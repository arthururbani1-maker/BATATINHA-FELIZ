# Prompt-mestre — Criar um sistema de gestão (SPA + nuvem) que "simplesmente funciona"

> Copie tudo abaixo da linha e cole no assistente (Claude/Cowork). Onde estiver **[COLCHETES]**, preencha com a sua área.
> Este prompt já embute as correções de tudo que quebrou no primeiro sistema (perda de dados na nuvem, sobrescrita entre computadores, estouro de transferência). Siga-o à risca.

---

## Papel e objetivo
Você é um engenheiro sênior. Construa um **sistema de gestão web** para a área de **[EX: barbearia / oficina mecânica / petshop / clínica / distribuidora]**, funcionando como um app profissional em nuvem: single-page, rápido, offline-capaz, com **Supabase como fonte oficial dos dados** e sincronização em tempo real entre vários computadores **sem nunca perder dados**.

## Stack e restrições (obrigatório)
- **Vanilla JS + HTML + CSS** (sem framework). Objetos globais: `DB`, `App`, `Modules`, `Cloud`, `Fmt`, `Toast`, `Modal`.
- Entregar como **arquivo único `index.html`** (CSS e JS embutidos) para hospedar no **GitHub Pages** — mas desenvolver em arquivos separados e ter um passo de "build" que inclui tudo num `index.html`.
- **Tema claro/escuro** com variáveis CSS centralizadas, detecção do sistema, alternância instantânea e persistência.
- **Responsivo**: desktop e celular.
- Nada de dependência pesada. Única lib externa permitida: `@supabase/supabase-js` via CDN (para realtime).
- Mostre um **marcador de versão visível** no rodapé do menu (ex.: "versão 1.0") para o usuário confirmar qual versão está rodando.

## Camada de dados (`data.js`) — a mais importante
- Estado único em memória, espelhado em **localStorage** (cache) e no **Supabase** (fonte oficial).
- `localStorage` guarda **cache + fila offline**; **jamais** é a fonte da verdade.
- Coleções (arrays) para cada entidade da área. Ex.: `[LISTE AS ENTIDADES: clientes, atendimentos, produtos, financeiro, caixa, agenda, ...]`.
- API central: `DB.load/save/all/get/insert/update/remove/logMov/logFin/importState/mergeRemote/mergeImport/restoreBackup/recordCount`.
- **REGRA DE OURO (controle de concorrência):** todo registro recebe um campo `__ver` gerado por **RELÓGIO LÓGICO (Lamport)**, NUNCA por `Date.now()` puro:
  - `nextVer(base) = max(_verLast, Date.now(), base) + 1`. Ao criar/editar, `__ver = nextVer(versaoAtualDoRegistro)`.
  - Ao carregar/mesclar, suba `_verLast` para o maior `__ver` visto (`bumpVerFromState`).
  - Motivo: computadores têm relógios diferentes; sem isso, um PC com relógio adiantado "vence" com dados velhos e reverte edições.
- **Toda gravação é automática** (não existe botão "salvar backup"). `DB.insert/update/remove` já persistem e disparam o envio à nuvem.

## Sincronização com Supabase (`cloud.js`) — implemente EXATAMENTE assim
Tabela única `erp_state (id text pk, data jsonb, rev bigint, updated_at timestamptz)` guardando o estado completo.

1. **Mesclagem por união, nunca substituição.** Ao receber dados da nuvem, faça `mergeRemote`: una as coleções por `id`. Registro que existe só em um lado é **sempre mantido** (nenhuma venda/registro pode sumir). Em conflito de `id`, **vence o maior `__ver`** (o mais novo). O antigo NUNCA sobrescreve o novo.
2. **Fila offline + flag "dirty".** Toda alteração local marca `dirty`. Um envio (`push`) só limpa o `dirty` **após sucesso** do Supabase. Se a internet cair, os dados ficam na fila e reenviam sozinhos (eventos `online`, `visibilitychange`, `beforeunload`).
3. **ECONOMIA DE TRANSFERÊNCIA (egress) — crítico:** o polling deve consultar **só a coluna `rev`** (`select=rev`, ~50 bytes) e **só baixar `data` quando `rev` aumentou**. NUNCA baixe o banco inteiro em loop — foi isso que estourou a cota de 5 GB.
4. **Realtime opcional (barato):** assine `postgres_changes` da tabela `erp_state` via supabase-js; ao receber evento, chame o mesmo `checkRemote` (que é "gated" por `rev`). Fallback: polling a cada **45 s**.
5. **Na abertura (`initialSync`):** puxe a nuvem UMA vez, **mescle** com o local e só reenvie se o local tiver algo que a nuvem não tem. Nunca sobrescreva o local com a nuvem cegamente.
6. **Indicador visual em 3 estados:** `Sincronizado` (verde) · `Sincronizando…` · `Sem conexão · alterações na fila`.
7. **Backups automáticos:** antes de qualquer substituição de estado, salve 2 pontos de backup rotativos no localStorage. Ofereça em Configurações: **Baixar cópia (.json)**, **Importar cópia (.json) e mesclar** (aditivo, nunca apaga), **Restaurar backup** (aditivo) e um **Diagnóstico** (contagens, última venda, log de sincronização, testar conexão).
8. **Confirmação antes da UI:** valide → grave (localStorage é síncrono) → confirme → só então feche/atualize a tela. Se a gravação falhar (armazenamento cheio/bloqueado), **não** conclua a operação e mostre erro claro.
9. **Logs internos de sync** (data, usuário, operação, sucesso/erro) visíveis no Diagnóstico.

## SQL do Supabase (entregar junto, para o usuário rodar)
```sql
create table if not exists public.erp_state (
  id text primary key, data jsonb, rev bigint default 0, updated_at timestamptz default now());
alter table public.erp_state enable row level security;
drop policy if exists "erp_state_all" on public.erp_state;
create policy "erp_state_all" on public.erp_state for all using (true) with check (true);
alter table public.erp_state replica identity full;
alter publication supabase_realtime add table public.erp_state;
```

## Módulos / telas (adapte à área)
Menu lateral com as telas. Base sugerida: **Dashboard** (KPIs do período + comparação com período anterior), **[TELA PRINCIPAL DE OPERAÇÃO — ex.: PDV / Agenda / Ordens de Serviço]**, **Cadastros** (clientes/produtos/serviços/fornecedores), **Financeiro** (contas a pagar/receber, caixa, formas de pagamento com taxa), **Relatórios/BI** (com **seletor de período global**: hoje, ontem, 7/15/30 dias, mês, mês anterior, 3/6/12 meses, ano, personalizado) e **Insights inteligentes** (recomendações baseadas SÓ nos dados reais, organizadas por prioridade 🔴🟡🟢, cada uma com "o que / qual dado / por que / qual ação"). **Configurações** (taxas, usuários/permissões, nuvem, segurança/backup).
Descreva as regras específicas da área aqui: **[REGRAS DO NEGÓCIO: o que é uma "venda/atendimento", status, estoque/agenda, comissões, etc.]**

## Convenções de UI
- Cards de KPI, tabelas com `table-wrap`, modais (`Modal.open`), avisos (`Toast.ok/err/warn`), badges de status.
- Nada de `localStorage`/`sessionStorage` para regras de negócio na interface — só para tema/preferências.
- Textos e datas em pt-BR (`Fmt.brl`, `Fmt.date`, `Fmt.datetime`, `Fmt.pct`).
- Permissões: administrador vê custo/lucro/margem/taxas; operador comum não.

## Disciplina de testes (obrigatória a cada mudança)
- `node --check` em todos os arquivos JS.
- Testes unitários em Node com shims de `localStorage`/`document` e um **Supabase simulado** cobrindo: registro antigo NÃO sobrescreve o novo; união entre 2 dispositivos; edição concorrente do mesmo registro; fila offline reenvia; polling ocioso NÃO baixa dados (só `rev`); backup/restauração aditivos.
- Só depois de passar nos testes, gere o `index.html` único.

## Anti-padrões — NÃO cometa (foram bugs reais)
1. ❌ Sobrescrever o estado da nuvem por cima do local (ou vice-versa) sem mesclar → **perde vendas**. ✅ Sempre mesclar por união.
2. ❌ Versionar por `Date.now()` puro → relógios diferentes revertem edições. ✅ Relógio lógico (Lamport).
3. ❌ Baixar o banco inteiro em polling curto → **estoura egress (5 GB)**. ✅ Consultar só `rev`, baixar `data` só quando mudou.
4. ❌ Contador `rev` por dispositivo decidindo quem vence → o de `rev` maior ganha mesmo com dado velho. ✅ Conflito por `__ver` de cada registro.
5. ❌ Atualizar a tela como se tivesse salvo antes de confirmar a gravação. ✅ Confirmar primeiro.
6. ❌ Semear dados de exemplo por cima de dados reais no arranque. ✅ Semente só se não existir nada.

## Entregáveis
- `index.html` único pronto para o GitHub Pages, com marcador de versão visível.
- Arquivo `SUPABASE.sql` para o usuário rodar.
- Instruções curtas de deploy (subir `index.html` no GitHub, abrir em aba anônima com Cmd+Shift+R) e de teste com 2 computadores (criar registro em A → aparece em B; fechar/reabrir → nada some).
- Ao final, relate: problemas previstos e como o design os evita, arquivos criados, e como validou (testes).

## Área específica deste sistema
**[DESCREVA AQUI EM DETALHE: para que serve, quem usa, as telas, as entidades, as regras, os relatórios e os insights que você quer.]**
