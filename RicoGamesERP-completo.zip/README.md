# Rico Games — ERP & PDV

Sistema de gestão (ERP interno + PDV) para loja de games. Funciona **offline**, direto no navegador, sem instalação e sem servidor. Todos os dados ficam salvos localmente (localStorage) no computador da loja.

## Como abrir

Dê dois cliques em **`index.html`** (ou arraste para o navegador Chrome/Edge).

- Usuário: **admin** · Senha: **1234**
- O sistema já vem com dados de demonstração (produtos, vendas, compras, fornecedores) para você testar tudo.

## Módulos

| Módulo | O que faz |
|---|---|
| **Dashboard** | Faturamento dia/mês, lucro bruto e líquido (dia/mês/ano), estoque, estoque baixo, produtos parados, contas a pagar/receber, últimas movimentações, gráfico de 14 dias |
| **PDV** | Venda rápida com busca por nome/SKU/código de barras, carrinho, desconto, PIX/Dinheiro/Débito/Crédito/parcelamento, **usado como pagamento**, cálculo de lucro e baixa automática de estoque |
| **Estoque** | Cadastro de produtos (categoria, marca, modelo, condição novo/seminovo/usado, custo unitário/médio, preço, estoque mínimo, nº de série, localização, status) + ajuste de inventário |
| **Compras** | Entrada de mercadorias com frete/impostos rateados no custo, histórico, atualização automática do estoque e do custo médio |
| **Fornecedores** | Cadastro completo de fornecedores |
| **Avaliação de Usados** | Estado, caixa/acessórios, valor de mercado, valor aceito, custo de manutenção, custo final, preço sugerido e margem prevista → envia para o estoque |
| **Trocas** | Compra de usado, troca parcial, troca direta e usado como pagamento (ex.: PS5 R$3.500 − PS4 R$800 = R$2.700) |
| **Movimentações** | Histórico completo e rastreável de tudo (venda, compra, usado, troca, garantia, devolução, ajuste, manutenção) |
| **Garantias** | Controle por nº de série, prazo, defeito, status do atendimento, custo gerado e histórico de ocorrências |
| **Financeiro** | Fluxo de caixa, contas a pagar/receber, despesas fixas/variáveis e relatório por categoria |
| **Relatórios** | Mais vendidos, maior margem, produtos parados, giro de estoque, faturamento/lucro por período, vendas por categoria e forma de pagamento, usados mais rentáveis, ranking de rentabilidade |

## Arquitetura

```
index.html            → estrutura, login, navegação
assets/css/styles.css → design system (tema verde/grafite Rico Games), responsivo desktop/tablet/celular
assets/js/data.js     → camada de dados offline (localStorage) + dados demo
assets/js/ui.js       → formatação (R$, datas), modais, toasts, badges
assets/js/modules.js  → lógica e telas de todos os módulos
assets/js/reports.js  → relatórios gerenciais
assets/js/app.js      → roteamento e login
```

Integração entre módulos: toda venda/compra/troca/garantia gera automaticamente **movimentação** (rastreabilidade) e **lançamento financeiro**, e atualiza o **estoque** e o **custo médio**.

## Observações

- Os dados ficam no navegador deste computador. Para usar em vários PDVs sincronizados ou com backup em nuvem, é o próximo passo (backend + sincronização) — a base já está estruturada para isso.
- Para zerar e recarregar os dados de demonstração, abra o console do navegador e rode `DB.reset()`.
