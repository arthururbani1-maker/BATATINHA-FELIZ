/* ============ RICO GAMES ERP — Planejamento de Compras (Fase 1) ============
   Tela de APOIO À DECISÃO (somente leitura). NÃO compra, NÃO altera preço nem
   estoque, NÃO cria produto nem segunda base de estoque. Só LÊ os dados do ERP.

   Para cada produto calcula, com dados reais do período escolhido:
     • velocidade de venda (média/dia, /semana, /mês)
     • dias até ruptura = estoque ÷ média diária (trava anti-divisão-por-zero)
     • quantidade recomendada = (média diária × dias de cobertura) − estoque,
       ajustada de forma MODERADA pela tendência recente (opcional)
     • lucro unitário, margem sobre venda e sobre custo (as duas separadas)
     • investimento, faturamento e lucro potenciais da compra sugerida
     • última venda / última entrada / confiança (nº de vendas na base)
   Reaproveita BI.range/prevRange e o motor de auditoria ProdHist.collect —
   fonte ÚNICA de verdade para estoque e movimentações (nada contado em dobro).

   O item de menu "planejamento" e a permissão homônima já estão registrados. */

const Plan = {
  /* ---------- configurações (persistem no config → nuvem) ---------- */
  DEF: { cobertura: 30, prazo: 7, periodo: '30d', janelaParado: 60, tendencia: true, minRec: 1 },
  cfgRec() { return DB.all('config')[0] || null; },
  cfg() {
    const c = this.cfgRec();
    return Object.assign({}, this.DEF, (c && c.planejamento) || {});
  },
  setCfg(patch) {
    const c = this.cfgRec(); if (!c) return;
    DB.update('config', c.id, { planejamento: Object.assign({}, this.cfg(), patch) });
  },
  canFin() { return (typeof App === 'undefined') || App.canFinance(); },
  vendasValidas() { return DB.all('vendas').filter(v => !v.cancelada); },

  /* casa um item de venda/compra com um produto (por id, sku ou nome) */
  matcher(p) { return (it) => it.produtoId === p.id || (it.sku && p.sku && it.sku === p.sku) || (it.nome && it.nome === p.nome); },

  /* ---------- núcleo: métricas por produto num período ---------- */
  compute(periodo, de, ate) {
    const cfg = this.cfg();
    const r = BI.range(periodo, de, ate);
    const pr = BI.prevRange(r, periodo);
    const spanDias = Math.max(1, Math.round((r.end - r.start) / 86400000));
    const now = Date.now();

    // janela "parado": max(janelaParado, período) — evita marcar parado num período curto
    const janelaParadoMs = Math.max(cfg.janelaParado, spanDias) * 86400000;

    const vendas = this.vendasValidas();
    const vendasPer = vendas.filter(v => { const d = new Date(v.data); return d >= r.start && d <= r.end; });
    const vendasPrev = vendas.filter(v => { const d = new Date(v.data); return d >= pr.start && d <= pr.end; });

    // acumuladores por produtoId (fallback sku) para o período e o anterior
    const acc = {};      // { qtd, receita, custo, dias:Set, precos:[] }
    const accPrev = {};  // { qtd }
    const lastSale = {}; // ultima venda (qualquer data)
    const prods = DB.all('produtos');
    const byId = {}; prods.forEach(p => byId[p.id] = p);
    // índice sku→produto para casar itens sem produtoId
    const bySku = {}; prods.forEach(p => { if (p.sku) bySku[p.sku] = p; });
    const byNome = {}; prods.forEach(p => { if (p.nome) byNome[p.nome] = p; });
    const keyOf = (it) => {
      if (it.produtoId && byId[it.produtoId]) return it.produtoId;
      if (it.sku && bySku[it.sku]) return bySku[it.sku].id;
      if (it.nome && byNome[it.nome]) return byNome[it.nome].id;
      return null;
    };

    const bump = (map, v, it, withDetail) => {
      const id = keyOf(it); if (!id) return;
      const p = byId[id];
      const cu = (it.custo > 0) ? it.custo : (p.custoMedio || p.custo || 0);
      const o = map[id] || (map[id] = { qtd: 0, receita: 0, custo: 0, dias: new Set(), precos: [] });
      o.qtd += (+it.qtd || 0);
      if (withDetail) {
        o.receita += it.preco * (+it.qtd || 0);
        o.custo += cu * (+it.qtd || 0);
        o.dias.add(new Date(v.data).toISOString().slice(0, 10));
        if (it.preco > 0 && it.qtd > 0) o.precos.push({ preco: it.preco, qtd: +it.qtd, data: v.data });
      }
    };
    vendasPer.forEach(v => (v.itens || []).forEach(it => bump(acc, v, it, true)));
    vendasPrev.forEach(v => (v.itens || []).forEach(it => bump(accPrev, v, it, false)));
    vendas.forEach(v => (v.itens || []).forEach(it => {
      const id = keyOf(it); if (!id) return;
      const d = +new Date(v.data); if (!lastSale[id] || d > lastSale[id]) lastSale[id] = d;
    }));

    // última entrada: compras não canceladas + p.entradas + usados recebidos
    const lastIn = {};
    const markIn = (id, data) => { if (!id) return; const d = +new Date(data); if (!lastIn[id] || d > lastIn[id]) lastIn[id] = d; };
    DB.all('compras').filter(c => !c.cancelada).forEach(c => (c.itens || []).forEach(it => markIn(keyOf(it), c.data)));
    prods.forEach(p => (p.entradas || []).forEach(e => markIn(p.id, e.data)));
    vendas.forEach(v => (v.usados || []).forEach(u => markIn(u.produtoId, v.data)));

    const rows = prods.map(p => {
      const a = acc[p.id] || { qtd: 0, receita: 0, custo: 0, dias: new Set(), precos: [] };
      const ap = accPrev[p.id] || { qtd: 0 };
      const estoque = +p.qtd || 0;
      const custoMedio = p.custoMedio || p.custo || 0;
      const preco = +p.preco || 0;
      const vendidas = a.qtd;
      const mediaDia = vendidas / spanDias;
      const mediaSem = mediaDia * 7, mediaMes = mediaDia * 30;

      // tendência: período atual vs anterior (fator moderado 0,5–1,5)
      let trendPct = 0, fator = 1;
      if (ap.qtd > 0) { trendPct = (vendidas - ap.qtd) / ap.qtd * 100; }
      else if (vendidas > 0) { trendPct = 100; }
      if (cfg.tendencia && ap.qtd > 0) {
        fator = vendidas / ap.qtd;
        fator = Math.max(0.5, Math.min(1.5, fator));
      }
      const mediaAjust = mediaDia * fator;

      // dias até ruptura (trava anti-divisão-por-zero)
      let diasRuptura;
      if (mediaDia <= 0) diasRuptura = estoque > 0 ? Infinity : 0;
      else diasRuptura = estoque / mediaDia;

      // quantidade recomendada: cobrir "cobertura" dias, líquido do estoque atual
      const alvo = mediaAjust * cfg.cobertura;
      let qtdRec = Math.ceil(alvo - estoque);
      if (qtdRec < 0) qtdRec = 0;
      if (qtdRec > 0 && qtdRec < cfg.minRec) qtdRec = cfg.minRec;

      const lucroUnit = preco - custoMedio;
      const margemV = preco > 0 ? lucroUnit / preco * 100 : 0;   // sobre venda
      const margemC = custoMedio > 0 ? lucroUnit / custoMedio * 100 : 0; // sobre custo
      const investimento = qtdRec * custoMedio;
      const faturamentoPot = qtdRec * preco;
      const lucroPot = qtdRec * lucroUnit;

      const diasSemVender = lastSale[p.id] ? Math.round((now - lastSale[p.id]) / 86400000) : null;
      const nuncaVendeu = !lastSale[p.id];
      const parado = estoque > 0 && (nuncaVendeu ? (now - (+new Date(p.criadoEm || now)) >= janelaParadoMs) : (now - lastSale[p.id] >= janelaParadoMs));

      // STATUS
      let status;
      if (parado) status = 'parado';
      else if (mediaDia <= 0) status = estoque > 0 ? 'saudavel' : 'saudavel'; // sem venda no período mas não parado
      else if (diasRuptura <= cfg.prazo) status = 'urgente';
      else if (diasRuptura <= cfg.cobertura) status = 'breve';
      else status = 'saudavel';
      // sem estoque e com demanda = urgente
      if (estoque <= 0 && mediaDia > 0) status = 'urgente';

      return {
        id: p.id, nome: p.nome, sku: p.sku, categoria: p.categoria || '—', condicao: p.condicao || 'novo',
        estoque, custoMedio, preco, min: +p.min || 0,
        vendidas, receita: a.receita, mediaDia, mediaSem, mediaMes, mediaAjust,
        diasRuptura, qtdRec, lucroUnit, margemV, margemC,
        investimento, faturamentoPot, lucroPot,
        trendPct, fator, nVendas: a.dias.size, precos: a.precos,
        ultimaVenda: lastSale[p.id] || null, ultimaEntrada: lastIn[p.id] || null,
        diasSemVender, nuncaVendeu, parado, status
      };
    });

    // totais (só produtos que geram recomendação de compra entram no investimento)
    const buy = rows.filter(x => x.qtdRec > 0);
    const totals = {
      spanDias, label: BI.periodoLabel(periodo, r), labelPrev: BI.periodoLabel('custom', pr),
      urgente: rows.filter(x => x.status === 'urgente').length,
      breve: rows.filter(x => x.status === 'breve').length,
      saudavel: rows.filter(x => x.status === 'saudavel').length,
      parado: rows.filter(x => x.status === 'parado').length,
      investimento: buy.reduce((s, x) => s + x.investimento, 0),
      faturamentoPot: buy.reduce((s, x) => s + x.faturamentoPot, 0),
      lucroPot: buy.reduce((s, x) => s + x.lucroPot, 0),
      capitalParado: rows.filter(x => x.status === 'parado').reduce((s, x) => s + x.estoque * x.custoMedio, 0),
      nBuy: buy.length
    };
    return { rows, totals, cfg, r, pr };
  },

  /* ============ UI ============ */
  st: { periodo: null, de: '', ate: '', cat: '', status: '', sort: 'urgencia', dir: -1, view: 'plan' },

  _statusMeta: {
    urgente: { ico: '🔴', label: 'Comprar agora', cls: 'urg' },
    breve: { ico: '🟠', label: 'Comprar em breve', cls: 'brv' },
    saudavel: { ico: '🟢', label: 'Estoque saudável', cls: 'ok' },
    parado: { ico: '🔵', label: 'Parado', cls: 'par' }
  },
  statusOrder: { urgente: 0, breve: 1, saudavel: 2, parado: 3 },

  page() {
    if (this.st.periodo == null) this.st.periodo = this.cfg().periodo || '30d';
    this.injectCss();
    setTimeout(() => this.render(), 20);
    return `
      <div class="page-head">
        <div><h1>Planejamento de Compras</h1><p>Apoio à decisão · o que repor, quanto e o retorno esperado · somente leitura</p></div>
        <div class="actions">
          <button class="btn-ghost" onclick="Plan.exportXlsx()">⬇️ Excel</button>
          <button class="btn-ghost" onclick="Plan.exportPdf()">🖨️ PDF</button>
          <button class="btn-ghost" onclick="Plan.openCfg()">⚙️ Ajustes</button>
        </div>
      </div>
      <div id="plan-root"></div>`;
  },

  setPeriodo(v) { this.st.periodo = v; const cc = document.getElementById('plan-custom'); if (cc) cc.style.display = v === 'custom' ? 'inline-flex' : 'none'; if (v !== 'custom') this.render(); },
  applyCustom() { this.st.de = fval('plan-de'); this.st.ate = fval('plan-ate'); this.st.periodo = 'custom'; this.render(); },
  setCat(v) { this.st.cat = v; this.render(); },
  setStatus(v) { this.st.status = (this.st.status === v ? '' : v); this.render(); },
  setView(v) { this.st.view = v; this.render(); },
  sort(k) { const S = this.st; if (S.sort === k) S.dir = -S.dir; else { S.sort = k; S.dir = -1; } this.render(); },

  data() { return this.compute(this.st.periodo, this.st.de, this.st.ate); },

  filtered(D) {
    const S = this.st;
    let rows = D.rows.slice();
    if (S.cat) rows = rows.filter(x => x.categoria === S.cat);
    if (S.status) rows = rows.filter(x => x.status === S.status);
    const key = S.sort;
    const val = x => {
      if (key === 'urgencia') return -(this.statusOrder[x.status] * 1e9 - (x.diasRuptura === Infinity ? 1e6 : x.diasRuptura));
      if (key === 'nome') return x.nome;
      if (key === 'ruptura') return x.diasRuptura === Infinity ? 1e9 : x.diasRuptura;
      return x[key] != null ? x[key] : 0;
    };
    rows.sort((a, b) => {
      if (key === 'nome') return a.nome.localeCompare(b.nome) * (S.dir < 0 ? -1 : 1);
      if (key === 'urgencia') { // urgência: 🔴 primeiro, dentro do grupo menor ruptura primeiro
        const oa = this.statusOrder[a.status], ob = this.statusOrder[b.status];
        if (oa !== ob) return oa - ob;
        const ra = a.diasRuptura === Infinity ? 1e9 : a.diasRuptura, rb = b.diasRuptura === Infinity ? 1e9 : b.diasRuptura;
        return ra - rb;
      }
      return (val(b) - val(a)) * (S.dir < 0 ? 1 : -1);
    });
    return rows;
  },

  render() {
    const el = document.getElementById('plan-root'); if (!el) return;
    const D = this.data();
    el.innerHTML = this.filtrosHtml(D) + this.dashHtml(D) + (
      this.st.view === 'rankings' ? this.rankingsHtml(D) :
      this.st.view === 'parados' ? this.paradosHtml(D) :
      this.tabelaHtml(D));
  },

  filtrosHtml(D) {
    const S = this.st, fin = this.canFin();
    const cats = [...new Set(DB.all('produtos').map(p => p.categoria).filter(Boolean))].sort();
    const per = typeof periodOptsHtml === 'function' ? periodOptsHtml(S.periodo) :
      [['all', 'Todo o período'], ['7d', '7 dias'], ['30d', '30 dias'], ['mes', 'Mês atual']].map(o => `<option value="${o[0]}" ${S.periodo === o[0] ? 'selected' : ''}>${o[1]}</option>`).join('');
    const custom = `<span id="plan-custom" style="display:${S.periodo === 'custom' ? 'inline-flex' : 'none'};gap:6px;align-items:center">
      <input type="date" id="plan-de" value="${S.de}"><span class="muted">até</span><input type="date" id="plan-ate" value="${S.ate}">
      <button class="btn-primary btn-sm" onclick="Plan.applyCustom()">Aplicar</button></span>`;
    const catSel = `<select onchange="Plan.setCat(this.value)"><option value="">Todas as categorias</option>${cats.map(c => `<option value="${esc(c)}" ${S.cat === c ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select>`;
    const views = [['plan', '📋 Plano de compra'], ['rankings', '🏆 Rankings'], ['parados', '🧊 Parados']];
    const viewTabs = `<div class="plan-views">${views.map(v => `<button class="plan-view ${S.view === v[0] ? 'on' : ''}" onclick="Plan.setView('${v[0]}')">${v[1]}</button>`).join('')}</div>`;
    return `<div class="plan-fbar">
      <div class="plan-fleft">
        <select onchange="Plan.setPeriodo(this.value)">${per}</select>
        ${custom}
        ${catSel}
      </div>
      <div class="plan-flabel">📅 <b>${esc(D.totals.label)}</b> · vendas dos últimos ${D.totals.spanDias} dia(s)</div>
    </div>${viewTabs}`;
  },

  dashHtml(D) {
    const t = D.totals, fin = this.canFin(), S = this.st;
    const card = (key, val, sub) => {
      const m = this._statusMeta[key];
      return `<div class="plan-dcard ${m.cls} ${S.status === key ? 'sel' : ''}" onclick="Plan.setStatus('${key}')" title="Filtrar por ${m.label}">
        <div class="plan-dc-top">${m.ico} <span>${m.label}</span></div>
        <div class="plan-dc-val">${val}</div><div class="plan-dc-sub">${sub}</div></div>`;
    };
    const money = (l, v, cls, sub) => `<div class="plan-mcard ${cls || ''}"><div class="plan-mc-l">${l}</div><div class="plan-mc-v">${v}</div><div class="plan-dc-sub">${sub}</div></div>`;
    const st = `<div class="plan-dash">
      ${card('urgente', t.urgente, 'produto(s)')}
      ${card('breve', t.breve, 'produto(s)')}
      ${card('saudavel', t.saudavel, 'produto(s)')}
      ${card('parado', t.parado, 'produto(s)')}
    </div>`;
    const mon = fin ? `<div class="plan-money">
      ${money('Investimento p/ repor', Fmt.brl(t.investimento), 'inv', t.nBuy + ' produto(s) sugerido(s)')}
      ${money('Faturamento potencial', Fmt.brl(t.faturamentoPot), 'fat', 'se vender tudo que repor')}
      ${money('Lucro potencial', Fmt.brl(t.lucroPot), 'luc', 'faturamento − custo de reposição')}
      ${money('Capital parado', Fmt.brl(t.capitalParado), 'par', t.parado + ' produto(s) sem giro')}
    </div>` : '';
    return st + mon;
  },

  urgBadge(x) { const m = this._statusMeta[x.status]; return `<span class="plan-badge ${m.cls}">${m.ico} ${m.label}</span>`; },
  rupturaTxt(x) {
    if (x.estoque <= 0) return '<span style="color:var(--red);font-weight:700">sem estoque</span>';
    if (x.diasRuptura === Infinity) return '<span class="muted">sem giro</span>';
    const d = Math.floor(x.diasRuptura);
    const c = x.diasRuptura <= this.cfg().prazo ? 'var(--red)' : (x.diasRuptura <= this.cfg().cobertura ? '#d97706' : 'var(--txt)');
    return `<span style="color:${c};font-weight:600">${d} dia${d === 1 ? '' : 's'}</span>`;
  },

  tabelaHtml(D) {
    const fin = this.canFin(), S = this.st;
    const rows = this.filtered(D);
    if (!DB.all('produtos').length) return '<div class="empty-state"><div class="big">📦</div>Nenhum produto cadastrado ainda.</div>';
    if (!rows.length) return '<div class="empty-state"><div class="big">🔎</div>Nenhum produto no filtro selecionado.<br><button class="btn-ghost btn-sm" style="margin-top:10px" onclick="Plan.setStatus(\'\')">Limpar filtro de status</button></div>';
    const arrow = k => S.sort === k ? (S.dir < 0 ? ' ▼' : ' ▲') : '';
    const th = (k, lbl, cls) => `<th class="${cls || ''}" style="cursor:pointer;white-space:nowrap" onclick="Plan.sort('${k}')">${lbl}${arrow(k)}</th>`;
    const body = rows.map(x => `<tr>
      <td>${this.urgBadge(x)}</td>
      <td class="strong"><span class="plan-plink" onclick="ProdHist.open('${x.id}')" title="Ver histórico de auditoria">${esc(x.nome)} 🔎</span><div class="muted" style="font-size:11px">${esc(x.sku || '')} · ${esc(x.categoria)}</div></td>
      <td class="num">${x.estoque}</td>
      <td class="num">${x.mediaDia > 0 ? x.mediaDia.toFixed(2).replace('.', ',') : '—'}</td>
      <td class="num">${this.rupturaTxt(x)}</td>
      <td class="num strong" style="color:${x.qtdRec > 0 ? 'var(--accent)' : 'var(--txt-3)'}">${x.qtdRec > 0 ? x.qtdRec : '—'}</td>
      ${fin ? `<td class="num">${x.qtdRec > 0 ? Fmt.brl(x.investimento) : '—'}</td>` : ''}
      ${fin ? `<td class="num">${x.qtdRec > 0 ? Fmt.brl(x.faturamentoPot) : '—'}</td>` : ''}
      ${fin ? `<td class="num" style="color:${x.lucroPot >= 0 ? 'var(--green)' : 'var(--red)'}">${x.qtdRec > 0 ? Fmt.brl(x.lucroPot) : '—'}</td>` : ''}
      ${fin ? `<td class="num">${x.preco > 0 ? Fmt.pct(x.margemV) : '—'}</td>` : ''}
      <td style="white-space:nowrap"><button class="btn-ghost btn-sm" onclick="Plan.analisar('${x.id}')">🔎 Analisar</button> <button class="btn-ghost btn-sm" onclick="Plan.simular('${x.id}')">🧮 Simular</button></td>
    </tr>`).join('');
    return `<div class="card"><div class="section-title">Plano de compra <span class="muted" style="font-weight:500">· ${rows.length} produto(s)${S.status ? ' · filtro: ' + this._statusMeta[S.status].label : ''}</span></div>
      <div class="table-wrap"><table><thead><tr>
        ${th('urgencia', 'Status')}
        ${th('nome', 'Produto')}
        ${th('estoque', 'Estoque', 'num')}
        ${th('mediaDia', 'Média/dia', 'num')}
        ${th('ruptura', 'Ruptura', 'num')}
        ${th('qtdRec', 'Comprar', 'num')}
        ${fin ? th('investimento', 'Investir', 'num') : ''}
        ${fin ? th('faturamentoPot', 'Fat. pot.', 'num') : ''}
        ${fin ? th('lucroPot', 'Lucro pot.', 'num') : ''}
        ${fin ? th('margemV', 'Margem', 'num') : ''}
        <th></th>
      </tr></thead><tbody>${body}</tbody></table></div>
      <div class="muted" style="font-size:11.5px;margin-top:8px">Média/dia e ruptura usam as vendas do período. "Comprar" cobre ${D.cfg.cobertura} dias de venda${D.cfg.tendencia ? ', ajustado pela tendência recente' : ''}. Clique no produto para o histórico completo.</div>
    </div>`;
  },

  /* ---------- rankings ---------- */
  rankingsHtml(D) {
    const fin = this.canFin();
    const withSales = D.rows.filter(x => x.vendidas > 0);
    const rk = (title, ico, rows, fmt) => {
      if (!rows.length) return `<div class="card"><div class="section-title">${ico} ${title}</div><div class="muted" style="font-size:12.5px">Sem dados suficientes no período.</div></div>`;
      return `<div class="card"><div class="section-title">${ico} ${title}</div>
        <div class="table-wrap"><table><thead><tr><th>#</th><th>Produto</th><th class="num">${fmt.h}</th></tr></thead>
        <tbody>${rows.map((x, i) => `<tr><td class="muted">${i + 1}</td><td class="strong"><span class="plan-plink" onclick="ProdHist.open('${x.id}')">${esc(x.nome)}</span><div class="muted" style="font-size:11px">${esc(x.categoria)}</div></td><td class="num strong">${fmt.v(x)}</td></tr>`).join('')}</tbody></table></div></div>`;
    };
    const top = (arr, fn, n) => arr.slice().sort((a, b) => fn(b) - fn(a)).slice(0, n || 8);
    let out = '<div class="plan-rk-grid">';
    out += rk('Mais vendidos', '📦', top(withSales, x => x.vendidas), { h: 'Qtd', v: x => x.vendidas + ' un' });
    out += rk('Maior necessidade de compra', '🛒', top(D.rows.filter(x => x.qtdRec > 0), x => x.qtdRec), { h: 'Comprar', v: x => x.qtdRec + ' un' });
    if (fin) out += rk('Maior lucro potencial na reposição', '💎', top(D.rows.filter(x => x.qtdRec > 0), x => x.lucroPot), { h: 'Lucro pot.', v: x => Fmt.brl(x.lucroPot) });
    if (fin) out += rk('Maior margem s/ venda', '📐', top(D.rows.filter(x => x.preco > 0), x => x.margemV), { h: 'Margem', v: x => Fmt.pct(x.margemV) });
    if (fin) out += rk('Maior investimento necessário', '💰', top(D.rows.filter(x => x.qtdRec > 0), x => x.investimento), { h: 'Investir', v: x => Fmt.brl(x.investimento) });
    out += rk('Mais próximos da ruptura', '⏳', D.rows.filter(x => x.diasRuptura !== Infinity && x.estoque > 0 && x.mediaDia > 0).sort((a, b) => a.diasRuptura - b.diasRuptura).slice(0, 8), { h: 'Ruptura', v: x => Math.floor(x.diasRuptura) + ' d' });
    out += '</div>';
    return out;
  },

  /* ---------- parados ---------- */
  paradosHtml(D) {
    const fin = this.canFin();
    const rows = D.rows.filter(x => x.status === 'parado').sort((a, b) => (b.estoque * b.custoMedio) - (a.estoque * a.custoMedio));
    if (!rows.length) return '<div class="card"><div class="section-title">🧊 Produtos parados</div><div class="empty-state"><div class="big">✅</div>Nenhum produto parado com o critério atual (' + this.cfg().janelaParado + ' dias sem vender).</div></div>';
    const totalCap = rows.reduce((s, x) => s + x.estoque * x.custoMedio, 0);
    const body = rows.map(x => `<tr>
      <td class="strong"><span class="plan-plink" onclick="ProdHist.open('${x.id}')">${esc(x.nome)} 🔎</span><div class="muted" style="font-size:11px">${esc(x.sku || '')} · ${esc(x.categoria)}</div></td>
      <td class="num">${x.estoque}</td>
      ${fin ? `<td class="num">${Fmt.brl(x.custoMedio)}</td>` : ''}
      ${fin ? `<td class="num strong">${Fmt.brl(x.estoque * x.custoMedio)}</td>` : ''}
      <td class="num">${x.nuncaVendeu ? '<span class="muted">nunca vendeu</span>' : x.diasSemVender + ' dias'}</td>
      <td><button class="btn-ghost btn-sm" onclick="Plan.analisar('${x.id}')">🔎 Analisar</button></td>
    </tr>`).join('');
    return `<div class="card"><div class="section-title">🧊 Produtos parados <span class="muted" style="font-weight:500">· ${rows.length} produto(s) · ${this.cfg().janelaParado} dias sem vender</span></div>
      ${fin ? `<div class="plan-parw">💰 Capital parado nesses produtos: <b>${Fmt.brl(totalCap)}</b> — dinheiro que poderia estar girando.</div>` : ''}
      <div class="table-wrap"><table><thead><tr><th>Produto</th><th class="num">Estoque</th>${fin ? '<th class="num">Custo un.</th><th class="num">Capital parado</th>' : ''}<th class="num">Sem vender</th><th></th></tr></thead><tbody>${body}</tbody></table></div>
      <div class="muted" style="font-size:11.5px;margin-top:8px">Sugestão: avalie promoção, combo ou destaque na loja. Esta tela não altera preço nem estoque — apenas aponta oportunidades.</div>
    </div>`;
  },

  /* ---------- modal: analisar produto ---------- */
  findRow(id) { const D = this.data(); return D.rows.find(x => x.id === id); },
  analisar(id) {
    const x = this.findRow(id); if (!x) return Toast.err('Produto não encontrado.');
    const fin = this.canFin(), cfg = this.cfg();
    const kpi = (l, v, c) => `<div class="ap-kpi"><span>${l}</span><b${c ? ` style="color:${c}"` : ''}>${v}</b></div>`;
    const kpis = `<div class="ap-kpis">
      ${kpi('Estoque atual', x.estoque + ' un', x.estoque <= 0 ? 'var(--red)' : '')}
      ${kpi('Vendidas no período', x.vendidas + ' un')}
      ${kpi('Média por dia', x.mediaDia > 0 ? x.mediaDia.toFixed(2).replace('.', ',') : '0')}
      ${kpi('Média por semana', x.mediaSem > 0 ? x.mediaSem.toFixed(1).replace('.', ',') : '0')}
      ${kpi('Média por mês', x.mediaMes > 0 ? x.mediaMes.toFixed(1).replace('.', ',') : '0')}
      ${kpi('Dias até ruptura', x.estoque <= 0 ? '0' : (x.diasRuptura === Infinity ? '—' : Math.floor(x.diasRuptura) + ' d'))}
      ${fin ? kpi('Preço de venda', Fmt.brl(x.preco)) : ''}
      ${fin ? kpi('Custo médio', Fmt.brl(x.custoMedio)) : ''}
      ${fin ? kpi('Lucro por unidade', Fmt.brl(x.lucroUnit), x.lucroUnit >= 0 ? 'var(--green)' : 'var(--red)') : ''}
      ${fin ? kpi('Margem s/ venda', Fmt.pct(x.margemV)) : ''}
      ${fin ? kpi('Margem s/ custo', Fmt.pct(x.margemC)) : ''}
    </div>`;

    // raciocínio da recomendação
    const passos = [];
    passos.push(`Vendas do período: <b>${x.vendidas} un</b> em ${cfg.periodo === 'custom' ? 'período personalizado' : this.data().totals.spanDias + ' dias'} → média de <b>${x.mediaDia.toFixed(2).replace('.', ',')}/dia</b>.`);
    if (cfg.tendencia && x.fator !== 1) passos.push(`Tendência recente: ${x.trendPct >= 0 ? 'alta' : 'queda'} de ${Fmt.pct(Math.abs(x.trendPct))} vs. período anterior → média ajustada para <b>${x.mediaAjust.toFixed(2).replace('.', ',')}/dia</b> (ajuste limitado a ±50%).`);
    passos.push(`Cobertura desejada: <b>${cfg.cobertura} dias</b> → precisa de ${Math.ceil(x.mediaAjust * cfg.cobertura)} un; já tem ${x.estoque} → <b>comprar ${x.qtdRec} un</b>.`);
    if (x.estoque > 0 && x.diasRuptura !== Infinity) passos.push(`No ritmo atual o estoque acaba em <b>${Math.floor(x.diasRuptura)} dias</b> (prazo de reposição configurado: ${cfg.prazo} dias).`);
    const reco = `<div class="card"><div class="section-title">🛒 Recomendação</div>
      <div class="plan-reco ${x.qtdRec > 0 ? 'go' : 'hold'}">${x.qtdRec > 0 ? `Comprar <b>${x.qtdRec} un</b>${fin ? ` · investir <b>${Fmt.brl(x.investimento)}</b> · faturamento potencial <b>${Fmt.brl(x.faturamentoPot)}</b> · lucro potencial <b>${Fmt.brl(x.lucroPot)}</b>` : ''}` : 'Não é necessário comprar agora — estoque cobre a demanda do período de cobertura.'}</div>
      <ul class="plan-steps">${passos.map(p => `<li>${p}</li>`).join('')}</ul>
      <div class="muted" style="font-size:11.5px">Estimativa baseada em ${x.nVendas} dia(s) com venda. ${x.nVendas < 3 ? '<b>Confiança baixa</b> — poucos dados; use como referência, não como garantia.' : 'Toda previsão é uma estimativa, não uma garantia.'}</div>
    </div>`;

    // preço × velocidade — só quando houver base suficiente
    const pv = this.precoVelocidade(x);

    // última venda / entrada
    const info = `<div class="card"><div class="section-title">Rastreamento</div><div class="ap-stats">
      ${kpi('Última venda', x.ultimaVenda ? Fmt.date(x.ultimaVenda) : 'nunca')}
      ${kpi('Última entrada', x.ultimaEntrada ? Fmt.date(x.ultimaEntrada) : '—')}
      ${kpi('Estoque mínimo', (x.min || 0) + ' un')}
      ${kpi('Confiança', x.nVendas >= 5 ? 'alta' : (x.nVendas >= 3 ? 'média' : 'baixa'))}
    </div></div>`;

    Modal.open({
      title: '🔎 Análise — ' + esc(x.nome), wide: true,
      body: `<div class="plan-an">
        <div class="ap-head"><div><h2 style="margin:0">${esc(x.nome)}</h2><div class="muted" style="font-size:12.5px">${esc(x.categoria)} · ${esc(x.condicao)} · ${esc(x.sku || '')}</div></div><div class="ap-head-per">${this.urgBadge(x)}</div></div>
        ${kpis}${reco}${pv}${info}</div>`,
      foot: `<button class="btn-ghost" onclick="ProdHist.open('${x.id}')">📦 Histórico completo</button>
        <button class="btn-ghost" onclick="Plan.simular('${x.id}')">🧮 Simular compra</button>
        <button class="btn-primary" onclick="Modal.close()">Fechar</button>`
    });
  },

  // relaciona preço praticado × unidades vendidas — com honestidade sobre dados insuficientes
  precoVelocidade(x) {
    const title = `<div class="section-title">💹 Preço × velocidade de venda</div>`;
    // agrupa por faixa de preço
    const pts = x.precos || [];
    const distintos = [...new Set(pts.map(p => Math.round(p.preco)))];
    if (pts.length < 4 || distintos.length < 2) {
      return `<div class="card">${title}<div class="plan-insuf">📉 <b>Dados insuficientes</b> para relacionar preço e volume deste produto. ${pts.length < 4 ? 'Há poucas vendas no período' : 'O produto foi vendido sempre no mesmo preço'} — não é possível afirmar como o preço afeta o giro sem mais histórico.</div></div>`;
    }
    // buckets por preço
    const map = {};
    pts.forEach(p => { const k = Math.round(p.preco); map[k] = map[k] || { preco: k, qtd: 0, ocor: 0 }; map[k].qtd += p.qtd; map[k].ocor++; });
    const faixas = Object.values(map).sort((a, b) => a.preco - b.preco);
    const rows = faixas.map(f => `<tr><td class="num strong">${Fmt.brl(f.preco)}</td><td class="num">${f.qtd} un</td><td class="num">${f.ocor} venda(s)</td></tr>`).join('');
    // correlação simples (Pearson) preço × qtd por faixa
    const n = faixas.length, xs = faixas.map(f => f.preco), ys = faixas.map(f => f.qtd);
    const mx = xs.reduce((a, b) => a + b, 0) / n, my = ys.reduce((a, b) => a + b, 0) / n;
    let sxy = 0, sxx = 0, syy = 0; for (let i = 0; i < n; i++) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) ** 2; syy += (ys[i] - my) ** 2; }
    const rcorr = (sxx > 0 && syy > 0) ? sxy / Math.sqrt(sxx * syy) : 0;
    let leitura;
    if (Math.abs(rcorr) < 0.3) leitura = 'Não há relação clara entre preço e volume com os dados atuais.';
    else if (rcorr < 0) leitura = `Tendência observada: preços mais altos vieram acompanhados de <b>menor</b> volume. Correlação ${rcorr.toFixed(2).replace('.', ',')} — é uma <b>observação</b>, não prova de causa e efeito.`;
    else leitura = `Curiosamente, preços mais altos vieram com <b>maior</b> volume (correlação ${rcorr.toFixed(2).replace('.', ',')}) — provavelmente influência de outros fatores (época, campanhas). Não conclua causa e efeito.`;
    return `<div class="card">${title}
      <div class="table-wrap"><table><thead><tr><th class="num">Preço praticado</th><th class="num">Unidades</th><th class="num">Ocorrências</th></tr></thead><tbody>${rows}</tbody></table></div>
      <div class="plan-pv-read">${leitura}</div></div>`;
  },

  /* ---------- modal: simular compra ---------- */
  simState: { id: null, qtd: 0 },
  simular(id) {
    const x = this.findRow(id); if (!x) return Toast.err('Produto não encontrado.');
    this.simState = { id, qtd: x.qtdRec > 0 ? x.qtdRec : Math.max(1, Math.ceil(x.mediaAjust * this.cfg().cobertura)) };
    Modal.open({
      title: '🧮 Simular compra — ' + esc(x.nome), wide: true,
      body: `<div id="plan-sim"></div>`,
      foot: `<button class="btn-ghost" onclick="Plan.analisar('${id}')">🔎 Ver análise</button><button class="btn-primary" onclick="Modal.close()">Fechar</button>`
    });
    this.simRender();
  },
  simSet(v) { let q = parseInt(v, 10); if (isNaN(q) || q < 0) q = 0; this.simState.qtd = q; this.simRender(); },
  simStep(d) { this.simSet(Math.max(0, (this.simState.qtd || 0) + d)); },
  simRender() {
    const el = document.getElementById('plan-sim'); if (!el) return;
    const x = this.findRow(this.simState.id); if (!x) return;
    const fin = this.canFin(), q = this.simState.qtd;
    const investimento = q * x.custoMedio, faturamento = q * x.preco, lucro = q * x.lucroUnit;
    const margemV = x.preco > 0 ? x.lucroUnit / x.preco * 100 : 0;
    const diasCobre = x.mediaDia > 0 ? (q + x.estoque) / x.mediaDia : Infinity;
    const diasSoCompra = x.mediaDia > 0 ? q / x.mediaDia : Infinity;
    const kpi = (l, v, c) => `<div class="ap-kpi"><span>${l}</span><b${c ? ` style="color:${c}"` : ''}>${v}</b></div>`;
    el.innerHTML = `
      <div class="plan-sim-top">
        <div class="muted" style="font-size:12.5px">${esc(x.categoria)} · estoque atual ${x.estoque} un · média ${x.mediaDia.toFixed(2).replace('.', ',')}/dia${fin ? ' · custo ' + Fmt.brl(x.custoMedio) + ' · preço ' + Fmt.brl(x.preco) : ''}</div>
        <div class="plan-sim-qty">
          <span>Quantidade a comprar</span>
          <div class="plan-qstep">
            <button onclick="Plan.simStep(-1)">−</button>
            <input type="number" id="plan-simq" value="${q}" min="0" oninput="Plan.simSet(this.value)">
            <button onclick="Plan.simStep(1)">+</button>
          </div>
          ${x.qtdRec > 0 ? `<button class="btn-ghost btn-sm" onclick="Plan.simSet(${x.qtdRec})">usar recomendado (${x.qtdRec})</button>` : ''}
        </div>
      </div>
      <div class="ap-kpis" style="margin-top:12px">
        ${fin ? kpi('Investimento', Fmt.brl(investimento), 'var(--txt)') : ''}
        ${fin ? kpi('Faturamento potencial', Fmt.brl(faturamento)) : ''}
        ${fin ? kpi('Lucro potencial', Fmt.brl(lucro), lucro >= 0 ? 'var(--green)' : 'var(--red)') : ''}
        ${fin ? kpi('Margem s/ venda', Fmt.pct(margemV)) : ''}
        ${kpi('Essa compra dura', diasSoCompra === Infinity ? 'sem giro' : Math.round(diasSoCompra) + ' dias de venda')}
        ${kpi('Estoque total cobre', diasCobre === Infinity ? 'sem giro' : Math.round(diasCobre) + ' dias')}
      </div>
      <div class="muted" style="font-size:11.5px;margin-top:10px">Simulação de apoio — não registra compra nem altera estoque. "Dura X dias" = quantidade ÷ média diária de venda do período.</div>`;
  },

  /* ---------- configurações ---------- */
  openCfg() {
    const c = this.cfg();
    const f = (id, lbl, val, hint, min, max) => `<div class="plan-cfgf"><label>${lbl}</label><input type="number" id="${id}" value="${val}" min="${min != null ? min : 1}"${max != null ? ` max="${max}"` : ''}><span class="muted">${hint}</span></div>`;
    Modal.open({
      title: '⚙️ Ajustes do Planejamento',
      body: `<div class="plan-cfg">
        ${f('cfg-cob', 'Dias de cobertura', c.cobertura, 'para quantos dias de venda comprar', 1, 365)}
        ${f('cfg-praz', 'Prazo de reposição (dias)', c.prazo, 'quando marcar 🔴 Comprar agora', 0, 180)}
        ${f('cfg-par', 'Janela de "parado" (dias)', c.janelaParado, 'sem vender por N dias = parado', 1, 730)}
        ${f('cfg-min', 'Quantidade mínima de compra', c.minRec, 'nunca sugerir menos que isso', 1, 100)}
        <div class="plan-cfgf"><label>Ajustar pela tendência recente</label>
          <select id="cfg-tend"><option value="1" ${c.tendencia ? 'selected' : ''}>Sim — leva alta/queda em conta</option><option value="0" ${!c.tendencia ? 'selected' : ''}>Não — usa só a média</option></select>
          <span class="muted">ajuste moderado (±50%), evita exagero</span></div>
        <div class="plan-cfgf"><label>Período padrão de análise</label>
          <select id="cfg-per">${typeof periodOptsHtml === 'function' ? periodOptsHtml(c.periodo) : ''}</select>
          <span class="muted">período usado ao abrir a tela</span></div>
      </div>`,
      foot: `<button class="btn-ghost" onclick="Modal.close()">Cancelar</button><button class="btn-primary" onclick="Plan.saveCfg()">Salvar</button>`
    });
  },
  saveCfg() {
    const num = (id, d, min, max) => { let v = parseInt(fval(id), 10); if (isNaN(v)) v = d; if (min != null) v = Math.max(min, v); if (max != null) v = Math.min(max, v); return v; };
    const patch = {
      cobertura: num('cfg-cob', 30, 1, 365),
      prazo: num('cfg-praz', 7, 0, 180),
      janelaParado: num('cfg-par', 60, 1, 730),
      minRec: num('cfg-min', 1, 1, 100),
      tendencia: fval('cfg-tend') === '1',
      periodo: fval('cfg-per') || '30d'
    };
    this.setCfg(patch);
    this.st.periodo = patch.periodo;
    Modal.close(); Toast.ok('Ajustes salvos e sincronizados.'); this.render();
  },

  /* ---------- exportação ---------- */
  exportRows() {
    const D = this.data(), fin = this.canFin();
    const head = ['Status', 'Produto', 'SKU', 'Categoria', 'Estoque', 'Vendidas (período)', 'Média/dia', 'Dias p/ ruptura', 'Comprar']
      .concat(fin ? ['Custo médio', 'Preço', 'Investir', 'Faturamento pot.', 'Lucro pot.', 'Margem s/venda %', 'Margem s/custo %'] : [])
      .concat(['Última venda', 'Última entrada']);
    const aoa = [head];
    this.filtered(D).forEach(x => aoa.push([
      this._statusMeta[x.status].label, x.nome, x.sku || '', x.categoria, x.estoque, x.vendidas,
      +x.mediaDia.toFixed(3), x.diasRuptura === Infinity ? '' : Math.floor(x.diasRuptura), x.qtdRec
    ].concat(fin ? [+x.custoMedio.toFixed(2), +x.preco.toFixed(2), +x.investimento.toFixed(2), +x.faturamentoPot.toFixed(2), +x.lucroPot.toFixed(2), +x.margemV.toFixed(1), +x.margemC.toFixed(1)] : [])
      .concat([x.ultimaVenda ? Fmt.date(x.ultimaVenda) : '', x.ultimaEntrada ? Fmt.date(x.ultimaEntrada) : ''])));
    return { aoa, D };
  },
  exportXlsx() {
    const { aoa } = this.exportRows();
    if (typeof Exporter !== 'undefined' && Exporter.xlsx) Exporter.xlsx('planejamento-compras.xlsx', 'Planejamento', aoa);
  },
  exportPdf() {
    const { aoa, D } = this.exportRows(), t = D.totals, fin = this.canFin();
    const th = aoa[0].map(h => `<th>${esc(h)}</th>`).join('');
    const bd = aoa.slice(1).map(r => `<tr>${r.map(c => `<td class="${typeof c === 'number' ? 'num' : ''}">${esc(c)}</td>`).join('')}</tr>`).join('');
    const kpis = `<div class="kpis">
      <div class="k"><div class="l">🔴 Comprar agora</div><div class="v">${t.urgente}</div></div>
      <div class="k"><div class="l">🟠 Comprar em breve</div><div class="v">${t.breve}</div></div>
      <div class="k"><div class="l">🔵 Parados</div><div class="v">${t.parado}</div></div>
      ${fin ? `<div class="k"><div class="l">Investimento</div><div class="v">${Fmt.brl(t.investimento)}</div></div><div class="k"><div class="l">Lucro potencial</div><div class="v">${Fmt.brl(t.lucroPot)}</div></div>` : ''}</div>`;
    if (typeof Exporter !== 'undefined' && Exporter.pdf) Exporter.pdf('Planejamento de Compras · ' + t.label, `${kpis}<table><thead><tr>${th}</tr></thead><tbody>${bd}</tbody></table>`);
  },

  /* ---------- estilos ---------- */
  injectCss() {
    if (document.getElementById('plan-css')) return;
    const css = `
    #plan-root{display:flex;flex-direction:column;gap:12px}
    .plan-fbar{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-top:8px}
    .plan-fleft{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
    .plan-fbar select,.plan-fbar input{padding:8px 10px;border-radius:9px;border:1px solid var(--line);background:var(--bg-2);color:var(--txt);font-size:13px}
    .plan-flabel{font-size:12.5px;color:var(--txt-2)}
    .plan-views{display:flex;gap:6px;flex-wrap:wrap}
    .plan-view{padding:7px 13px;border-radius:9px;border:1px solid var(--line);background:var(--bg-2);color:var(--txt-2);font-size:13px;font-weight:600;cursor:pointer}
    .plan-view.on{background:var(--accent);border-color:var(--accent);color:#fff}
    .plan-dash{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
    .plan-dcard{background:var(--bg-2);border:1px solid var(--line);border-left-width:4px;border-radius:12px;padding:12px 14px;cursor:pointer;transition:.12s}
    .plan-dcard:hover{transform:translateY(-1px)}
    .plan-dcard.sel{box-shadow:0 0 0 2px var(--accent) inset}
    .plan-dcard.urg{border-left-color:#ef4444}.plan-dcard.brv{border-left-color:#f59e0b}.plan-dcard.ok{border-left-color:#22c55e}.plan-dcard.par{border-left-color:#3b82f6}
    .plan-dc-top{font-size:12px;font-weight:700;color:var(--txt-2);display:flex;gap:6px;align-items:center}
    .plan-dc-val{font-size:26px;font-weight:800;margin-top:4px}
    .plan-dc-sub{font-size:11px;color:var(--txt-3);margin-top:2px}
    .plan-money{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}
    .plan-mcard{background:var(--bg-2);border:1px solid var(--line);border-radius:12px;padding:12px 14px}
    .plan-mcard.inv{border-color:rgba(91,140,255,.4)}.plan-mcard.fat{border-color:rgba(168,85,247,.4)}.plan-mcard.luc{border-color:rgba(34,197,94,.4)}.plan-mcard.par{border-color:rgba(59,130,246,.4)}
    .plan-mc-l{font-size:11px;text-transform:uppercase;letter-spacing:.4px;color:var(--txt-3);font-weight:700}
    .plan-mc-v{font-size:20px;font-weight:800;margin-top:3px}
    .plan-badge{display:inline-flex;align-items:center;gap:4px;font-size:11.5px;font-weight:700;padding:3px 9px;border-radius:20px;white-space:nowrap}
    .plan-badge.urg{background:rgba(239,68,68,.16);color:#ef4444}.plan-badge.brv{background:rgba(245,158,11,.16);color:#d97706}.plan-badge.ok{background:rgba(34,197,94,.16);color:#16a34a}.plan-badge.par{background:rgba(59,130,246,.16);color:#3b82f6}
    .plan-plink{color:var(--accent);cursor:pointer;font-weight:700}
    .plan-rk-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px}
    .plan-rk-grid .card{margin:0}
    .plan-parw{background:rgba(59,130,246,.1);border:1px solid rgba(59,130,246,.3);border-radius:10px;padding:10px 12px;font-size:13px;margin-bottom:10px}
    .plan-reco{border-radius:10px;padding:11px 14px;font-size:14px;margin-bottom:10px}
    .plan-reco.go{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.4)}
    .plan-reco.hold{background:var(--bg-2);border:1px solid var(--line);color:var(--txt-2)}
    .plan-steps{margin:6px 0 8px;padding-left:20px;font-size:13px;color:var(--txt-2);display:flex;flex-direction:column;gap:4px}
    .plan-insuf{background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.35);border-radius:10px;padding:11px 13px;font-size:13px;color:var(--txt-2)}
    .plan-pv-read{margin-top:8px;font-size:12.5px;color:var(--txt-2);background:var(--bg-2);border-radius:8px;padding:9px 12px}
    .plan-an .ap-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:12px}
    .plan-sim-top{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-end}
    .plan-sim-qty{display:flex;flex-direction:column;gap:6px}
    .plan-sim-qty>span{font-size:12px;font-weight:700;color:var(--txt-2)}
    .plan-qstep{display:flex;align-items:center;gap:6px}
    .plan-qstep button{width:34px;height:34px;border-radius:8px;border:1px solid var(--line);background:var(--bg-2);color:var(--txt);font-size:18px;font-weight:700;cursor:pointer}
    .plan-qstep input{width:90px;text-align:center;padding:8px;border-radius:8px;border:1px solid var(--line);background:var(--bg-2);color:var(--txt);font-size:18px;font-weight:800}
    .plan-cfg{display:flex;flex-direction:column;gap:14px}
    .plan-cfgf{display:flex;flex-direction:column;gap:4px}
    .plan-cfgf label{font-size:13px;font-weight:700}
    .plan-cfgf input,.plan-cfgf select{padding:9px 11px;border-radius:9px;border:1px solid var(--line);background:var(--bg-2);color:var(--txt);font-size:14px}
    .plan-cfgf .muted{font-size:11.5px}
    `;
    const st = document.createElement('style'); st.id = 'plan-css'; st.textContent = css; document.head.appendChild(st);
  }
};

/* integração com o router: Modules.planejamento é o que o App.go() chama */
if (typeof Modules !== 'undefined') { Modules.planejamento = function () { return Plan.page(); }; }
