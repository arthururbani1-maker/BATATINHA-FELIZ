/* ============ RICO GAMES ERP — Configurações: Taxas e Pagamentos ============ */
const Taxas = {
  all() { return DB.all('taxas'); },
  get(key) { return DB.all('taxas').find(t => t.key === key); },
  ativas() { return this.all().filter(t => t.ativo !== false); },
  keyFor(tipo, parcelas) {
    if (tipo === 'Crédito') return (!parcelas || parcelas <= 1) ? 'Crédito à vista' : 'Crédito ' + parcelas + 'x';
    return tipo;
  },
  feeByKey(key, valor) {
    const t = this.get(key);
    if (!t || t.ativo === false) return 0;
    return Math.round(((valor || 0) * ((t.percent || 0) / 100) + (t.fixo || 0)) * 100) / 100;
  },
  fee(pag) { return this.feeByKey(this.keyFor(pag.tipo, pag.parcelas), pag.valor || 0); },
  feeVenda(v) { return (v.pagamentos || []).reduce((s, p) => s + (p.taxa != null ? p.taxa : this.fee(p)), 0); },
  isFinanceira(key) { const t = this.get(key); return !!(t && t.tipo === 'financeira'); },
  financeiras() { return this.ativas().filter(t => t.tipo === 'financeira'); }
};

const inStyle = 'background:var(--bg-2);border:1px solid var(--line);color:var(--txt);border-radius:8px;padding:7px 10px';

Modules.cfgState = { tab: 'taxas' };
Modules.config = function () {
  const tabs = [['taxas', '💳 Taxas'], ['cupom', '🧾 Cupom e Garantia'], ['impressora', '🖨️ Impressora'], ['importar', '📥 Importar Omie'], ['usuarios', '👤 Usuários'], ['permissoes', '🔒 Permissões'], ['nuvem', '☁️ Nuvem'], ['seguranca', '🛡️ Segurança']];
  setTimeout(() => Modules.cfgRenderTab(), 20);
  return `
  <div class="page-head"><div><h1>Configurações</h1><p>Ajustes do sistema</p></div></div>
  <div class="tabs" id="cfg-subnav">${tabs.map(t => `<div class="tab ${this.cfgState.tab === t[0] ? 'active' : ''}" onclick="Modules.cfgSetTab('${t[0]}')">${t[1]}</div>`).join('')}</div>
  <div id="cfg-body"></div>`;
};
Modules.cfgSetTab = function (t) {
  this.cfgState.tab = t;
  const keys = ['taxas', 'cupom', 'impressora', 'importar', 'usuarios', 'permissoes', 'nuvem', 'seguranca'];
  document.querySelectorAll('#cfg-subnav .tab').forEach((el, i) => el.classList.toggle('active', keys[i] === t));
  this.cfgRenderTab();
};
Modules.cfgRenderTab = function () {
  const b = document.getElementById('cfg-body'); if (!b) return;
  const t = this.cfgState.tab;
  b.innerHTML = t === 'taxas' ? this.cfgTaxasCard() : t === 'cupom' ? this.cfgCupomArea() : t === 'impressora' ? this.cfgImpressoraCard() : t === 'importar' ? this.cfgImportarCard() : t === 'usuarios' ? this.cfgUsuariosCard() : t === 'permissoes' ? this.cfgPermissoesCard() : t === 'nuvem' ? this.cfgCloudCard() : this.cfgSegurancaCard();
  if (t === 'cupom') this.cfgPreview();
};
Modules.cfgTaxasCard = function () {
  const t = Taxas.all();
  const extrasFC = ((DB.all('config')[0] || {}).formasCompra) || [];
  return `<div class="card">
    <div class="section-title">💳 Taxas e Pagamentos <a onclick="Modules.cfgAdd()">+ Forma de pagamento</a></div>
    <div class="table-wrap" style="border:none"><table>
      <thead><tr><th>Forma de pagamento</th><th>Tipo</th><th class="num">Taxa (%)</th><th class="num">Taxa fixa (R$)</th><th>Prazo / recebimento</th><th>Status</th><th></th></tr></thead>
      <tbody>${t.map(x => `<tr>
        <td class="strong">${esc(x.nome)}${x.tipo === 'financeira' && x.conta ? `<div class="muted" style="font-size:11px">conta: ${esc(x.conta)}</div>` : ''}</td>
        <td>${x.tipo === 'financeira' ? '<span class="badge b-purple">🏦 Financeira</span>' : '<span class="badge b-gray">💳 Maquininha</span>'}</td>
        <td class="num"><input type="number" step="0.01" value="${x.percent}" style="${inStyle};width:84px;text-align:right" onchange="Modules.cfgSet('${x.id}','percent',this.value)"></td>
        <td class="num"><input type="number" step="0.01" value="${x.fixo || 0}" style="${inStyle};width:84px;text-align:right" onchange="Modules.cfgSet('${x.id}','fixo',this.value)"></td>
        <td>${x.tipo === 'financeira'
          ? `<input type="number" value="${x.prazoDias || 0}" style="${inStyle};width:70px;text-align:right" onchange="Modules.cfgSet('${x.id}','prazoDias',this.value)"> <span class="muted" style="font-size:11px">dias</span>`
          : `<input value="${esc(x.prazo || '')}" style="${inStyle};width:130px" onchange="Modules.cfgSet('${x.id}','prazo',this.value)">`}</td>
        <td><label style="display:inline-flex;align-items:center;gap:7px;cursor:pointer;font-size:12.5px;color:var(--txt-2)"><input type="checkbox" ${x.ativo !== false ? 'checked' : ''} onchange="Modules.cfgSet('${x.id}','ativo',this.checked)"> ${x.ativo !== false ? 'Ativo' : 'Inativo'}</label></td>
        <td class="num">${x.custom ? `<button class="btn-icon" onclick="Modules.cfgDel('${x.id}')">🗑️</button>` : ''}</td>
      </tr>`).join('')}</tbody></table></div>
    <p class="muted" style="margin-top:14px;font-size:12px;line-height:1.6">💡 Maquininha (Crédito/Débito): a taxa é descontada do lucro na hora.<br>🏦 <b>Financeira / Boleto</b> (ex: Brasil Card): a venda vira <b>Conta a Receber</b> — o valor líquido entra no caixa só quando você marcar como recebido, após o prazo em dias.</p>
  </div>
  <div class="card" style="margin-top:16px">
    <div class="section-title">🚚 Formas de pagamento de compras <a onclick="Modules.cfgFormaCompraAdd()">+ Nova forma</a></div>
    <p class="muted" style="font-size:12px;margin-bottom:10px">Usadas na <b>Entrada de Estoque</b>. As padrão (Dinheiro, PIX, Débito, Crédito à vista, Crédito parcelado, Transferência, Boleto, Consórcio, Outro) já existem. Aqui você adiciona formas próprias.</p>
    <div style="display:flex;gap:6px;flex-wrap:wrap">${extrasFC.length ? extrasFC.map(f => `<span class="seg-chip">${esc(f)} <span onclick="Modules.cfgFormaCompraDel('${esc(f).replace(/'/g, "\\'")}')" style="color:var(--red);cursor:pointer">✕</span></span>`).join('') : '<span class="muted" style="font-size:12px">Nenhuma forma personalizada ainda.</span>'}</div>
  </div>`;
};
Modules.cfgFormaCompraAdd = function () {
  Modal.open({ title: 'Nova forma de pagamento (compras)', body: `<div class="field"><label>Nome da forma</label><input id="fc-nome" placeholder="Ex: Cartão BNDES, Cheque..."></div>`, foot: `<button class="btn-ghost" onclick="Modal.close()">Cancelar</button><button class="btn-primary" onclick="Modules.cfgFormaCompraSave()">Adicionar</button>` });
};
Modules.cfgFormaCompraSave = function () {
  const nome = (fval('fc-nome') || '').trim(); if (!nome) return Toast.err('Informe o nome da forma.');
  const cfg = DB.all('config')[0]; const list = ((cfg.formasCompra) || []).slice();
  if (list.indexOf(nome) < 0) list.push(nome);
  DB.update('config', cfg.id, { formasCompra: list }); Modal.close(); Toast.ok('Forma adicionada.'); this.cfgRenderTab();
};
Modules.cfgFormaCompraDel = function (nome) {
  const cfg = DB.all('config')[0]; const list = ((cfg.formasCompra) || []).filter(f => f !== nome);
  DB.update('config', cfg.id, { formasCompra: list }); Toast.ok('Forma removida.'); this.cfgRenderTab();
};

Modules.cfgImpressoraCard = function () {
  const p = (typeof Print !== 'undefined') ? Print.cfg() : { papel: '80', modo: 'ask', corte: true, gaveta: false, telefone: '', endereco: '', loja: 'Rico Games' };
  const opt = (v, val, lbl) => `<option value="${v}" ${val === v ? 'selected' : ''}>${lbl}</option>`;
  return `<div class="card">
    <div class="section-title">🖨️ Impressora <span class="muted" style="font-weight:500;font-size:12px">Cupom térmico (Elgin e compatíveis)</span></div>
    <p class="muted" style="margin-bottom:12px;font-size:12px">Os dados da loja e os campos do cupom ficam na aba <b>Cupom e Garantia</b>.</p>
    <div class="form-grid">
      <div class="field"><label>Largura do papel</label><select onchange="Modules.cfgPrintSet('papel',this.value)">${opt('80', p.papel, '80 mm (padrão)')}${opt('58', p.papel, '58 mm (compacta)')}</select></div>
      <div class="field"><label>Quando imprimir</label><select onchange="Modules.cfgPrintSet('modo',this.value)">${opt('auto', p.modo, 'Imprimir automaticamente após a venda')}${opt('ask', p.modo, 'Perguntar antes de imprimir')}${opt('off', p.modo, 'Não imprimir automaticamente')}</select></div>
      <div class="field"><label>Intensidade da impressão <span class="muted" style="font-weight:400;font-size:11px">letra mais escura</span></label><select onchange="Modules.cfgPrintSet('intensidade',this.value)">${opt('normal', p.intensidade || 'escura', 'Normal')}${opt('escura', p.intensidade || 'escura', 'Escura (recomendado)')}${opt('extra', p.intensidade || 'escura', 'Extra escura (negrito + maior)')}</select></div>
      <div class="field"><label>Corte automático</label><label style="display:inline-flex;align-items:center;gap:8px;padding-top:8px;font-size:13px;color:var(--txt-2)"><input type="checkbox" ${p.corte ? 'checked' : ''} onchange="Modules.cfgPrintSet('corte',this.checked)"> Cortar papel ao final</label></div>
      <div class="field"><label>Gaveta de dinheiro</label><label style="display:inline-flex;align-items:center;gap:8px;padding-top:8px;font-size:13px;color:var(--txt-2)"><input type="checkbox" ${p.gaveta ? 'checked' : ''} onchange="Modules.cfgPrintSet('gaveta',this.checked)"> Abrir gaveta automaticamente</label></div>
    </div>
    <div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap">
      <button class="btn-primary" onclick="Print.test()">🖨️ Testar impressão</button>
    </div>
    <p class="muted" style="margin-top:12px;font-size:12px;line-height:1.6">O cupom abre na janela de impressão do navegador — escolha a impressora <b>Elgin</b> (instalada no Windows/Mac) e marque para lembrar como padrão. Dica: nas opções do navegador, ajuste margens para "Nenhuma" e desmarque cabeçalho/rodapé para o cupom sair limpo. Corte e gaveta automáticos dependem do driver da Elgin instalado no computador.<br><br>🖨️ <b>Saiu fraco?</b> Use a <b>Intensidade "Escura"</b> ou "Extra escura" acima (deixa a letra em negrito, marca bem mais). Se ainda ficar fraco, aumente a <b>densidade/escurecimento no driver da Elgin</b> (Preferências de impressão → Densidade/Qualidade) e confira se o papel térmico é de boa qualidade.</p>
  </div>`;
};
Modules.cfgPrintSet = function (field, value) {
  const cfg = DB.all('config')[0];
  const imp = Object.assign({}, cfg.impressao || {});
  imp[field] = value;
  DB.update('config', cfg.id, { impressao: imp });
  Toast.ok('Configuração salva.');
};

Modules.cfgCloudCard = function () {
  const c = (typeof Cloud !== 'undefined' && Cloud.cfg()) || {};
  const on = (typeof Cloud !== 'undefined' && Cloud.configured());
  return `<div class="card" style="margin-top:18px">
    <div class="section-title">☁️ Sincronização na nuvem ${on ? '<span class="badge b-green">Conectado</span>' : '<span class="badge b-gray">Desconectado</span>'}</div>
    <p class="muted" style="margin-bottom:14px;line-height:1.6">Conecte um banco gratuito (Supabase) para que tudo o que o funcionário lançar apareça para você de qualquer lugar, em tempo real. Siga o arquivo <b>GUIA-NUVEM</b> para criar a conta e a tabela — leva uns 10 minutos.</p>
    <div class="form-grid">
      <div class="field full"><label>URL do projeto Supabase</label><input id="cl-url" value="${esc(c.url || '')}" placeholder="https://xxxxxxxx.supabase.co"></div>
      <div class="field full"><label>Chave pública (anon key)</label><input id="cl-key" value="${esc(c.key || '')}" placeholder="eyJhbGciOi..."></div>
    </div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px">
      <button class="btn-primary" onclick="Modules.cfgCloudSave()">${on ? 'Reconectar / testar' : 'Conectar e testar'}</button>
      ${on ? '<button class="btn-ghost" onclick="Modules.cfgCloudPush()">⬆️ Enviar dados agora</button><button class="btn-ghost" onclick="Modules.cfgCloudPull()">⬇️ Baixar da nuvem</button><button class="btn-danger" onclick="Modules.cfgCloudDisconnect()">Desconectar</button>' : ''}
    </div>
    <p class="muted" style="margin-top:12px;font-size:12px">⚠️ Conecte primeiro o computador principal (com seus dados) e só depois os outros aparelhos, para não sobrescrever nada.</p>
  </div>`;
};
Modules.cfgCloudSave = async function () {
  const url = fval('cl-url'), key = fval('cl-key');
  if (!url || !key) return Toast.err('Cole a URL e a chave do Supabase.');
  Cloud.setCfg(url, key);
  Toast.ok('Testando conexão…');
  const ok = await Cloud.test();
  if (!ok) { Toast.err('Não consegui conectar. Confira a URL, a chave e se a tabela "erp_state" foi criada (veja o GUIA-NUVEM).'); return; }
  await Cloud.initialSync(); Cloud.start();
  Toast.ok('Conectado à nuvem! Sincronização ativa.'); App.go('config');
};
Modules.cfgCloudDisconnect = function () {
  Modal.confirm('Desconectar da nuvem? O sistema volta a salvar apenas neste computador.', () => { Cloud.clear(); Toast.ok('Desconectado.'); App.go('config'); }, 'Desconectar');
};
Modules.cfgCloudPush = async function () { await Cloud.doPush(); Toast.ok('Dados enviados para a nuvem.'); };
Modules.cfgCloudPull = async function () { await Cloud.initialSync(); if (App.refresh) App.refresh(); Toast.ok('Dados baixados da nuvem.'); };

Modules.cfgSegurancaCard = function () {
  if (!App.isAdmin()) return `<div class="empty-state"><div class="big">🔒</div>Apenas administradores acessam esta área.</div>`;
  const logs = (DB.all('config')[0] || {}).resetLogs || [];
  const bk = (DB.backupInfo && DB.backupInfo()) || { has: false };
  return `<div class="card" style="margin-bottom:16px">
    <div class="section-title">💾 Backup e recuperação de dados</div>
    <p class="muted" style="line-height:1.6;margin-bottom:12px">Seus dados ficam salvos no aparelho (navegador) e espelhados na nuvem. Aqui você pode <b>baixar uma cópia de segurança</b> ou <b>restaurar o último backup automático</b> (criado sempre que a nuvem atualiza os dados).</p>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <button class="btn-primary" onclick="Modules.cfgBackupDownload()">⬇️ Baixar cópia de segurança (.json)</button>
      <button class="btn-ghost" onclick="document.getElementById('cfg-import-file').click()">📥 Importar cópia (.json) e mesclar</button>
      <input type="file" id="cfg-import-file" accept="application/json,.json" style="display:none" onchange="Modules.cfgImportFile(this)">
      <button class="btn-ghost" onclick="Modules.cfgRestoreBackup(1)" ${bk.has ? '' : 'disabled title="Nenhum backup automático ainda"'}>♻️ Recuperar backup 1${bk.at ? ' (' + Fmt.datetime(bk.at) + ')' : ''}</button>
      ${bk.has2 ? `<button class="btn-ghost" onclick="Modules.cfgRestoreBackup(2)">♻️ Recuperar backup 2${bk.at2 ? ' (' + Fmt.datetime(bk.at2) + ')' : ''}</button>` : ''}
      <button class="btn-ghost" onclick="Modules.cfgDiagnostico()">🔎 Diagnóstico de dados</button>
    </div>
    <p class="muted" style="font-size:12px;margin-top:8px">♻️ <b>Recuperar backup</b> e 📥 <b>Importar cópia</b> agora <b>mesclam</b> (só somam vendas/registros que faltam, sem apagar nada). Ideal para recuperar dados de outro PC ou de antes de uma perda.</p>
    <p class="muted" style="font-size:12px;margin-top:10px">Dica: baixe uma cópia periodicamente. Se algum dia notar dados sumindo, restaure o backup aqui antes de qualquer outra coisa.</p>
  </div>
  <div class="card" style="border:1px solid rgba(245,69,92,.45)">
    <div class="section-title" style="color:var(--red)">🛡️ Reset de Dados do Sistema</div>
    <div class="alert-card danger" style="margin-bottom:16px"><div class="a-ico">⚠️</div><div><div class="a-lbl" style="line-height:1.5">Esta ação apagará <b>todos os dados operacionais</b>: produtos, estoque, vendas, histórico, contas a pagar/receber, movimentações financeiras, caixa, compras, fornecedores, garantias, trocas, usados recebidos e relatórios.<br>A <b>estrutura</b> do ERP, temas, impressora, taxas, usuários e senhas <b>continuam intactos</b>. <b>Esta ação não pode ser desfeita.</b></div></div></div>
    <div class="form-grid">
      <div class="field"><label>Sua senha de administrador *</label><input id="rs-pass" type="password" autocomplete="off"></div>
      <div class="field"><label>Digite a frase: <b>RESETAR SISTEMA</b></label><input id="rs-frase" autocomplete="off" placeholder="RESETAR SISTEMA"></div>
    </div>
    <label style="display:flex;align-items:center;gap:9px;margin-top:14px;font-size:13px;color:var(--txt-2)"><input type="checkbox" id="rs-ok"> Entendo que esta ação é <b>irreversível</b> e apagará todos os dados operacionais.</label>
    <button class="btn-danger" style="margin-top:16px" onclick="Modules.cfgResetData()">🗑️ Resetar sistema (zerar dados)</button>
    ${logs.length ? `<div style="margin-top:18px"><div style="font-size:12.5px;font-weight:700;color:var(--txt-2);margin-bottom:8px">Histórico de resets</div>${logs.slice(0, 8).map(l => `<div class="mini-stat"><span>${Fmt.datetime(l.data)}</span><span>${esc(l.usuario)}</span></div>`).join('')}</div>` : ''}
  </div>`;
};
Modules.cfgDiagnostico = function () {
  const vendas = DB.all('vendas'), ativas = vendas.filter(v => !v.cancelada);
  const vids = new Set(vendas.map(v => v.id));
  // Vendas por dia (últimos 14 dias) — permite ver um dia com 0 vendas que deveria ter vendas
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
  const dias = [];
  for (let i = 0; i < 14; i++) { const d = new Date(hoje); d.setDate(d.getDate() - i); dias.push(d); }
  const byDay = {}; ativas.forEach(v => { const k = new Date(v.data).toISOString().slice(0, 10); byDay[k] = byDay[k] || { n: 0, tot: 0 }; byDay[k].n++; byDay[k].tot += v.total || 0; });
  const linhasDia = dias.map(d => { const k = d.toISOString().slice(0, 10); const x = byDay[k] || { n: 0, tot: 0 }; return `<tr><td>${Fmt.date(d)}</td><td class="num ${x.n === 0 ? 'muted' : 'strong'}">${x.n}</td><td class="num">${Fmt.brl(x.tot)}</td></tr>`; }).join('');
  // Órfãos: registros que apontam para uma venda que não existe mais (impressão digital de venda perdida)
  const orfFin = DB.all('financeiro').filter(f => f.origem === 'venda' && f.refId && !vids.has(f.refId));
  const orfMov = DB.all('movimentacoes').filter(m => m.tipo === 'venda' && m.refId && !vids.has(m.refId));
  const orfCx = DB.all('caixa').filter(c => c.refId && /venda/i.test(c.origem || c.tipo || '') && !vids.has(c.refId));
  const orfaos = orfFin.length + orfMov.length + orfCx.length;
  const ultima = ativas.length ? ativas.slice().sort((a, b) => new Date(b.data) - new Date(a.data))[0] : null;
  const sync = (typeof Cloud !== 'undefined') ? { rev: Cloud.rev ? Cloud.rev() : '?', dirty: Cloud.isDirty ? Cloud.isDirty() : false, conf: Cloud.configured ? Cloud.configured() : false } : { conf: false };
  const bk = (DB.backupInfo && DB.backupInfo()) || { has: false };
  Modal.open({
    title: '🔎 Diagnóstico de dados', wide: true,
    body: `
      <div class="grid kpis" style="margin-bottom:14px">
        ${kpi('Vendas', Fmt.num(ativas.length), vendas.length - ativas.length + ' cancelada(s)', '🧾', '')}
        ${kpi('Compras', Fmt.num(DB.all('compras').length), null, '🚚', '')}
        ${kpi('Lançamentos financeiros', Fmt.num(DB.all('financeiro').length), null, '💰', '')}
        ${kpi('Produtos', Fmt.num(DB.all('produtos').length), null, '📦', '')}
      </div>
      <div class="card ${orfaos ? '' : ''}" style="margin-bottom:14px;background:var(--bg-2);${orfaos ? 'border:1px solid var(--red)' : ''}">
        <div class="mini-stat"><span>${orfaos ? '🚨' : '✅'} Registros órfãos (vendas que sumiram mas deixaram rastro)</span><b style="color:${orfaos ? 'var(--red)' : 'var(--green)'}">${orfaos}</b></div>
        ${orfaos ? `<div class="muted" style="font-size:12px;margin-top:6px">Encontramos ${orfMov.length} movimentação(ões), ${orfFin.length} lançamento(s) financeiro(s) e ${orfCx.length} de caixa apontando para vendas que não existem mais. Isso indica vendas perdidas. Valores rastreados:</div>
          <div class="table-wrap" style="margin-top:8px"><table><thead><tr><th>Origem</th><th>Descrição</th><th>Data</th><th class="num">Valor</th></tr></thead><tbody>
          ${orfMov.slice(0, 20).map(m => `<tr><td>Movimentação</td><td>${esc(m.descricao || '')}</td><td>${Fmt.date(m.data)}</td><td class="num">${Fmt.brl((m.valor != null ? m.valor : (m.o && m.o.valor) || 0))}</td></tr>`).join('')}
          ${orfFin.slice(0, 20).map(f => `<tr><td>Financeiro</td><td>${esc(f.descricao || '')}</td><td>${Fmt.date(f.data || f.emissao)}</td><td class="num">${Fmt.brl(f.valor || 0)}</td></tr>`).join('')}
          </tbody></table></div>` : '<div class="muted" style="font-size:12px;margin-top:6px">Nenhum rastro de venda perdida encontrado. (Obs: se a nuvem sobrescreveu tudo de uma vez, não sobra rastro interno — confira também pelos cupons impressos e pelo Supabase.)</div>'}
      </div>
      <div class="grid cols-2" style="margin-bottom:0">
        <div class="card"><div class="section-title">Vendas por dia (14 dias)</div>
          <div class="table-wrap"><table><thead><tr><th>Dia</th><th class="num">Vendas</th><th class="num">Total</th></tr></thead><tbody>${linhasDia}</tbody></table></div>
          <div class="muted" style="font-size:12px;margin-top:6px">Última venda registrada: <b>${ultima ? Fmt.datetime(ultima.data) : '—'}</b>. Se um dia em que você vendeu aparece com <b>0</b>, houve perda naquele dia.</div></div>
        <div class="card"><div class="section-title">Sincronização e backup</div>
          <div class="mini-stat"><span>Nuvem configurada</span><b>${sync.conf ? 'Sim' : 'Não'}</b></div>
          <div class="mini-stat"><span>Versão de sincronização (rev)</span><b>${sync.rev}</b></div>
          <div class="mini-stat"><span>Alterações pendentes de envio</span><b style="color:${sync.dirty ? 'var(--amber)' : 'var(--green)'}">${sync.dirty ? 'Sim' : 'Não'}</b></div>
          <div class="mini-stat"><span>Último backup automático</span><b>${bk.at ? Fmt.datetime(bk.at) : '—'}</b></div>
          <div class="mini-stat"><span>Realtime ativo</span><b style="color:${(typeof Cloud !== 'undefined' && Cloud.realtimeOn) ? 'var(--green)' : 'var(--txt-2)'}">${(typeof Cloud !== 'undefined' && Cloud.realtimeOn) ? 'Sim' : 'Não (usando verificação a cada 3s)'}</b></div>
          <div class="mini-stat"><span>Situação da conexão</span><b style="color:${(typeof Cloud !== 'undefined' && Cloud._offline) ? 'var(--red)' : 'var(--green)'}">${(typeof Cloud !== 'undefined' && Cloud._offline) ? 'Sem conexão' : 'Conectado'}</b></div>
          <div style="margin-top:10px"><button class="btn-ghost btn-sm" onclick="Modules.cfgTestarNuvem()">🔌 Testar conexão com a nuvem</button></div>
          <div class="muted" style="font-size:12px;margin-top:8px">Para conferir a fundo: abra o Supabase → Table Editor → <b>erp_state</b> e veja a coluna <b>updated_at</b>.</div></div>
      </div>
      ${(typeof Cloud !== 'undefined' && Cloud.syncLog) ? `<div class="card" style="margin-top:14px"><div class="section-title">🧾 Log de sincronização (últimas operações)</div>
        <div class="table-wrap" style="max-height:220px;overflow:auto"><table><thead><tr><th>Data/Hora</th><th>Usuário</th><th>Operação</th><th>Resultado</th></tr></thead>
        <tbody>${(Cloud.syncLog().slice(0, 30).map(l => `<tr><td>${Fmt.datetime(l.t)}</td><td>${esc(l.u)}</td><td>${esc(l.op)}${l.msg ? ' <span class="muted">· ' + esc(l.msg) + '</span>' : ''}</td><td>${l.ok ? '<span class="badge b-green">OK</span>' : '<span class="badge b-red">Erro</span>'}</td></tr>`).join('')) || '<tr><td colspan="4" class="muted" style="text-align:center;padding:20px">Sem registros ainda.</td></tr>'}</tbody></table></div></div>` : ''}`,
    foot: `<button class="btn-ghost" onclick="Modal.close()">Fechar</button><button class="btn-primary" onclick="Modules.cfgBackupDownload()">⬇️ Baixar cópia agora</button>`
  });
};
Modules.cfgTestarNuvem = function () {
  if (typeof Cloud === 'undefined' || !Cloud.testDetailed) return Toast.err('Sincronização indisponível.');
  Toast.warn('Testando conexão com o Supabase…');
  Cloud.testDetailed().then(res => {
    if (res.ok) Toast.ok('✅ Conexão com a nuvem OK! As alterações na fila serão enviadas agora.');
    else Toast.err('❌ Falha ao conectar: ' + (res.msg || 'erro desconhecido') + '. Verifique a internet e se o projeto do Supabase não está pausado.');
  });
};
Modules.cfgBackupDownload = function () {
  try {
    const data = DB.exportJSON();
    const blob = new Blob([data], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = 'rico-games-backup-' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.json';
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 200);
    Toast.ok('Cópia de segurança baixada.');
  } catch (e) { Toast.err('Falha ao gerar o backup.'); }
};
Modules.cfgImportFile = function (input) {
  if (!App.isAdmin()) return Toast.err('Apenas administradores.');
  const file = input.files && input.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = function () {
    let obj; try { obj = JSON.parse(reader.result); } catch (e) { return Toast.err('Arquivo inválido (não é um backup .json válido).'); }
    if (!obj || (!obj.vendas && !obj.produtos)) return Toast.err('Este arquivo não parece um backup do Rico Games.');
    const antes = DB.recordCount();
    Modal.confirm('Importar e <b>mesclar</b> este arquivo? As vendas e registros que faltam serão adicionados (nada é apagado). Este aparelho tem ' + antes + ' registros hoje.', () => {
      const res = DB.mergeImport(obj);
      Toast.ok(res.added + ' registro(s) recuperado(s) e mesclado(s)! Sincronizando…');
      Modal.close(); setTimeout(() => location.reload(), 900);
    }, 'Importar e mesclar');
  };
  reader.readAsText(file); input.value = '';
};
Modules.cfgRestoreBackup = function (slot) {
  if (!App.isAdmin()) return Toast.err('Apenas administradores.');
  Modal.confirm('Recuperar o backup ' + (slot === 2 ? '2' : '1') + '? Ele será <b>mesclado</b> com os dados atuais — só adiciona vendas/registros que faltam, <b>nada é apagado</b>.', () => {
    const res = (DB.restoreBackup && DB.restoreBackup(slot)) || { ok: false };
    if (res.ok) { Toast.ok(res.added + ' registro(s) recuperado(s)! Recarregando...'); setTimeout(() => location.reload(), 900); }
    else Toast.err('Não há backup disponível nesse ponto.');
  }, 'Recuperar e mesclar');
};
Modules.cfgResetData = function () {
  if (!App.isAdmin()) return Toast.err('Apenas administradores podem resetar o sistema.');
  const pass = document.getElementById('rs-pass').value;
  const frase = fval('rs-frase');
  const me = DB.all('usuarios').find(u => u.usuario === (App.user() && App.user().usuario));
  if (!me || me.senha !== pass) return Toast.err('Senha de administrador incorreta.');
  if (frase !== 'RESETAR SISTEMA') return Toast.err('Digite exatamente: RESETAR SISTEMA');
  if (!fchk('rs-ok')) return Toast.err('Marque a confirmação de que entende que é irreversível.');
  Modal.confirm('Tem certeza ABSOLUTA? Todos os dados operacionais serão apagados agora e não poderão ser recuperados.', () => {
    const s = DB.state();
    ['produtos', 'vendas', 'compras', 'fornecedores', 'avaliacoes', 'trocas', 'prevendas', 'movimentacoes', 'garantias', 'financeiro', 'caixa', 'fechamentos', 'modelosUsados'].forEach(c => { if (Array.isArray(s[c])) s[c].length = 0; });
    s.config[0].resetLogs = s.config[0].resetLogs || [];
    s.config[0].resetLogs.unshift({ data: new Date().toISOString(), usuario: (App.user() && App.user().nome) || 'Admin' });
    DB.save();
    Modal.close();
    Toast.ok('Sistema resetado com sucesso.');
    App.go('dashboard');
  }, 'Resetar agora');
};

Modules.PERM_GROUPS = [
  { t: 'Dashboard', mods: [['dashboard', 'Visualizar Dashboard']], flags: [] },
  { t: 'PDV & Vendas', mods: [['pdv', 'Acessar PDV'], ['vendasDia', 'Ver Vendas do Dia'], ['caixa', 'Acessar Caixa']], flags: [['podeDesconto', 'Dar desconto no PDV'], ['podeAlterarPreco', 'Alterar preço na venda'], ['podeCancelar', 'Cancelar venda'], ['podeSangria', 'Sangria / retirada do caixa']] },
  { t: 'Estoque & Compras', mods: [['estoque', 'Acessar estoque'], ['entrada', 'Entrada de estoque'], ['compras', 'Acessar compras'], ['usados', 'Receber usado'], ['trocas', 'Trocas']], flags: [['podeEditarProduto', 'Cadastrar / editar produto'], ['podeExcluirProduto', 'Excluir produto']] },
  { t: 'Financeiro', mods: [['financeiro', 'Acessar Financeiro']], flags: [] },
  { t: 'Planejamento de Compras', mods: [['planejamento', 'Acessar Planejamento de Compras']], flags: [] },
  { t: 'Relatórios', mods: [['relatorios', 'Acessar Relatórios']], flags: [['verFinanceiro', 'Ver custo, lucro e margem']] },
  { t: 'Outros módulos', mods: [['prevendas', 'Pré-venda / Reservas'], ['movimentacoes', 'Movimentações'], ['garantias', 'Garantias']], flags: [] },
  { t: 'Configurações', mods: [['config', 'Acessar Configurações']], flags: [] }
];
Modules.permCount = function (u) { const p = u.permissoes || {}; let n = 0; this.PERM_GROUPS.forEach(g => { g.mods.forEach(m => { if (p.modules && p.modules[m[0]]) n++; }); g.flags.forEach(f => { if (p[f[0]]) n++; }); }); return n; };
Modules.cfgUsuariosCard = function () {
  if (!App.isAdmin()) return '<div class="card"><div class="empty-state"><div class="big">🔒</div>Apenas administradores podem gerenciar usuários e permissões.</div></div>';
  const us = DB.all('usuarios');
  return `<div class="card" style="margin-top:18px">
    <div class="section-title">👤 Usuários <a onclick="Modules.cfgUserAdd()">+ Novo usuário</a></div>
    <div class="usr-grid">${us.map(u => { const admin = u.role === 'admin', ativo = u.ativo !== false; return `<div class="usr-card">
      <div class="usr-h"><div class="usr-av">${esc((u.nome || '?').charAt(0).toUpperCase())}</div><div style="flex:1;min-width:0"><div class="usr-nome">${esc(u.nome)}</div><div class="usr-sub">${esc(u.usuario)}</div></div></div>
      <div class="usr-meta"><span class="badge ${admin ? 'b-purple' : 'b-blue'}">${admin ? 'Dono / Admin' : 'Funcionário'}</span><span class="badge ${ativo ? 'b-green' : 'b-gray'}">${ativo ? '● Ativo' : '○ Inativo'}</span></div>
      <div class="usr-perm">${admin ? '🔓 Acesso total ao sistema' : (this.permCount(u) + ' permissões ativas')}</div>
      <div class="usr-acts">
        ${admin ? '<button class="btn-ghost btn-sm" disabled>Acesso total</button>' : `<button class="btn-primary btn-sm" onclick="Modules.cfgUserPerms('${u.id}')">Gerenciar permissões</button>`}
        <button class="btn-ghost btn-sm" onclick="Modules.cfgUserPass('${u.id}')" title="Trocar senha">🔑</button>
        <label class="usr-tog"><input type="checkbox" ${ativo ? 'checked' : ''} ${u.id === 'u_admin' ? 'disabled' : ''} onchange="Modules.cfgUserToggle('${u.id}',this.checked)"> ativo</label>
        ${(u.id !== 'u_admin' && !admin) ? `<button class="btn-icon" title="Remover" onclick="Modules.cfgUserDel('${u.id}')">🗑️</button>` : ''}
      </div></div>`; }).join('')}</div>
    <p class="muted" style="margin-top:12px;font-size:12px">Cada usuário tem as <b>próprias</b> permissões — alterar um <b>não afeta</b> os outros. O administrador tem acesso total e não pode ser rebaixado por engano.</p>
  </div>`;
};
Modules.cfgUserPerms = function (id) {
  if (!App.isAdmin()) return Toast.err('Apenas administradores podem alterar permissões.');
  const u = DB.get('usuarios', id); if (!u) return;
  if (u.role === 'admin') return Toast.err('O administrador já tem acesso total.');
  const p = Object.assign({}, PERM_DEFAULT_FUNC, u.permissoes || {}, { modules: Object.assign({}, PERM_DEFAULT_FUNC.modules, (u.permissoes || {}).modules || {}) });
  const sw = (isMod, key, lbl) => { const val = isMod ? !!(p.modules && p.modules[key]) : !!p[key]; return `<label class="usr-sw"><input type="checkbox" ${val ? 'checked' : ''} onchange="Modules.cfgUserPermSet('${id}','${key}',this.checked,${isMod})"> <span>${esc(lbl)}</span></label>`; };
  const body = this.PERM_GROUPS.map(g => `<div class="usr-grp"><div class="usr-grp-t">${esc(g.t)}</div><div class="usr-sws">${g.mods.map(m => sw(true, m[0], m[1])).join('')}${g.flags.map(f => sw(false, f[0], f[1])).join('')}</div></div>`).join('');
  Modal.open({ title: '🔒 Permissões de ' + esc(u.nome), wide: true, body: `<p class="muted" style="margin-bottom:12px;font-size:12.5px">Ative só o que <b>${esc(u.nome)}</b> pode acessar e fazer. Salva na hora, <b>somente para este usuário</b>. Vale no próximo login dele (ou já, se estiver logado).</p>${body}`, foot: `<button class="btn-primary" onclick="Modal.close();App.go('config')">Concluir</button>` });
};
Modules.cfgUserPermSet = function (id, key, value, isModule) {
  if (!App.isAdmin()) return Toast.err('Apenas administradores podem alterar permissões.');
  const u = DB.get('usuarios', id); if (!u || u.role === 'admin') return;
  const perm = Object.assign({ modules: {} }, u.permissoes || {});
  perm.modules = Object.assign({}, (u.permissoes || {}).modules || {});
  if (isModule) perm.modules[key] = value; else perm[key] = value;
  DB.update('usuarios', id, { permissoes: perm });   // salva SÓ neste usuário
  const cur = App.user(); if (cur && cur.id === id) App.applyAccess();   // se for o próprio logado, reflete na hora
  Toast.ok('Permissões atualizadas com sucesso.');
};
Modules.cfgPermissoesCard = function () {
  if (!App.isAdmin()) return '<div class="card"><div class="empty-state"><div class="big">🔒</div>Apenas administradores.</div></div>';
  const us = DB.all('usuarios').filter(u => u.role !== 'admin');
  return `<div class="card" style="margin-top:18px">
    <div class="section-title">🔒 Permissões</div>
    <p class="muted" style="line-height:1.7;margin-bottom:12px">As permissões agora são <b>individuais por usuário</b> — cada um tem o próprio conjunto, e alterar um <b>não afeta</b> os outros. Gerencie no card de cada usuário.</p>
    ${us.length ? `<div class="usr-grid">${us.map(u => `<div class="usr-card"><div class="usr-h"><div class="usr-av">${esc((u.nome || '?').charAt(0).toUpperCase())}</div><div style="flex:1;min-width:0"><div class="usr-nome">${esc(u.nome)}</div><div class="usr-sub">${this.permCount(u)} permissões ativas</div></div></div><div class="usr-acts"><button class="btn-primary btn-sm" onclick="Modules.cfgUserPerms('${u.id}')">Gerenciar permissões</button></div></div>`).join('')}</div>` : '<p class="muted" style="font-size:12.5px">Nenhum funcionário cadastrado. Crie usuários na aba 👤 Usuários.</p>'}
    <button class="btn-ghost" style="margin-top:12px" onclick="Modules.cfgSetTab('usuarios')">Ir para Usuários</button></div>`;
};
Modules.cfgUserAdd = function () {
  if (!App.isAdmin()) return Toast.err('Apenas administradores podem criar usuários.');
  Modal.open({
    title: '+ Novo usuário',
    body: `<div class="form-grid">
      <div class="field full"><label>Nome *</label><input id="us-nome"></div>
      <div class="field"><label>Usuário (login) *</label><input id="us-user" autocomplete="off"></div>
      <div class="field"><label>Senha *</label><input id="us-pass"></div>
      <div class="field full"><label>Perfil</label><select id="us-role"><option value="funcionario">Funcionário (acesso restrito)</option><option value="admin">Dono / Admin (acesso total)</option></select></div>
    </div>`,
    foot: `<button class="btn-ghost" onclick="Modal.close()">Cancelar</button><button class="btn-primary" onclick="Modules.cfgUserSaveNew()">Criar usuário</button>`
  });
};
Modules.cfgUserSaveNew = function () {
  if (!App.isAdmin()) return Toast.err('Apenas administradores podem criar usuários.');
  const nome = fval('us-nome'), usuario = fval('us-user'), senha = fval('us-pass'), role = fval('us-role');
  if (!nome || !usuario || !senha) return Toast.err('Preencha nome, usuário e senha.');
  if (DB.all('usuarios').some(u => u.usuario.toLowerCase() === usuario.toLowerCase())) return Toast.err('Já existe um usuário com esse login.');
  // novo funcionário nasce com um conjunto PRÓPRIO de permissões (independente dos demais)
  const permissoes = role === 'admin' ? null : JSON.parse(JSON.stringify(PERM_DEFAULT_FUNC));
  DB.insert('usuarios', { nome, usuario, senha, role, ativo: true, permissoes });
  Modal.close(); Toast.ok('Usuário criado.'); App.go('config');
};
Modules.cfgUserPass = function (id) {
  const u = DB.get('usuarios', id);
  Modal.open({
    title: '🔑 Senha de ' + esc(u.nome),
    body: `<div class="field"><label>Nova senha</label><input id="us-newpass" value="${esc(u.senha)}"></div>`,
    foot: `<button class="btn-ghost" onclick="Modal.close()">Cancelar</button><button class="btn-primary" onclick="Modules.cfgUserSavePass('${id}')">Salvar</button>`
  });
};
Modules.cfgUserSavePass = function (id) {
  const s = fval('us-newpass'); if (!s) return Toast.err('Informe a senha.');
  DB.update('usuarios', id, { senha: s }); Modal.close(); Toast.ok('Senha atualizada.');
};
Modules.cfgUserToggle = function (id, ativo) {
  if (!App.isAdmin()) return Toast.err('Apenas administradores.');
  if (id === 'u_admin' && !ativo) return Toast.err('Não é possível desativar o administrador principal.');
  DB.update('usuarios', id, { ativo }); Toast.ok('Status atualizado.');
};
Modules.cfgUserDel = function (id) {
  if (!App.isAdmin()) return Toast.err('Apenas administradores podem remover usuários.');
  const u = DB.get('usuarios', id); if (u && u.role === 'admin' && DB.all('usuarios').filter(x => x.role === 'admin').length <= 1) return Toast.err('Não é possível remover o único administrador.');
  Modal.confirm('Remover este usuário?', () => { DB.remove('usuarios', id); App.go('config'); Toast.ok('Usuário removido.'); }, 'Remover');
};
Modules.cfgSet = function (id, field, value) {
  const patch = {};
  if (field === 'percent' || field === 'fixo') patch[field] = parseFloat(String(value).replace(',', '.')) || 0;
  else if (field === 'prazoDias') { patch.prazoDias = parseInt(value) || 0; patch.prazo = (patch.prazoDias || 0) + ' dias'; }
  else if (field === 'ativo') patch.ativo = value;
  else patch[field] = value;
  DB.update('taxas', id, patch);
  Toast.ok('Taxa atualizada.');
  if (field === 'ativo') App.go('config');
};
Modules.cfgAdd = function () {
  Modal.open({
    title: '+ Nova forma de pagamento',
    body: `<div class="form-grid">
      <div class="field"><label>Tipo</label><select id="cfg-tipo" onchange="Modules.cfgAddToggle()"><option value="maquininha">💳 Maquininha (recebe na hora)</option><option value="financeira">🏦 Boleto / Financeira (recebe depois)</option></select></div>
      <div class="field"><label>Nome *</label><input id="cfg-nome" placeholder="Ex: Brasil Card"></div>
      <div class="field"><label>Taxa (%)</label><input id="cfg-pct" type="number" step="0.01" value="0"></div>
      <div class="field"><label>Taxa fixa (R$)</label><input id="cfg-fixo" type="number" step="0.01" value="0"></div>
      <div class="field" id="cfg-prazo-wrap"><label>Prazo de recebimento</label><input id="cfg-prazo" placeholder="Ex: 30 dias"></div>
      <div class="field" id="cfg-prazod-wrap" style="display:none"><label>Prazo de recebimento (dias)</label><input id="cfg-prazod" type="number" value="7"></div>
      <div class="field full" id="cfg-conta-wrap" style="display:none"><label>Conta de recebimento</label><input id="cfg-conta" placeholder="Ex: Banco / conta onde o dinheiro cai"></div>
    </div>`,
    foot: `<button class="btn-ghost" onclick="Modal.close()">Cancelar</button><button class="btn-primary" onclick="Modules.cfgSaveNew()">Adicionar</button>`
  });
};
Modules.cfgAddToggle = function () {
  const fin = fval('cfg-tipo') === 'financeira';
  const show = (id, on) => { const e = document.getElementById(id); if (e) e.style.display = on ? '' : 'none'; };
  show('cfg-prazo-wrap', !fin); show('cfg-prazod-wrap', fin); show('cfg-conta-wrap', fin);
};
Modules.cfgSaveNew = function () {
  const nome = fval('cfg-nome'); if (!nome) return Toast.err('Informe o nome.');
  const tipo = fval('cfg-tipo') || 'maquininha';
  const o = { key: nome, nome, percent: fnum('cfg-pct'), fixo: fnum('cfg-fixo'), ativo: true, custom: true, tipo };
  if (tipo === 'financeira') { o.prazoDias = parseInt(fval('cfg-prazod')) || 0; o.conta = fval('cfg-conta'); o.prazo = (o.prazoDias || 0) + ' dias'; }
  else o.prazo = fval('cfg-prazo');
  DB.insert('taxas', o);
  Modal.close(); Toast.ok((tipo === 'financeira' ? 'Financeira' : 'Forma de pagamento') + ' adicionada.'); App.go('config');
};
Modules.cfgDel = function (id) {
  Modal.confirm('Remover esta forma de pagamento?', () => { DB.remove('taxas', id); App.go('config'); Toast.ok('Removida.'); }, 'Remover');
};
