/* ============ RICO GAMES ERP — Business Intelligence ============ */
const BI = {
  vendas() { return DB.all('vendas').filter(v => !v.cancelada); },
  prods() { return DB.all('produtos'); },
  prodInfo(sku) { return BI.prods().find(p => p.sku === sku); },
  agg(vendasList) {
    const vendas = vendasList || this.vendas();
    const m = {};
    vendas.forEach(v => { const seen = {}; v.itens.forEach(i => {
      const k = i.sku, p = this.prodInfo(k);
      m[k] = m[k] || { sku: k, nome: i.nome, categoria: i.categoria || (p ? p.categoria : '—'), condicao: i.condicao || (p ? p.condicao : 'novo'), qtd: 0, receita: 0, custo: 0, lucro: 0, orders: 0 };
      const custoU = (i.custo > 0) ? i.custo : (p ? (p.custoMedio || p.custo || 0) : 0); // fallback p/ vendas registradas com custo 0
      m[k].qtd += i.qtd; m[k].receita += i.preco * i.qtd; m[k].custo += custoU * i.qtd; m[k].lucro += (i.preco - custoU) * i.qtd;
      if (!seen[k]) { m[k].orders++; seen[k] = 1; }
    }); });
    return Object.values(m).map(x => { x.margemV = x.receita ? x.lucro / x.receita * 100 : 0; x.margemC = x.custo ? x.lucro / x.custo * 100 : 0; x.lucroUn = x.qtd ? x.lucro / x.qtd : 0; x.ticket = x.orders ? x.receita / x.orders : x.receita; return x; });
  },
  totals(vendasList) {
    const vendas = vendasList || this.vendas();
    const a = this.agg(vendas);
    const receita = a.reduce((s, x) => s + x.receita, 0), custo = a.reduce((s, x) => s + x.custo, 0);
    const lucro = receita - custo, qtd = a.reduce((s, x) => s + x.qtd, 0), nv = vendas.length;
    const taxas = (typeof Taxas !== 'undefined') ? vendas.reduce((s, v) => s + Taxas.feeVenda(v), 0) : 0;
    const estUnid = BI.prods().reduce((s, p) => s + p.qtd, 0);
    const lucroLiq = lucro - taxas;
    const usadosVend = vendas.reduce((s, v) => s + (v.itens || []).filter(i => (i.condicao || (BI.prodInfo(i.sku) || {}).condicao) === 'usado').reduce((ss, i) => ss + i.qtd, 0), 0);
    const recebidoFin = DB.all('financeiro').filter(f => f.financeira && f.origem === 'venda' && ((f.pago || 0) >= (f.valor || 0) - 0.01)).reduce((s, f) => s + (f.liquido != null ? f.liquido : (f.valor - (f.taxa || 0))), 0);
    return {
      receita, custo, lucro, taxas, liquido: receita - taxas, lucroLiq, qtd, nv, usadosVend, recebidoFin,
      ticket: nv ? receita / nv : 0,
      margemV: receita ? lucro / receita * 100 : 0, margemC: custo ? lucro / custo * 100 : 0,
      margemLiqV: receita ? lucroLiq / receita * 100 : 0, margemLiqC: custo ? lucroLiq / custo * 100 : 0,
      pctTaxas: receita ? taxas / receita * 100 : 0,
      giro: estUnid ? qtd / estUnid : qtd, estUnid, estValor: BI.prods().reduce((s, p) => s + (p.custoMedio || p.custo) * p.qtd, 0)
    };
  },
  lastSale() { const m = {}; this.vendas().forEach(v => v.itens.forEach(i => { const d = new Date(v.data); if (!m[i.sku] || d > m[i.sku]) m[i.sku] = d; })); return m; },
  crossSell(vendasList) {
    const ordersWith = {}, pairWith = {};
    (vendasList || this.vendas()).forEach(v => {
      const skus = [...new Set(v.itens.map(i => i.sku))];
      skus.forEach(a => { ordersWith[a] = (ordersWith[a] || 0) + 1; pairWith[a] = pairWith[a] || {}; skus.forEach(b => { if (a !== b) pairWith[a][b] = (pairWith[a][b] || 0) + 1; }); });
    });
    return Object.keys(pairWith).filter(a => Object.keys(pairWith[a]).length).map(a => ({
      sku: a, nome: (this.prodInfo(a) || {}).nome || a, orders: ordersWith[a],
      comps: Object.entries(pairWith[a]).map(([b, c]) => ({ sku: b, nome: (this.prodInfo(b) || {}).nome || b, count: c, per10: Math.round(c / ordersWith[a] * 10) })).sort((x, y) => y.count - x.count)
    })).sort((x, y) => y.orders - x.orders);
  },
  recomenda() {
    const a = this.agg(), ls = this.lastSale(), now = Date.now();
    const buy = [], stop = [];
    BI.prods().forEach(p => {
      const ag = a.find(x => x.sku === p.sku) || { qtd: 0, margemV: 0, lucro: 0 };
      const last = ls[p.sku], dias = last ? Math.round((now - last) / 86400000) : 999;
      const giro = p.qtd ? ag.qtd / p.qtd : ag.qtd;
      if (ag.qtd >= 2 && ag.margemV >= 18 && p.qtd <= p.min * 2) buy.push({ nome: p.nome, motivo: 'Gira rápido · margem ' + Fmt.pct(ag.margemV) + ' · estoque ' + p.qtd, score: giro * ag.margemV });
      if (p.qtd > 0 && (dias >= 60 || (ag.margemV < 12 && p.qtd > p.min))) stop.push({ nome: p.nome, motivo: dias >= 999 ? 'Nunca vendeu · ' + p.qtd + ' em estoque' : (dias >= 60 ? dias + ' dias sem vender' : 'Margem baixa ' + Fmt.pct(ag.margemV)), estoque: p.qtd });
    });
    return { buy: buy.sort((x, y) => y.score - x.score).slice(0, 6), stop: stop.slice(0, 6) };
  },
  range(periodo, de, ate) {
    const now = new Date(), s0 = d => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; }, e0 = d => { const x = new Date(d); x.setHours(23, 59, 59, 999); return x; };
    const dback = n => { const s = new Date(now); s.setDate(s.getDate() - (n - 1)); return { start: s0(s), end: e0(now) }; };
    if (periodo === 'hoje') return { start: s0(now), end: e0(now) };
    if (periodo === 'ontem') { const y = new Date(now); y.setDate(y.getDate() - 1); return { start: s0(y), end: e0(y) }; }
    if (periodo === '7d') return dback(7);
    if (periodo === '15d') return dback(15);
    if (periodo === '30d') return dback(30);
    if (periodo === '3m') { const s = new Date(now); s.setMonth(s.getMonth() - 3); return { start: s0(s), end: e0(now) }; }
    if (periodo === '6m') { const s = new Date(now); s.setMonth(s.getMonth() - 6); return { start: s0(s), end: e0(now) }; }
    if (periodo === '12m') { const s = new Date(now); s.setMonth(s.getMonth() - 12); return { start: s0(s), end: e0(now) }; }
    if (periodo === 'mes') return { start: s0(new Date(now.getFullYear(), now.getMonth(), 1)), end: e0(now) };
    if (periodo === 'mesAnterior') return { start: s0(new Date(now.getFullYear(), now.getMonth() - 1, 1)), end: e0(new Date(now.getFullYear(), now.getMonth(), 0)) };
    if (periodo === 'ano') return { start: s0(new Date(now.getFullYear(), 0, 1)), end: e0(now) };
    if (periodo === 'anoAnterior') return { start: s0(new Date(now.getFullYear() - 1, 0, 1)), end: e0(new Date(now.getFullYear() - 1, 11, 31)) };
    if (periodo === 'custom') return { start: de ? s0(new Date(de + 'T12:00:00')) : new Date(0), end: ate ? e0(new Date(ate + 'T12:00:00')) : e0(now) };
    return { start: new Date(0), end: e0(now) };
  },
  periodoLabel(periodo, r) {
    const nomes = { hoje: 'Hoje', ontem: 'Ontem', '7d': 'Últimos 7 dias', '15d': 'Últimos 15 dias', '30d': 'Últimos 30 dias', '3m': 'Últimos 3 meses', '6m': 'Últimos 6 meses', '12m': 'Últimos 12 meses', mes: 'Mês atual', mesAnterior: 'Mês anterior', ano: 'Ano atual', anoAnterior: 'Ano anterior', custom: 'Período personalizado', all: 'Todo o período' };
    const nome = nomes[periodo] || periodo;
    if (periodo === 'mes' || periodo === 'mesAnterior') { const m = r.start.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }); return m.charAt(0).toUpperCase() + m.slice(1); }
    if (periodo === 'ano' || periodo === 'anoAnterior') return String(r.start.getFullYear());
    const mesmoDia = Fmt.date(r.start) === Fmt.date(r.end);
    return (mesmoDia ? Fmt.date(r.start) : Fmt.date(r.start) + ' até ' + Fmt.date(r.end)) + ' (' + nome + ')';
  },
  vendasPeriodo(periodo, de, ate) { const r = this.range(periodo, de, ate); return this.vendas().filter(v => { const d = new Date(v.data); return d >= r.start && d <= r.end; }); },
};
function periodOptsHtml(sel) { return [['all', 'Todo o período'], ['hoje', 'Hoje'], ['ontem', 'Ontem'], ['7d', 'Últimos 7 dias'], ['15d', 'Últimos 15 dias'], ['30d', 'Últimos 30 dias'], ['mes', 'Mês atual'], ['mesAnterior', 'Mês anterior'], ['3m', 'Últimos 3 meses'], ['6m', 'Últimos 6 meses'], ['12m', 'Últimos 12 meses'], ['ano', 'Ano atual'], ['anoAnterior', 'Ano anterior'], ['custom', 'Período personalizado']].map(o => `<option value="${o[0]}" ${sel === o[0] ? 'selected' : ''}>${o[1]}</option>`).join(''); }

Modules.biState = { tab: 'geral', trend: 'dia', sel: [], periodo: '30d', de: '', ate: '' };
Modules.relatorios = function () {
  const tabs = [['geral', '📊 Visão geral'], ['analiseprod', '🔎 Análise de produto'], ['comparaprod', '⚖️ Análise de produtos'], ['giro', '🔁 Compras × Vendas'], ['simulador', '🧮 Simulador'], ['segmentos', '🧩 Segmentos'], ['pagamentos', '💳 Formas de pagamento'], ['compraspg', '🚚 Compras'], ['rankings', '🏆 Rankings'], ['pesquisa', '🔍 Pesquisa & comparação'], ['rentab', '💎 Rentabilidade']];
  const st = this.biState, r = BI.range(st.periodo, st.de, st.ate);
  setTimeout(() => Modules.biRender(), 20);
  return `
  <div class="page-head"><div><h1>Relatórios</h1><p>Business Intelligence · vendas, margem e rentabilidade</p></div>
    <div class="actions"><button class="btn-ghost" onclick="Modules.biExport('xlsx')">⬇️ Excel</button><button class="btn-ghost" onclick="Modules.biExport('pdf')">🖨️ PDF</button></div></div>
  <div class="bi-periodbar">
    <div class="bi-pb-left">
      <select id="bi-per" onchange="Modules.biPerChange()">${periodOptsHtml(st.periodo)}</select>
      <span id="bi-per-custom" style="display:${st.periodo === 'custom' ? 'inline-flex' : 'none'};gap:6px;align-items:center">
        <input type="date" id="bi-de" value="${st.de}"><span class="muted">até</span><input type="date" id="bi-ate" value="${st.ate}">
        <button class="btn-primary btn-sm" onclick="Modules.biPerApply()">Aplicar</button>
      </span>
      <button class="btn-ghost btn-sm" onclick="Modules.biPerClear()">Limpar filtros</button>
    </div>
    <div class="bi-pb-label">📅 Período analisado: <b id="bi-per-label">${esc(BI.periodoLabel(st.periodo, r))}</b></div>
  </div>
  <div class="tabs" id="bi-subnav">${tabs.map(t => `<div class="tab ${this.biState.tab === t[0] ? 'active' : ''}" onclick="Modules.biSetTab('${t[0]}')">${t[1]}</div>`).join('')}</div>
  <div id="bi-body"></div>`;
};
Modules.biPerChange = function () {
  const p = fval('bi-per') || '30d';
  this.biState.periodo = p;
  const cc = document.getElementById('bi-per-custom'); if (cc) cc.style.display = p === 'custom' ? 'inline-flex' : 'none';
  if (p !== 'custom') { this.biUpdateLabel(); this.biRender(); }
};
Modules.biPerApply = function () {
  this.biState.de = fval('bi-de'); this.biState.ate = fval('bi-ate'); this.biState.periodo = 'custom';
  this.biUpdateLabel(); this.biRender();
};
Modules.biPerClear = function () {
  this.biState.periodo = '30d'; this.biState.de = ''; this.biState.ate = '';
  const s = document.getElementById('bi-per'); if (s) s.value = '30d';
  const cc = document.getElementById('bi-per-custom'); if (cc) cc.style.display = 'none';
  this.biUpdateLabel(); this.biRender();
};
Modules.biUpdateLabel = function () {
  const st = this.biState, r = BI.range(st.periodo, st.de, st.ate);
  const el = document.getElementById('bi-per-label'); if (el) el.textContent = BI.periodoLabel(st.periodo, r);
};
Modules.biRangeCtx = function () {
  const st = this.biState, r = BI.range(st.periodo, st.de, st.ate);
  const vendas = BI.vendas().filter(v => { const d = new Date(v.data); return d >= r.start && d <= r.end; });
  const pr = BI.prevRange(r, st.periodo);
  const vprev = BI.vendas().filter(v => { const d = new Date(v.data); return d >= pr.start && d <= pr.end; });
  return { st, r, pr, vendas, vprev, label: BI.periodoLabel(st.periodo, r) };
};
Modules.biInit = function () { this.biRender(); };
Modules.biSetTab = function (t) {
  this.biState.tab = t;
  const keys = ['geral', 'analiseprod', 'comparaprod', 'giro', 'simulador', 'segmentos', 'pagamentos', 'compraspg', 'rankings', 'pesquisa', 'rentab'];
  document.querySelectorAll('#bi-subnav .tab').forEach((el, i) => el.classList.toggle('active', keys[i] === t));
  this.biRender();
};
Modules.biRender = function () {
  const b = document.getElementById('bi-body'); if (!b) return;
  const t = this.biState.tab;
  try {
    b.innerHTML = ({ geral: this.biGeral, analiseprod: this.biAnaliseProd, comparaprod: this.biMultiProd, giro: this.biGiro, simulador: this.biSimulador, segmentos: this.biSegmentos, pagamentos: this.biPagamentos, compraspg: this.biCompras, rankings: this.biRankings, pesquisa: this.biPesquisa, rentab: this.biRentab })[t].call(this);
    if (t === 'pesquisa') this.biCompara();
    if (t === 'simulador') this.simRecalc();
  } catch (e) {
    console.error('Erro ao gerar relatório', t, e);
    b.innerHTML = '<div class="empty-state"><div class="big">⚠️</div>Não foi possível gerar este relatório.<br><small style="color:var(--txt-3)">' + esc(String(e && e.message || e)) + '</small><br><button class="btn-ghost btn-sm" style="margin-top:12px" onclick="Modules.biSetTab(\'geral\')">← Voltar à Visão geral</button></div>';
  }
};

/* ---- helpers de UI ---- */
function biRankRows(items, valFn, subFn, rightFn) {
  const max = Math.max(1, ...items.map(valFn));
  return `<div class="bi-rank">${items.map((x, i) => `
    <div class="bi-row"><div class="bi-pos ${i < 3 ? 'top' : ''}">${i + 1}</div>
      <div class="bi-main"><div class="bi-name">${esc(x.nome)}</div><div class="bi-sub">${subFn(x)}</div>
        <div class="bi-bartrack"><div class="bi-barfill" style="width:${valFn(x) / max * 100}%"></div></div></div>
      <div class="strong" style="white-space:nowrap">${rightFn(x)}</div></div>`).join('')}</div>`;
}

/* ---- VISÃO GERAL ---- */
/* Gráfico de evolução adaptativo: por hora (<=2 dias), por dia (<=62 dias) ou por mês */
function biEvolChart(vendas, r) {
  const spanDays = (r.end - r.start) / 86400000;
  const gran = spanDays <= 2 ? 'hora' : (spanDays <= 62 ? 'dia' : 'mes');
  const keyOf = d => { const x = new Date(d); return gran === 'hora' ? `${x.getFullYear()}-${x.getMonth()}-${x.getDate()}-${x.getHours()}` : gran === 'dia' ? `${x.getFullYear()}-${x.getMonth()}-${x.getDate()}` : `${x.getFullYear()}-${x.getMonth()}`; };
  const list = [], cur = new Date(r.start);
  if (gran === 'hora') { cur.setMinutes(0, 0, 0); while (cur <= r.end && list.length < 60) { list.push({ key: keyOf(cur), val: 0, n: 0, label: cur.getHours() + 'h', full: Fmt.date(cur) + ' ' + cur.getHours() + 'h' }); cur.setHours(cur.getHours() + 1); } }
  else if (gran === 'dia') { cur.setHours(0, 0, 0, 0); while (cur <= r.end && list.length < 100) { list.push({ key: keyOf(cur), val: 0, n: 0, label: cur.getDate() + '/' + (cur.getMonth() + 1), full: Fmt.date(cur) }); cur.setDate(cur.getDate() + 1); } }
  else { cur.setDate(1); cur.setHours(0, 0, 0, 0); while (cur <= r.end && list.length < 36) { const ml = cur.toLocaleDateString('pt-BR', { month: 'short' }); list.push({ key: keyOf(cur), val: 0, n: 0, label: ml.replace('.', '') + '/' + String(cur.getFullYear()).slice(2), full: ml + '/' + cur.getFullYear() }); cur.setMonth(cur.getMonth() + 1); } }
  const map = {}; list.forEach(b => map[b.key] = b);
  vendas.forEach(v => { const b = map[keyOf(v.data)]; if (b) { b.val += v.total || 0; b.n++; } });
  const total = list.reduce((s, b) => s + b.val, 0);
  if (!total) return '<div class="muted" style="text-align:center;padding:34px 0">Sem vendas no período selecionado.</div>';
  const W = 720, H = 210, pl = 54, pr = 10, pt = 12, pb = 30;
  const max = Math.max(1, ...list.map(b => b.val));
  const bw = (W - pl - pr) / list.length;
  let grid = '';
  for (let i = 0; i <= 4; i++) { const val = max * i / 4, yy = pt + (1 - i / 4) * (H - pt - pb); grid += `<line x1="${pl}" y1="${yy}" x2="${W - pr}" y2="${yy}" stroke="var(--line,#2a2f3a)" stroke-width="1"/><text x="${pl - 6}" y="${yy + 3}" text-anchor="end" font-size="9.5" fill="var(--txt-2,#9aa3b2)">${Fmt.brl(val).replace('R$ ', '')}</text>`; }
  const every = Math.ceil(list.length / 14);
  const bars = list.map((b, i) => {
    const x = pl + i * bw, h = (b.val / max) * (H - pt - pb), y = H - pb - h;
    const lbl = (i % every === 0) ? `<text x="${x + bw / 2}" y="${H - 10}" text-anchor="middle" font-size="9.5" fill="var(--txt-2,#9aa3b2)">${b.label}</text>` : '';
    return `<rect x="${(x + bw * 0.12).toFixed(1)}" y="${y.toFixed(1)}" width="${(bw * 0.76).toFixed(1)}" height="${Math.max(0, h).toFixed(1)}" rx="2" fill="var(--accent,#5b8cff)"><title>${b.full}: ${Fmt.brl(b.val)} (${b.n} venda${b.n === 1 ? '' : 's'})</title></rect>${lbl}`;
  }).join('');
  const gtxt = gran === 'hora' ? 'por hora' : gran === 'dia' ? 'por dia' : 'por mês';
  return `<div class="muted" style="font-size:11.5px;margin-bottom:4px">Faturamento ${gtxt}</div><svg viewBox="0 0 ${W} ${H}" width="100%" preserveAspectRatio="xMidYMid meet">${grid}${bars}</svg>`;
}
Modules.biGeral = function () {
  const ctx = this.biRangeCtx();
  const T = BI.totals(ctx.vendas), P = BI.totals(ctx.vprev);
  const a = BI.agg(ctx.vendas);
  const topLucro = a.slice().sort((x, y) => y.lucro - x.lucro).slice(0, 5);
  const topFat = a.slice().sort((x, y) => y.receita - x.receita).slice(0, 5);
  const per = BI.periodoLabel(this.biState.periodo, ctx.r);
  const perAnt = (this.biState.periodo === 'all') ? '' : BI.periodoLabel('custom', ctx.pr);
  // comparação: retorna sub com variação (▲/▼ % e valor)
  const cmp = (cur, prev, money, inverteCor) => {
    if (this.biState.periodo === 'all') return per;
    if (!prev) return cur ? '<span class="up">novo</span> · ' + per : per;
    const d = (cur - prev) / Math.abs(prev) * 100, abs = cur - prev;
    const good = inverteCor ? d < 0 : d >= 0;
    return `<span class="${good ? 'up' : 'down'}">${d >= 0 ? '▲ +' : '▼ '}${Fmt.pct(Math.abs(d))}</span> · ant: ${money ? Fmt.brl(prev) : Fmt.num(prev)} (${abs >= 0 ? '+' : ''}${money ? Fmt.brl(abs) : Fmt.num(abs)})`;
  };
  return `
  <div class="bi-periodhead">📊 Indicadores do período: <b>${esc(per)}</b>${perAnt ? ` <span class="muted" style="font-weight:500">· comparando com o período anterior (${esc(perAnt)})</span>` : ''}</div>
  <div class="grid kpis" style="margin-bottom:16px">
    ${kpi('Faturamento bruto', Fmt.brl(T.receita), cmp(T.receita, P.receita, true), '💵', '')}
    ${kpi('Faturamento líquido', Fmt.brl(T.liquido), cmp(T.liquido, P.liquido, true), '🏦', 'blue')}
    ${kpi('Lucro bruto', Fmt.brl(T.lucro), cmp(T.lucro, P.lucro, true), '📈', '')}
    ${kpi('Lucro líquido', Fmt.brl(T.lucroLiq), cmp(T.lucroLiq, P.lucroLiq, true), '💎', 'purple')}
  </div>
  <div class="grid kpis" style="margin-bottom:16px">
    ${kpi('Total em taxas', Fmt.brl(T.taxas), Fmt.pct(T.pctTaxas) + ' do fat. · ' + cmp(T.taxas, P.taxas, true, true), '💳', 'red')}
    <div class="card kpi"><div class="kpi-ico">📐</div><div class="kpi-label">Margem sobre venda</div><div class="kpi-value">${Fmt.pct(T.margemV)}</div><div class="kpi-sub">líquida: ${Fmt.pct(T.margemLiqV)}</div></div>
    <div class="card kpi blue"><div class="kpi-ico">📐</div><div class="kpi-label">Margem sobre custo</div><div class="kpi-value">${Fmt.pct(T.margemC)}</div><div class="kpi-sub">líquida: ${Fmt.pct(T.margemLiqC)}</div></div>
    ${kpi('Ticket médio', Fmt.brl(T.ticket), cmp(T.ticket, P.ticket, true), '🎟️', '')}
  </div>
  <div class="grid kpis" style="margin-bottom:20px">
    ${kpi('Vendas realizadas', Fmt.num(T.nv), cmp(T.nv, P.nv, false), '🧾', 'amber')}
    ${kpi('Produtos vendidos', Fmt.num(T.qtd), cmp(T.qtd, P.qtd, false) + ' un', '📦', 'blue')}
    ${kpi('Usados vendidos', Fmt.num(T.usadosVend), cmp(T.usadosVend, P.usadosVend, false) + ' un', '🔄', '')}
    ${kpi('Custo dos produtos', Fmt.brl(T.custo), 'no período', '🏷️', '')}
  </div>
  <div class="card" style="margin-bottom:16px"><div class="section-title">📈 Evolução no período <span class="muted" style="font-weight:500">· ${esc(per)}</span></div>${biEvolChart(ctx.vendas, ctx.r)}</div>
  <div class="grid cols-2" style="margin-bottom:16px">
    <div class="card"><div class="section-title">💎 Top 5 em lucro <span class="muted" style="font-weight:500">· ${esc(per)}</span></div>${topLucro.length ? biRankRows(topLucro, x => x.lucro, x => x.qtd + ' un · ' + Fmt.pct(x.margemV) + ' margem', x => Fmt.brl(x.lucro)) : '<p class="muted">Sem vendas no período.</p>'}</div>
    <div class="card"><div class="section-title">💵 Top 5 em faturamento <span class="muted" style="font-weight:500">· ${esc(per)}</span></div>${topFat.length ? biRankRows(topFat, x => x.receita, x => x.qtd + ' un · ' + Fmt.pct(T.receita ? x.receita / T.receita * 100 : 0) + ' do total', x => Fmt.brl(x.receita)) : '<p class="muted">Sem vendas no período.</p>'}</div>
  </div>`;
};


/* ---- RANKINGS ---- */
Modules.biRankings = function () {
  const a = BI.agg(), T = BI.totals(), ls = BI.lastSale(), now = Date.now();
  const lucr = a.slice().sort((x, y) => y.lucro - x.lucro).slice(0, 10);
  const marg = a.slice().filter(x => x.receita > 0).sort((x, y) => y.margemV - x.margemV).slice(0, 10);
  const fat = a.slice().sort((x, y) => y.receita - x.receita).slice(0, 10);
  const fraco = BI.prods().map(p => {
    const ag = a.find(x => x.sku === p.sku) || { qtd: 0, margemV: 0, lucro: 0 };
    const last = ls[p.sku], dias = last ? Math.round((now - last) / 86400000) : null;
    return { nome: p.nome, qtd: ag.qtd, margemV: ag.margemV, estoque: p.qtd, dias, giro: p.qtd ? ag.qtd / p.qtd : ag.qtd };
  }).filter(x => x.estoque > 0).sort((x, y) => (x.giro - y.giro) || ((x.dias || 999) > (y.dias || 999) ? -1 : 1)).slice(0, 10);
  return `
  <div class="grid cols-2b" style="margin-bottom:16px">
    <div class="card"><div class="section-title">💎 Produtos mais lucrativos</div>
      <div class="table-wrap" style="border:none"><table><thead><tr><th>Produto</th><th class="num">Qtd</th><th class="num">Faturam.</th><th class="num">Lucro</th><th class="num">Margem</th></tr></thead>
      <tbody>${lucr.map(x => `<tr><td>${esc(x.nome)}</td><td class="num">${x.qtd}</td><td class="num">${Fmt.brl(x.receita)}</td><td class="num strong" style="color:var(--green)">${Fmt.brl(x.lucro)}</td><td class="num"><span class="badge b-green">${Fmt.pct(x.margemV)}</span></td></tr>`).join('')}</tbody></table></div></div>
    <div class="card"><div class="section-title">📐 Maior margem (%)</div>${biRankRows(marg, x => x.margemV, x => x.qtd + ' un · ' + Fmt.brl(x.lucro) + ' lucro', x => `<span class="badge b-green">${Fmt.pct(x.margemV)}</span>`)}</div>
  </div>
  <div class="grid cols-2b">
    <div class="card"><div class="section-title">💵 Maior faturamento</div>
      <div class="table-wrap" style="border:none"><table><thead><tr><th>Produto</th><th class="num">Qtd</th><th class="num">Receita</th><th class="num">% do total</th></tr></thead>
      <tbody>${fat.map(x => `<tr><td>${esc(x.nome)}</td><td class="num">${x.qtd}</td><td class="num strong">${Fmt.brl(x.receita)}</td><td class="num"><span class="badge b-blue">${Fmt.pct(x.receita / T.receita * 100)}</span></td></tr>`).join('')}</tbody></table></div></div>
    <div class="card"><div class="section-title">⚠️ Menor desempenho</div>
      <div class="table-wrap" style="border:none"><table><thead><tr><th>Produto</th><th class="num">Vend.</th><th class="num">Giro</th><th class="num">Estoque</th><th class="num">Sem venda</th></tr></thead>
      <tbody>${fraco.map(x => `<tr><td>${esc(x.nome)}</td><td class="num">${x.qtd}</td><td class="num">${x.giro.toFixed(1)}x</td><td class="num">${x.estoque}</td><td class="num">${x.dias == null ? '<span class="badge b-red">nunca</span>' : x.dias + 'd'}</td></tr>`).join('')}</tbody></table></div></div>
  </div>`;
};

/* ---- PESQUISA & COMPARAÇÃO ---- */
Modules.biPesquisa = function () {
  const prods = BI.prods().slice().sort((a, b) => a.nome.localeCompare(b.nome));
  return `
  <div class="grid cols-2" style="margin-bottom:16px">
    <div class="card"><div class="section-title">Selecione os produtos para comparar</div>
      <input id="bi-pq" placeholder="Filtrar lista..." oninput="Modules.biPickFilter()" style="width:100%;background:var(--bg-2);border:1px solid var(--line);color:var(--txt);padding:9px 12px;border-radius:9px;margin-bottom:10px">
      <div class="picker" id="bi-picker">${prods.map(p => `<label data-nome="${esc(p.nome.toLowerCase())}"><input type="checkbox" value="${p.sku}" ${Modules.biState.sel.includes(p.sku) ? 'checked' : ''} onchange="Modules.biToggle('${p.sku}')"> ${esc(p.nome)} <span class="muted" style="margin-left:auto;font-size:11px">${p.sku}</span></label>`).join('')}</div>
    </div>
    <div class="card"><div class="section-title">Resumo da seleção</div><div id="bi-cmp-sum"></div></div>
  </div>
  <div id="bi-cmp-table"></div>`;
};
Modules.biPickFilter = function () { const q = (fval('bi-pq') || '').toLowerCase(); document.querySelectorAll('#bi-picker label').forEach(l => l.style.display = l.dataset.nome.includes(q) ? 'flex' : 'none'); };
Modules.biToggle = function (sku) { const s = this.biState.sel; const i = s.indexOf(sku); if (i >= 0) s.splice(i, 1); else s.push(sku); this.biCompara(); };
Modules.biCompara = function () {
  const sel = this.biState.sel, a = BI.agg();
  const rows = sel.map(sku => a.find(x => x.sku === sku) || { sku, nome: (BI.prodInfo(sku) || {}).nome || sku, qtd: 0, receita: 0, custo: 0, lucro: 0, margemV: 0, margemC: 0 });
  const sumEl = document.getElementById('bi-cmp-sum'), tblEl = document.getElementById('bi-cmp-table');
  if (!sumEl) return;
  if (!rows.length) { sumEl.innerHTML = '<p class="muted">Marque produtos na lista ao lado para ver as métricas e comparar.</p>'; tblEl.innerHTML = ''; return; }
  const tot = rows.reduce((s, x) => ({ qtd: s.qtd + x.qtd, receita: s.receita + x.receita, custo: s.custo + x.custo, lucro: s.lucro + x.lucro }), { qtd: 0, receita: 0, custo: 0, lucro: 0 });
  sumEl.innerHTML = `<div class="mini-stat"><span>Produtos selecionados</span><b>${rows.length}</b></div>
    <div class="mini-stat"><span>Qtd vendida</span><b>${tot.qtd}</b></div>
    <div class="mini-stat"><span>Receita</span><b>${Fmt.brl(tot.receita)}</b></div>
    <div class="mini-stat"><span>Lucro</span><b style="color:var(--green)">${Fmt.brl(tot.lucro)}</b></div>
    <div class="mini-stat"><span>Margem s/ venda</span><b>${Fmt.pct(tot.receita ? tot.lucro / tot.receita * 100 : 0)}</b></div>
    <div class="mini-stat"><span>Margem s/ custo</span><b>${Fmt.pct(tot.custo ? tot.lucro / tot.custo * 100 : 0)}</b></div>`;
  tblEl.innerHTML = `<div class="table-wrap"><table><thead><tr><th>Produto</th><th class="num">Qtd</th><th class="num">Receita</th><th class="num">Custo</th><th class="num">Lucro</th><th class="num">Marg. venda</th><th class="num">Marg. custo</th><th class="num">Ticket médio</th></tr></thead>
    <tbody>${rows.map(x => `<tr><td class="strong">${esc(x.nome)}</td><td class="num">${x.qtd}</td><td class="num">${Fmt.brl(x.receita)}</td><td class="num muted">${Fmt.brl(x.custo)}</td><td class="num" style="color:var(--green)">${Fmt.brl(x.lucro)}</td><td class="num">${Fmt.pct(x.margemV)}</td><td class="num">${Fmt.pct(x.margemC)}</td><td class="num">${Fmt.brl(x.qtd ? x.receita / x.qtd : 0)}</td></tr>`).join('')}</tbody></table></div>`;
};



/* ---- RENTABILIDADE ---- */
Modules.biRentab = function () {
  const a = BI.agg();
  const porUnid = a.slice().filter(x => x.qtd > 0).sort((x, y) => y.lucroUn - x.lucroUn).slice(0, 10);
  const acum = a.slice().sort((x, y) => y.lucro - x.lucro).slice(0, 10);
  const roi = BI.prods().map(p => {
    const ag = a.find(x => x.sku === p.sku) || { lucro: 0, custo: 0 };
    const invest = (p.custoMedio || p.custo) * p.qtd;
    return { nome: p.nome, lucro: ag.lucro, invest, roi: invest ? ag.lucro / invest * 100 : (ag.lucro > 0 ? 999 : 0), roiCusto: ag.custo ? ag.lucro / ag.custo * 100 : 0 };
  }).filter(x => x.invest > 0).sort((x, y) => y.roi - x.roi).slice(0, 10);
  return `
  <div class="card" style="margin-bottom:16px"><div class="section-title">💡 O mais vendido nem sempre é o mais lucrativo</div>
    <p class="muted">Compare o lucro acumulado (volume) com o lucro por unidade (eficiência). Produtos de baixo volume e alta margem podem render mais que campeões de venda.</p></div>
  <div class="grid cols-2b" style="margin-bottom:16px">
    <div class="card"><div class="section-title">Lucro acumulado</div>${biRankRows(acum, x => x.lucro, x => x.qtd + ' un vendidas', x => Fmt.brl(x.lucro))}</div>
    <div class="card"><div class="section-title">Lucro por unidade</div>${biRankRows(porUnid, x => x.lucroUn, x => x.qtd + ' un · margem ' + Fmt.pct(x.margemV), x => Fmt.brl(x.lucroUn))}</div>
  </div>
  <div class="card"><div class="section-title">ROI sobre estoque (retorno do capital investido)</div>
    <div class="table-wrap" style="border:none"><table><thead><tr><th>Produto</th><th class="num">Lucro gerado</th><th class="num">Capital em estoque</th><th class="num">ROI</th></tr></thead>
    <tbody>${roi.map(x => `<tr><td>${esc(x.nome)}</td><td class="num" style="color:var(--green)">${Fmt.brl(x.lucro)}</td><td class="num muted">${Fmt.brl(x.invest)}</td><td class="num"><span class="badge ${x.roi >= 100 ? 'b-green' : 'b-amber'}">${x.roi >= 999 ? '∞' : Fmt.pct(x.roi)}</span></td></tr>`).join('')}</tbody></table></div></div>`;
};


/* ---- EXPORT ---- */
Modules.biExport = function (fmt) {
  const ctx = this.biRangeCtx();
  const T = BI.totals(ctx.vendas), a = BI.agg(ctx.vendas).slice().sort((x, y) => y.lucro - x.lucro), r2 = x => Math.round(x * 100) / 100;
  const _perLabel = ctx.label;
  if (fmt === 'xlsx') {
    const aoa = [
      ['Rico Games — Relatório de Business Intelligence'], ['Período analisado', _perLabel], ['Gerado em', Fmt.date(new Date())], [],
      ['INDICADORES'], ['Faturamento bruto', r2(T.receita)], ['Taxas de pagamento', r2(T.taxas)], ['Faturamento líquido', r2(T.liquido)], ['Custo dos produtos', r2(T.custo)], ['Lucro bruto', r2(T.lucro)], ['Lucro líquido', r2(T.lucroLiq)],
      ['Margem bruta s/ venda (%)', r2(T.margemV)], ['Margem líquida s/ venda (%)', r2(T.margemLiqV)], ['Margem bruta s/ custo (%)', r2(T.margemC)], ['Margem líquida s/ custo (%)', r2(T.margemLiqC)], ['% taxas sobre faturamento', r2(T.pctTaxas)], ['Ticket médio', r2(T.ticket)], ['Produtos vendidos', T.qtd], ['Vendas', T.nv], ['Giro de estoque', r2(T.giro)], [],
      ['PRODUTOS', 'Categoria', 'Condição', 'Qtd', 'Receita', 'Custo', 'Lucro', 'Margem venda %', 'Margem custo %']
    ];
    a.forEach(x => aoa.push([x.nome, x.categoria, x.condicao, x.qtd, r2(x.receita), r2(x.custo), r2(x.lucro), r2(x.margemV), r2(x.margemC)]));
    Exporter.xlsx('bi-rico-games-' + new Date().toISOString().slice(0, 10) + '.xlsx', 'BI', aoa);
  } else {
    const kp = (l, v) => `<div class="k"><div class="l">${l}</div><div class="v">${v}</div></div>`;
    const kpis = `<div class="kpis">${kp('Faturamento', Fmt.brl(T.receita))}${kp('Lucro bruto', Fmt.brl(T.lucro))}${kp('Lucro líquido', Fmt.brl(T.lucroLiq))}${kp('Margem venda', Fmt.pct(T.margemV))}${kp('Margem custo', Fmt.pct(T.margemC))}${kp('Ticket médio', Fmt.brl(T.ticket))}${kp('Giro', T.giro.toFixed(2) + 'x')}</div>`;
    const rows = a.slice(0, 30).map(x => `<tr><td>${esc(x.nome)}</td><td>${esc(x.categoria)}</td><td class="num">${x.qtd}</td><td class="num">${Fmt.brl(x.receita)}</td><td class="num">${Fmt.brl(x.lucro)}</td><td class="num">${Fmt.pct(x.margemV)}</td></tr>`).join('');
    Exporter.pdf('Business Intelligence · ' + _perLabel, kpis + `<table><thead><tr><th>Produto</th><th>Categoria</th><th class="num">Qtd</th><th class="num">Receita</th><th class="num">Lucro</th><th class="num">Margem</th></tr></thead><tbody>${rows}</tbody></table>`);
  }
};

/* ============ ANÁLISE POR FORMA DE PAGAMENTO ============ */
BI.payKey = function (tipo, parcelas) {
  if (tipo === 'Crédito') return (!parcelas || parcelas <= 1) ? 'Crédito à vista' : 'Crédito ' + parcelas + 'x';
  return tipo; // PIX, Dinheiro, Débito ou outra forma
};
BI.payOrder = ['PIX', 'Dinheiro', 'Débito', 'Crédito à vista', 'Produto usado'];
/* fração (0..1) do valor da venda que corresponde aos filtros de produto/categoria/condição */
BI.payFrac = function (cat, prod, cond) {
  if (!cat && !prod && !cond) return null;
  return v => {
    const base = (v.itens || []).reduce((s, i) => s + i.preco * i.qtd, 0);
    if (!base) return 0;
    const matched = (v.itens || []).filter(i => {
      const p = BI.prodInfo(i.sku) || {};
      const c = i.categoria || p.categoria, cd = i.condicao || p.condicao;
      if (cat && c !== cat) return false;
      if (cond && cd !== cond) return false;
      if (prod && i.sku !== prod) return false;
      return true;
    }).reduce((s, i) => s + i.preco * i.qtd, 0);
    return matched / base;
  };
};
BI.vendaCusto = function (v) {
  return (v.itens || []).reduce((s, i) => { const cu = (i.custo > 0) ? i.custo : ((BI.prodInfo(i.sku) || {}).custoMedio || (BI.prodInfo(i.sku) || {}).custo || 0); return s + cu * i.qtd; }, 0);
};
BI.payAgg = function (vendas, fracFn) {
  const m = {}, ensure = k => (m[k] = m[k] || { key: k, nome: k, vendas: 0, valor: 0, taxa: 0, lucro: 0 });
  let totFat = 0, totVendas = 0, totCusto = 0;
  vendas.forEach(v => {
    const frac = fracFn ? fracFn(v) : 1;
    if (frac <= 0) return;
    totVendas++;
    const vTotal = (v.total || 0);
    const custoV = BI.vendaCusto(v);
    const lucroBrutoV = vTotal - custoV; // lucro antes das taxas
    const usadoVal = ((v.usadoValor != null ? v.usadoValor : (v.usados ? v.usados.reduce((s, u) => s + (u.valor || 0), 0) : 0)) || 0) * frac;
    const paysSum = (v.pagamentos || []).reduce((s, p) => s + (p.valor || 0), 0);
    const recebido = v.recebido != null ? v.recebido : paysSum;
    const aPagar = v.aPagar != null ? v.aPagar : Math.max(0, vTotal - (usadoVal / (frac || 1)));
    let trocoRest = v.troco != null ? v.troco : Math.max(0, recebido - aPagar); // troco abatido só do dinheiro
    const used = {};
    const shareLucro = (val) => vTotal ? lucroBrutoV * (val / (vTotal * frac || 1)) : 0; // lucro proporcional ao valor da forma
    (v.pagamentos || []).forEach(p => {
      let val = p.valor || 0;
      if (p.tipo === 'Dinheiro' && trocoRest > 0) { const cut = Math.min(val, trocoRest); val -= cut; trocoRest -= cut; }
      val *= frac;
      if (val <= 0.009) return;
      const k = BI.payKey(p.tipo, p.parcelas); ensure(k);
      const taxa = (p.taxa != null ? p.taxa : (typeof Taxas !== 'undefined' ? Taxas.fee(p) : 0)) * frac;
      m[k].valor += val; m[k].taxa += taxa; m[k].lucro += shareLucro(val) - taxa;
      used[k] = 1;
    });
    if (usadoVal > 0.009) { ensure('Produto usado'); m['Produto usado'].valor += usadoVal; m['Produto usado'].lucro += shareLucro(usadoVal); used['Produto usado'] = 1; }
    Object.keys(used).forEach(k => m[k].vendas++);
    totFat += vTotal * frac; totCusto += custoV * frac;
  });
  const list = Object.values(m).sort((a, b) => {
    const ia = BI.payOrder.indexOf(a.key), ib = BI.payOrder.indexOf(b.key);
    return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
  });
  list.forEach(x => { x.liquido = x.valor - x.taxa; x.pctFat = totFat ? x.valor / totFat * 100 : 0; x.pctQtd = totVendas ? x.vendas / totVendas * 100 : 0; x.taxaMedia = x.valor ? x.taxa / x.valor * 100 : 0; x.ticket = x.vendas ? x.valor / x.vendas : 0; });
  return { list, totFat, totVendas, totCusto, totTaxa: list.reduce((s, x) => s + x.taxa, 0), totLiq: list.reduce((s, x) => s + x.liquido, 0), totLucro: list.reduce((s, x) => s + x.lucro, 0) };
};
/* taxa de cartão de referência (para estimar economia de PIX/Dinheiro) */
BI.refCardRate = function () {
  if (typeof Taxas === 'undefined') return 0;
  const cv = Taxas.get('Crédito à vista');
  if (cv && cv.percent) return cv.percent;
  const cards = Taxas.ativas().filter(t => /Crédito|Débito/.test(t.key));
  return cards.length ? cards.reduce((s, t) => s + (t.percent || 0), 0) / cards.length : 0;
};
BI.prevRange = function (r, per) {
  if (per === 'mes') { const s = r.start; return { start: new Date(s.getFullYear(), s.getMonth() - 1, 1), end: new Date(s.getFullYear(), s.getMonth(), 0, 23, 59, 59, 999) }; }
  if (per === 'ano') { const s = r.start; return { start: new Date(s.getFullYear() - 1, 0, 1), end: new Date(s.getFullYear() - 1, 11, 31, 23, 59, 59, 999) }; }
  const dur = r.end - r.start, end = new Date(r.start.getTime() - 1), start = new Date(end.getTime() - dur);
  return { start, end };
};

function payColor(k) {
  const map = { 'PIX': '#22c55e', 'Dinheiro': '#0ea5e9', 'Débito': '#6366f1', 'Crédito à vista': '#f59e0b', 'Produto usado': '#a855f7' };
  if (map[k]) return map[k];
  if (/^Crédito/.test(k)) return '#ef4444'; // parcelado (qualquer Nx)
  return '#94a3b8';
}
function biDonut(slices, total, centerLabel) {
  const active = slices.filter(s => s.value > 0);
  if (!total || !active.length) return '<div class="muted" style="text-align:center;padding:40px 0">Sem dados no período.</div>';
  const cx = 110, cy = 110, R = 92, r = 58; let acc = 0, body = '';
  if (active.length === 1) {
    body = `<circle cx="${cx}" cy="${cy}" r="${(R + r) / 2}" fill="none" stroke="${active[0].color}" stroke-width="${R - r}"/>`;
  } else {
    body = active.map(s => {
      const frac = s.value / total, a0 = acc * 2 * Math.PI - Math.PI / 2; acc += frac; const a1 = acc * 2 * Math.PI - Math.PI / 2, large = frac > 0.5 ? 1 : 0;
      const X = (rad, a) => [cx + rad * Math.cos(a), cy + rad * Math.sin(a)];
      const [x0, y0] = X(R, a0), [x1, y1] = X(R, a1), [xi1, yi1] = X(r, a1), [xi0, yi0] = X(r, a0);
      return `<path d="M${x0.toFixed(2)} ${y0.toFixed(2)} A${R} ${R} 0 ${large} 1 ${x1.toFixed(2)} ${y1.toFixed(2)} L${xi1.toFixed(2)} ${yi1.toFixed(2)} A${r} ${r} 0 ${large} 0 ${xi0.toFixed(2)} ${yi0.toFixed(2)} Z" fill="${s.color}"/>`;
    }).join('');
  }
  return `<svg viewBox="0 0 220 220" width="220" height="220" style="max-width:100%;display:block;margin:0 auto">${body}<text x="${cx}" y="${cy - 2}" text-anchor="middle" font-size="14" font-weight="800" fill="var(--txt)">${esc(centerLabel)}</text><text x="${cx}" y="${cy + 16}" text-anchor="middle" font-size="11" fill="var(--txt-2)">total</text></svg>`;
}

Modules.biPagState = { chart: 'fat' };
Modules.biPagamentos = function () {
  const cats = DB.all('categorias').map(c => c.nome);
  const prods = BI.prods().slice().sort((a, b) => a.nome.localeCompare(b.nome));
  setTimeout(() => Modules.biPagRender(), 20);
  return `
  <div class="card" style="margin-bottom:16px"><div class="section-title">💳 Análise por forma de pagamento</div>
    <p class="muted" style="margin-bottom:12px;line-height:1.5">Entenda como os clientes pagam: participação de cada forma no faturamento e na quantidade de vendas, taxas pagas e valor líquido recebido. Vendas com pagamento dividido têm o valor distribuído corretamente entre as formas.</p>
    <div class="toolbar" style="gap:8px;flex-wrap:wrap">
      <select id="pag-per" onchange="Modules.biPagRender()">${periodOptsHtml('mes')}</select>
      <span id="pag-custom" style="display:none;gap:8px;align-items:center"><input type="date" id="pag-de" onchange="Modules.biPagRender()"><span class="muted">até</span><input type="date" id="pag-ate" onchange="Modules.biPagRender()"></span>
      <select id="pag-cat" onchange="Modules.biPagRender()"><option value="">Todas categorias</option>${cats.map(c => `<option>${esc(c)}</option>`).join('')}</select>
      <select id="pag-cond" onchange="Modules.biPagRender()"><option value="">Toda condição</option><option value="novo">Novo</option><option value="seminovo">Seminovo</option><option value="usado">Usado</option></select>
      <select id="pag-prod" onchange="Modules.biPagRender()"><option value="">Todos os produtos</option>${prods.map(p => `<option value="${esc(p.sku)}">${esc(p.nome)}</option>`).join('')}</select>
    </div>
  </div>
  <div id="bipag-res"></div>`;
};
Modules.biPagSetChart = function (c) { this.biPagState.chart = c; this.biPagRender(); };
Modules.biPagCompute = function () {
  const per = fval('pag-per') || 'mes';
  const fracFn = BI.payFrac(fval('pag-cat'), fval('pag-prod'), fval('pag-cond'));
  const r = BI.range(per, fval('pag-de'), fval('pag-ate'));
  const vendas = BI.vendas().filter(v => { const d = new Date(v.data); return d >= r.start && d <= r.end; });
  const cur = BI.payAgg(vendas, fracFn);
  let prev = null, pr = null;
  if (per !== 'all') {
    pr = BI.prevRange(r, per);
    const pv = BI.vendas().filter(v => { const d = new Date(v.data); return d >= pr.start && d <= pr.end; });
    prev = BI.payAgg(pv, fracFn);
  }
  return { cur, prev, per, r, pr };
};
Modules.biPagRender = function () {
  const host = document.getElementById('bipag-res'); if (!host) return;
  const per = fval('pag-per') || 'mes';
  const cc = document.getElementById('pag-custom'); if (cc) cc.style.display = per === 'custom' ? 'inline-flex' : 'none';
  const ctx = this.biPagCompute();
  host.innerHTML = Modules.biPagHtml(ctx);
};
Modules.biPagHtml = function (ctx) {
  const cur = ctx.cur, prev = ctx.prev, r = ctx.r;
  if (!cur.list.length) return '<div class="empty-state"><div class="big">💳</div>Nenhuma venda no período selecionado.</div>';
  const periodoLabel = Fmt.date(r.start) + (Fmt.date(r.start) !== Fmt.date(r.end) ? ' a ' + Fmt.date(r.end) : '');
  const pctTaxasFat = cur.totFat ? cur.totTaxa / cur.totFat * 100 : 0;
  const fatLiquido = cur.totFat - cur.totTaxa;
  const get = k => cur.list.find(x => x.key === k) || { valor: 0, taxa: 0 };
  const semTaxaFat = get('PIX').valor + get('Dinheiro').valor;
  const refRate = BI.refCardRate();
  const economia = semTaxaFat * refRate / 100;

  /* ---------- KPIs executivos ---------- */
  const kpis = `<div class="grid kpis" style="margin-bottom:16px">
    ${kpi('Total de taxas pagas', Fmt.brl(cur.totTaxa), 'no período', '💳', 'red')}
    <div class="card kpi"><div class="kpi-ico">📉</div><div class="kpi-label">Taxas sobre faturamento</div><div class="kpi-value">${Fmt.pct(pctTaxasFat)}</div><div class="kpi-sub">do faturamento bruto</div></div>
    <div class="card kpi blue"><div class="kpi-ico">🏦</div><div class="kpi-label">Faturamento líquido</div><div class="kpi-value">${Fmt.brl(fatLiquido)}</div><div class="kpi-sub">bruto ${Fmt.brl(cur.totFat)} − taxas ${Fmt.brl(cur.totTaxa)}</div></div>
    <div class="card kpi" style="border:1px solid var(--green)"><div class="kpi-ico">💚</div><div class="kpi-label">Economia c/ PIX e Dinheiro</div><div class="kpi-value" style="color:var(--green)">${Fmt.brl(economia)}</div><div class="kpi-sub">vs taxa de cartão (${Fmt.pct(refRate)})</div></div>
  </div>`;

  /* ---------- Comparação com período anterior ---------- */
  let comp = '';
  if (prev) {
    const vari = (a, b) => { if (!b) return a ? '<span class="badge b-green">novo</span>' : '<span class="muted">—</span>'; const d = (a - b) / b * 100; return `<span style="color:${d >= 0 ? 'var(--red)' : 'var(--green)'};font-weight:700">${d >= 0 ? '▲ +' : '▼ '}${Fmt.pct(Math.abs(d))}</span>`; };
    const variG = (a, b) => { if (!b) return a ? '<span class="badge b-green">novo</span>' : '<span class="muted">—</span>'; const d = (a - b) / b * 100; return `<span style="color:${d >= 0 ? 'var(--green)' : 'var(--red)'};font-weight:700">${d >= 0 ? '▲ +' : '▼ '}${Fmt.pct(Math.abs(d))}</span>`; };
    const cmpCell = (lbl, a, b, vf) => `<div class="pag-cmp"><div class="muted" style="font-size:11px">${lbl}</div><div style="font-size:15px;font-weight:700">${Fmt.brl(a)}</div><div style="font-size:11px">ant: ${Fmt.brl(b)} · ${vf(a, b)}</div></div>`;
    comp = `<div class="card" style="margin-bottom:16px"><div class="section-title">📊 Este período vs anterior</div>
      <div class="pag-cmp-row">
        ${cmpCell('Faturamento bruto', cur.totFat, prev.totFat, variG)}
        ${cmpCell('Taxas pagas', cur.totTaxa, prev.totTaxa, vari)}
        ${cmpCell('Faturamento líquido', cur.totFat - cur.totTaxa, prev.totFat - prev.totTaxa, variG)}
        ${cmpCell('Lucro líquido', cur.totLucro, prev.totLucro, variG)}
      </div></div>`;
  }

  /* ---------- Gráfico (4 modos) ---------- */
  const chart = this.biPagState.chart;
  const valOf = x => chart === 'fat' ? x.valor : chart === 'qtd' ? x.vendas : chart === 'taxas' ? x.taxa : x.liquido;
  const fmtVal = v => chart === 'qtd' ? (v + ' venda(s)') : Fmt.brl(v);
  const slices = cur.list.map(x => ({ label: x.key, value: valOf(x), color: payColor(x.key) }));
  const total = cur.list.reduce((s, x) => s + valOf(x), 0);
  const center = chart === 'fat' ? Fmt.brl(cur.totFat).replace('R$ ', 'R$') : chart === 'qtd' ? cur.totVendas + '' : chart === 'taxas' ? Fmt.brl(cur.totTaxa).replace('R$ ', 'R$') : Fmt.brl(cur.totFat - cur.totTaxa).replace('R$ ', 'R$');
  const legend = cur.list.slice().sort((a, b) => valOf(b) - valOf(a)).map(x => {
    const pct = total ? valOf(x) / total * 100 : 0;
    return `<div class="pag-leg"><span class="pag-dot" style="background:${payColor(x.key)}"></span>
      <div style="flex:1"><div style="display:flex;justify-content:space-between;gap:8px"><b>${esc(x.key)}</b><span class="strong">${fmtVal(valOf(x))}</span></div>
      <div class="bi-bartrack" style="margin-top:5px"><div class="bi-barfill" style="width:${Math.min(100, pct)}%;background:${payColor(x.key)}"></div></div>
      <div class="muted" style="font-size:11px;margin-top:3px">${Fmt.pct(pct)}</div></div></div>`;
  }).join('');
  const segBtn = (k, l) => `<button class="seg-btn ${chart === k ? 'on' : ''}" onclick="Modules.biPagSetChart('${k}')">${l}</button>`;
  const grafico = `<div class="card" style="margin-bottom:16px">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:8px">
      <div class="section-title" style="margin:0">Distribuição <span class="muted" style="font-weight:500">· ${esc(periodoLabel)}</span></div>
      <div class="seg">${segBtn('fat', 'Faturamento')}${segBtn('qtd', 'Quantidade')}${segBtn('taxas', 'Taxas')}${segBtn('liquido', 'Líquido')}</div>
    </div>
    <div class="pag-chartwrap"><div class="pag-donut">${biDonut(slices, total, center)}</div><div class="pag-legend">${legend}</div></div>
  </div>`;

  /* ---------- Tabela detalhada ---------- */
  const rows = cur.list.map(x => `<tr>
    <td><span class="pag-dot" style="background:${payColor(x.key)}"></span> <b>${esc(x.key)}</b></td>
    <td class="num">${x.vendas}</td>
    <td class="num strong">${Fmt.brl(x.valor)}</td>
    <td class="num">${Fmt.pct(x.pctFat)}</td>
    <td class="num">${x.taxa > 0 ? Fmt.pct(x.taxaMedia) : '0%'}</td>
    <td class="num ${x.taxa > 0 ? '' : 'muted'}">${x.taxa > 0 ? '− ' + Fmt.brl(x.taxa) : '—'}</td>
    <td class="num strong" style="color:var(--green)">${Fmt.brl(x.liquido)}</td>
    <td class="num" style="color:${x.lucro >= 0 ? 'var(--green)' : 'var(--red)'};font-weight:700">${Fmt.brl(x.lucro)}</td>
    <td class="num">${Fmt.brl(x.ticket)}</td></tr>`).join('');
  const tabela = `<div class="card" style="margin-bottom:16px"><div class="section-title">Relatório por forma de pagamento</div>
    <div class="table-wrap"><table>
      <thead><tr><th>Forma</th><th class="num">Vendas</th><th class="num">Faturado</th><th class="num">Part.</th><th class="num">Taxa média</th><th class="num">Taxas pagas</th><th class="num">Líquido</th><th class="num">Lucro líq.</th><th class="num">Ticket</th></tr></thead>
      <tbody>${rows}</tbody>
      <tfoot><tr style="font-weight:700;border-top:2px solid var(--line)"><td>TOTAL</td><td class="num">${cur.totVendas}</td><td class="num">${Fmt.brl(cur.totFat)}</td><td class="num">100%</td><td class="num">${Fmt.pct(pctTaxasFat)}</td><td class="num">− ${Fmt.brl(cur.totTaxa)}</td><td class="num" style="color:var(--green)">${Fmt.brl(fatLiquido)}</td><td class="num" style="color:var(--green)">${Fmt.brl(cur.totLucro)}</td><td></td></tr></tfoot>
    </table></div>
    <p class="muted" style="font-size:11.5px;margin-top:8px">Pagamentos divididos são rateados entre as formas; os valores somam o faturamento total. Lucro líquido = participação no lucro bruto − taxas da forma.</p>
    ${App.canFinance() ? `<div style="margin-top:10px"><button class="btn-ghost btn-sm" onclick="Modules.biPagExport()">⬇️ Exportar Excel</button></div>` : ''}</div>`;

  /* ---------- Ranking das taxas ---------- */
  const rk = cur.list.filter(x => x.taxa > 0.009).sort((a, b) => b.taxa - a.taxa);
  const ranking = `<div class="card"><div class="section-title">🏅 Ranking das taxas (maior custo)</div>
    ${rk.length ? biRankRows(rk, x => x.taxa, x => x.vendas + ' vendas · ' + Fmt.brl(x.valor) + ' faturado · taxa ' + Fmt.pct(x.taxaMedia), x => `<span style="color:var(--red)">${Fmt.brl(x.taxa)}</span>`) : '<p class="muted">Nenhuma taxa paga no período (tudo em PIX/dinheiro). 🎉</p>'}</div>`;

  /* ---------- Insights automáticos ---------- */
  const cardFat = cur.list.filter(x => /Crédito|Débito/.test(x.key)).reduce((s, x) => s + x.valor, 0);
  const pctCard = cur.totFat ? cardFat / cur.totFat * 100 : 0;
  const parcTaxa = cur.list.filter(x => /^Crédito \d+x/.test(x.key)).reduce((s, x) => s + x.taxa, 0);
  const pctParcTaxas = cur.totTaxa ? parcTaxa / cur.totTaxa * 100 : 0;
  const maxImpacto = rk[0];
  const ins = [];
  if (pctCard > 0) ins.push(`${Fmt.pct(pctCard)} do faturamento foi realizado em cartão.`);
  ins.push(`As taxas consumiram ${Fmt.pct(pctTaxasFat)} do faturamento bruto.`);
  if (economia > 0) ins.push(`O PIX e o dinheiro economizaram aproximadamente ${Fmt.brl(economia)} em taxas no período.`);
  if (pctParcTaxas > 0) ins.push(`O crédito parcelado representou ${Fmt.pct(pctParcTaxas)} das taxas pagas.`);
  if (maxImpacto) ins.push(`A modalidade ${maxImpacto.key} teve o maior impacto financeiro: ${Fmt.brl(maxImpacto.taxa)} em taxas.`);
  if (cur.totLucro > 0 && cur.totFat) ins.push(`A margem líquida média do período foi de ${Fmt.pct(cur.totLucro / cur.totFat * 100)} sobre o faturamento.`);
  const insights = `<div class="card" style="margin-top:16px"><div class="section-title">💡 Insights</div>
    <div style="display:flex;flex-direction:column;gap:8px">${ins.map(t => `<div class="pag-insight">💬 ${esc(t)}</div>`).join('')}</div></div>`;

  return kpis + comp + grafico + `<div class="grid cols-2" style="margin-bottom:0">${tabela}${ranking}</div>` + Modules.biFinanceiraCard(ctx) + insights;
};
/* ---------- Boleto / Financeira (contas a receber) ---------- */
Modules.biFinanceiraCard = function (ctx) {
  const r = ctx.r;
  const recs = DB.all('financeiro').filter(f => f.financeira && f.origem === 'venda').filter(f => { const d = new Date(f.emissao || f.data); return d >= r.start && d <= r.end; });
  if (!recs.length) return '';
  const recebido = f => f.status === 'recebido' || f.status === 'pago' || f.status === 'conciliado' || (f.pago || 0) >= (f.valor || 0) - 0.01;
  const bruto = recs.reduce((s, f) => s + (f.valor || 0), 0);
  const taxas = recs.reduce((s, f) => s + (f.taxa || 0), 0);
  const liquidoTot = recs.reduce((s, f) => s + (f.liquido != null ? f.liquido : (f.valor - (f.taxa || 0))), 0);
  const recebidos = recs.filter(recebido), pendentes = recs.filter(f => !recebido(f));
  const jaRecebido = recebidos.reduce((s, f) => s + (f.liquido != null ? f.liquido : (f.valor - (f.taxa || 0))), 0);
  const aReceber = pendentes.reduce((s, f) => s + (f.liquido != null ? f.liquido : (f.valor - (f.taxa || 0))), 0);
  const prazoMed = recs.length ? recs.reduce((s, f) => { const e = new Date(f.emissao || f.data), vc = new Date(f.vencimento || f.data); return s + Math.max(0, Math.round((vc - e) / 86400000)); }, 0) / recs.length : 0;
  const porFin = {};
  recs.forEach(f => { const k = f.financeiraNome || 'Financeira'; porFin[k] = porFin[k] || { nome: k, bruto: 0, taxa: 0, liquido: 0, n: 0 }; porFin[k].bruto += f.valor || 0; porFin[k].taxa += f.taxa || 0; porFin[k].liquido += (f.liquido != null ? f.liquido : f.valor - (f.taxa || 0)); porFin[k].n++; });
  const fins = Object.values(porFin).sort((a, b) => b.bruto - a.bruto);
  return `<div class="card" style="margin-top:16px"><div class="section-title">🏦 Boleto / Financeira — contas a receber</div>
    <div class="grid kpis" style="margin-bottom:14px">
      ${kpi('Vendido por financeira', Fmt.brl(bruto), recs.length + ' venda(s)', '🏦', 'purple')}
      ${kpi('Taxas das financeiras', Fmt.brl(taxas), bruto ? Fmt.pct(taxas / bruto * 100) + ' do bruto' : '', '💳', 'red')}
      ${kpi('Líquido a receber', Fmt.brl(aReceber), pendentes.length + ' pendente(s)', '⏳', 'amber')}
      ${kpi('Já recebido', Fmt.brl(jaRecebido), recebidos.length + ' conciliado(s)', '✅', 'green')}
    </div>
    <div class="table-wrap"><table><thead><tr><th>Financeira</th><th class="num">Vendas</th><th class="num">Bruto</th><th class="num">Taxas</th><th class="num">Líquido</th></tr></thead>
      <tbody>${fins.map(x => `<tr><td><b>${esc(x.nome)}</b></td><td class="num">${x.n}</td><td class="num">${Fmt.brl(x.bruto)}</td><td class="num" style="color:var(--red)">− ${Fmt.brl(x.taxa)}</td><td class="num strong" style="color:var(--green)">${Fmt.brl(x.liquido)}</td></tr>`).join('')}</tbody>
      <tfoot><tr style="font-weight:700;border-top:2px solid var(--line)"><td>TOTAL</td><td class="num">${recs.length}</td><td class="num">${Fmt.brl(bruto)}</td><td class="num" style="color:var(--red)">− ${Fmt.brl(taxas)}</td><td class="num" style="color:var(--green)">${Fmt.brl(liquidoTot)}</td></tr></tfoot></table></div>
    <div class="muted" style="font-size:12px;margin-top:8px">Prazo médio de recebimento: <b>${Math.round(prazoMed)} dia(s)</b>. Concilie os recebimentos em Financeiro → Contas a Receber quando o valor cair na conta.</div></div>`;
};
Modules.biPagExport = function () {
  const ctx = Modules.biPagCompute(); const cur = ctx.cur, r = ctx.r, r2 = x => Math.round(x * 100) / 100;
  const pctTaxasFat = cur.totFat ? cur.totTaxa / cur.totFat * 100 : 0;
  const aoa = [['Rico Games — Análise por forma de pagamento'], ['Período', Fmt.date(r.start) + ' a ' + Fmt.date(r.end)], [],
    ['Faturamento bruto', r2(cur.totFat)], ['Total de taxas', r2(cur.totTaxa)], ['% taxas s/ faturamento', r2(pctTaxasFat)], ['Faturamento líquido', r2(cur.totFat - cur.totTaxa)], ['Lucro líquido', r2(cur.totLucro)], [],
    ['Forma', 'Vendas', 'Faturado', '% fat', 'Taxa média %', 'Taxas pagas', 'Líquido', 'Lucro líquido', 'Ticket médio']];
  cur.list.forEach(x => aoa.push([x.key, x.vendas, r2(x.valor), r2(x.pctFat), r2(x.taxaMedia), r2(x.taxa), r2(x.liquido), r2(x.lucro), r2(x.ticket)]));
  aoa.push(['TOTAL', cur.totVendas, r2(cur.totFat), 100, r2(pctTaxasFat), r2(cur.totTaxa), r2(cur.totFat - cur.totTaxa), r2(cur.totLucro), '']);
  Exporter.xlsx('formas-pagamento-' + new Date().toISOString().slice(0, 10) + '.xlsx', 'Pagamentos', aoa);
};


/* ---- COMPRAS POR FORMA DE PAGAMENTO ---- */
Modules.cpgState = { periodo: 'mes', de: '', ate: '' };
Modules.cpgSet = function (v) { this.cpgState.periodo = v; this.biRender(); };
Modules.biCompras = function () {
  const S = this.cpgState;
  const r = BI.range(S.periodo, S.de, S.ate);
  const custom = S.periodo === 'custom' ? `<span style="display:inline-flex;gap:6px;align-items:center"><input type="date" id="cpg-de" value="${S.de}" onchange="Modules.cpgState.de=this.value;Modules.biRender()"><span class="muted">até</span><input type="date" id="cpg-ate" value="${S.ate}" onchange="Modules.cpgState.ate=this.value;Modules.biRender()"></span>` : '';
  const bar = `<div class="bi-periodbar"><select id="cpg-per" onchange="Modules.cpgSet(this.value)">${periodOptsHtml(S.periodo)}</select> ${custom}<div class="bi-pb-label">📅 <b>${esc(BI.periodoLabel(S.periodo, r))}</b></div></div>`;
  const compras = DB.all('compras').filter(c => !c.cancelada && (() => { const d = new Date(c.data); return d >= r.start && d <= r.end; })());
  if (!compras.length) return bar + '<div class="empty-state"><div class="big">🚚</div>Nenhuma compra registrada no período.</div>';
  const porForma = {}, porOrigem = {}; let total = 0;
  compras.forEach(c => {
    const pags = (c.pagamentos && c.pagamentos.length) ? c.pagamentos : [{ forma: c.formaPagamento || '—', valor: c.total || 0 }];
    pags.forEach(p => { const f = p.forma || '—'; porForma[f] = (porForma[f] || 0) + (p.valor || 0); total += (p.valor || 0); });
    const o = c.origemPagamento || '—'; porOrigem[o] = (porOrigem[o] || 0) + (c.total || 0);
  });
  const formas = Object.entries(porForma).map(([f, v]) => ({ f, v, pct: total ? v / total * 100 : 0 })).sort((a, b) => b.v - a.v);
  const origens = Object.entries(porOrigem).map(([o, v]) => ({ o, v })).sort((a, b) => b.v - a.v);
  const PAL = ['#5b8cff', '#22c55e', '#f59e0b', '#ef4444', '#a855f7', '#14b8a6', '#ec4899', '#64748b'];
  const chart = (typeof Modules.apBars === 'function') ? Modules.apBars(formas.map(x => x.f), formas.map(x => x.v), '#5b8cff') : '';
  const kpi = (l, v) => `<div class="ap-kpi"><span>${l}</span><b>${v}</b></div>`;
  return bar
    + `<div class="ap-kpis" style="margin-bottom:14px">${kpi('Total comprado', Fmt.brl(total))}${kpi('Nº de compras', compras.length)}${kpi('Forma mais usada', formas[0] ? esc(formas[0].f) : '—')}${kpi('Formas distintas', formas.length)}</div>`
    + `<div class="card"><div class="section-title">Compras por forma de pagamento</div>
      <div class="table-wrap"><table><thead><tr><th>Forma</th><th class="num">Total</th><th class="num">% do total</th></tr></thead>
      <tbody>${formas.map((x, i) => `<tr><td><span class="bdot" style="display:inline-block;width:10px;height:10px;border-radius:3px;background:${PAL[i % 8]};margin-right:7px"></span>${esc(x.f)}</td><td class="num strong">${Fmt.brl(x.v)}</td><td class="num">${Fmt.pct(x.pct)}</td></tr>`).join('')}</tbody>
      <tfoot><tr style="font-weight:700;border-top:2px solid var(--line)"><td>Total</td><td class="num">${Fmt.brl(total)}</td><td class="num">100%</td></tr></tfoot></table></div>
      ${chart}</div>`
    + `<div class="card"><div class="section-title">Por origem do pagamento</div>
      <div class="table-wrap"><table><thead><tr><th>Origem</th><th class="num">Total</th></tr></thead>
      <tbody>${origens.map(x => `<tr><td>${esc(x.o)}</td><td class="num strong">${Fmt.brl(x.v)}</td></tr>`).join('')}</tbody></table></div></div>`;
};

/* ===== Compras × Vendas (Giro do que comprei) =====
   Para cada produto COMPRADO no período: quanto comprei e quanto DESSE lote já vendi
   (unidades, custo, receita e lucro estimados). "Vendido do lote" conta todas as vendas
   até hoje, limitado à quantidade comprada no período (giro nunca passa de 100%).
   Só leitura — não altera preços, estoque, financeiro nem histórico. */
Modules.giroState = { periodo: 'mes', de: '', ate: '', sort: 'inv' };
Modules.giroSet = function (v) { this.giroState.periodo = v; this.biRender(); };
Modules.giroSortSet = function (v) { this.giroState.sort = v; this.biRender(); };
Modules.giroCompute = function (r) {
  // 1) compras do período agregadas por SKU
  const compras = DB.all('compras').filter(c => !c.cancelada && (() => { const d = new Date(c.data); return d >= r.start && d <= r.end; })());
  const buy = {};
  compras.forEach(c => (c.itens || []).forEach(i => {
    const sku = i.sku || i.produtoId; if (!sku) return;
    const b = buy[sku] || (buy[sku] = { sku, nome: i.nome || (BI.prodInfo(i.sku) || {}).nome || sku, qtdC: 0, custoC: 0 });
    const q = +i.qtd || 0; b.qtdC += q; b.custoC += (+i.custo || 0) * q;
  }));
  // 2) vendas de TODOS os tempos por SKU (não canceladas)
  const sold = {};
  DB.all('vendas').filter(v => !v.cancelada).forEach(v => (v.itens || []).forEach(i => {
    const sku = i.sku; if (!sku || !buy[sku]) return;
    const s = sold[sku] || (sold[sku] = { qtd: 0, receita: 0 });
    const q = +i.qtd || 0; s.qtd += q; s.receita += (+i.preco || 0) * q;
  }));
  // 3) cruzamento por SKU
  const rows = Object.values(buy).map(b => {
    const s = sold[b.sku] || { qtd: 0, receita: 0 };
    const custoUnit = b.qtdC ? b.custoC / b.qtdC : 0;
    const precoMedioV = s.qtd ? s.receita / s.qtd : 0;
    const vendLote = Math.min(s.qtd, b.qtdC);          // do lote comprado no período
    const custoVend = vendLote * custoUnit;
    const receitaEst = vendLote * precoMedioV;
    const lucroEst = receitaEst - custoVend;
    const sobra = b.qtdC - vendLote;
    return { sku: b.sku, nome: b.nome, qtdC: b.qtdC, custoC: b.custoC, custoUnit, vendLote, giro: b.qtdC ? vendLote / b.qtdC * 100 : 0, custoVend, receitaEst, lucroEst, sobra, sobraCusto: sobra * custoUnit };
  });
  const cmp = { inv: (a, b) => b.custoC - a.custoC, giroDesc: (a, b) => b.giro - a.giro || b.custoC - a.custoC, giroAsc: (a, b) => a.giro - b.giro || b.custoC - a.custoC, lucro: (a, b) => b.lucroEst - a.lucroEst };
  rows.sort(cmp[this.giroState.sort] || cmp.inv);
  const T = rows.reduce((t, x) => { t.qtdC += x.qtdC; t.custoC += x.custoC; t.vendLote += x.vendLote; t.custoVend += x.custoVend; t.receitaEst += x.receitaEst; t.lucroEst += x.lucroEst; t.sobra += x.sobra; t.sobraCusto += x.sobraCusto; return t; }, { qtdC: 0, custoC: 0, vendLote: 0, custoVend: 0, receitaEst: 0, lucroEst: 0, sobra: 0, sobraCusto: 0 });
  T.giro = T.qtdC ? T.vendLote / T.qtdC * 100 : 0;
  return { rows, T, nCompras: compras.length };
};
Modules.biGiro = function () {
  const S = this.giroState, r = BI.range(S.periodo, S.de, S.ate);
  const custom = S.periodo === 'custom' ? `<span style="display:inline-flex;gap:6px;align-items:center"><input type="date" id="giro-de" value="${S.de}" onchange="Modules.giroState.de=this.value;Modules.biRender()"><span class="muted">até</span><input type="date" id="giro-ate" value="${S.ate}" onchange="Modules.giroState.ate=this.value;Modules.biRender()"></span>` : '';
  const bar = `<div class="bi-periodbar"><select id="giro-per" onchange="Modules.giroSet(this.value)">${periodOptsHtml(S.periodo)}</select> ${custom}<div class="bi-pb-label">📅 <b>${esc(BI.periodoLabel(S.periodo, r))}</b></div></div>`;
  const D = this.giroCompute(r);
  if (!D.rows.length) return bar + '<div class="empty-state"><div class="big">🔁</div>Nenhuma compra registrada no período.<div class="muted" style="margin-top:6px;font-size:12.5px">As compras aparecem aqui após serem lançadas em Entrada de Estoque ou Compras.</div></div>';
  const T = D.T;
  const kpi = (l, v, sub) => `<div class="ap-kpi"><span>${l}</span><b>${v}</b>${sub ? `<small style="display:block;color:var(--txt-3);font-weight:600;font-size:11px;margin-top:2px">${sub}</small>` : ''}</div>`;
  const giroColor = g => g >= 70 ? '#22c55e' : (g >= 35 ? '#f59e0b' : '#ef4444');
  const barPct = g => `<div style="display:flex;align-items:center;gap:7px;justify-content:flex-end"><div style="flex:1;max-width:90px;height:7px;border-radius:5px;background:var(--line);overflow:hidden"><div style="width:${Math.min(100, g).toFixed(0)}%;height:100%;background:${giroColor(g)}"></div></div><b style="min-width:42px;text-align:right;color:${giroColor(g)}">${Fmt.pct(g)}</b></div>`;
  const sortSel = `<select id="giro-sort" onchange="Modules.giroSortSet(this.value)" style="margin-left:auto">
    <option value="inv" ${S.sort === 'inv' ? 'selected' : ''}>Mais investido</option>
    <option value="giroAsc" ${S.sort === 'giroAsc' ? 'selected' : ''}>Menor giro (empacado)</option>
    <option value="giroDesc" ${S.sort === 'giroDesc' ? 'selected' : ''}>Maior giro</option>
    <option value="lucro" ${S.sort === 'lucro' ? 'selected' : ''}>Maior lucro estimado</option></select>`;
  const rowsHtml = D.rows.map(x => `<tr>
    <td class="strong">${esc(x.nome)}<div class="muted" style="font-size:11px">${esc(x.sku)}</div></td>
    <td class="num">${x.qtdC}</td>
    <td class="num">${Fmt.brl(x.custoC)}</td>
    <td class="num strong">${x.vendLote}${x.sobra > 0 ? `<div class="muted" style="font-size:11px">sobra ${x.sobra}</div>` : ''}</td>
    <td class="num">${barPct(x.giro)}</td>
    <td class="num">${Fmt.brl(x.receitaEst)}</td>
    <td class="num" style="color:${x.lucroEst >= 0 ? '#16a34a' : '#ef4444'}"><b>${Fmt.brl(x.lucroEst)}</b></td>
    <td class="num">${x.sobra > 0 ? Fmt.brl(x.sobraCusto) : '<span class="muted">—</span>'}</td></tr>`).join('');
  return bar
    + `<div class="ap-kpis" style="margin-bottom:6px">
        ${kpi('Comprado no período', Fmt.brl(T.custoC), T.qtdC + ' un · ' + D.nCompras + ' compra(s)')}
        ${kpi('Vendido do comprado', Fmt.pct(T.giro), T.vendLote + ' de ' + T.qtdC + ' un')}
        ${kpi('Receita estimada', Fmt.brl(T.receitaEst), 'do que já girou')}
        ${kpi('Lucro estimado', Fmt.brl(T.lucroEst), 'receita − custo do vendido')}
        ${kpi('Ainda em estoque', Fmt.brl(T.sobraCusto), T.sobra + ' un a custo')}
      </div>
      <p class="muted" style="font-size:12px;margin:0 2px 14px">💡 "Vendido do lote" conta todas as vendas até hoje, no máximo o que foi comprado no período. Receita e lucro são estimados pelo preço médio de venda de cada produto.</p>
      <div class="card"><div class="section-title" style="display:flex;align-items:center;gap:10px">Giro por produto ${sortSel}</div>
      <div class="table-wrap"><table><thead><tr>
        <th>Produto</th><th class="num">Comprado</th><th class="num">Investido</th><th class="num">Vendido</th><th class="num">% giro</th><th class="num">Receita estim.</th><th class="num">Lucro estim.</th><th class="num">Sobra (custo)</th>
      </tr></thead>
      <tbody>${rowsHtml}</tbody>
      <tfoot><tr style="font-weight:700;border-top:2px solid var(--line)">
        <td>Total (${D.rows.length} produtos)</td><td class="num">${T.qtdC}</td><td class="num">${Fmt.brl(T.custoC)}</td><td class="num">${T.vendLote}</td><td class="num">${Fmt.pct(T.giro)}</td><td class="num">${Fmt.brl(T.receitaEst)}</td><td class="num" style="color:${T.lucroEst >= 0 ? '#16a34a' : '#ef4444'}">${Fmt.brl(T.lucroEst)}</td><td class="num">${Fmt.brl(T.sobraCusto)}</td>
      </tr></tfoot></table></div>
      <div style="margin-top:12px"><button class="btn-ghost btn-sm" onclick="Modules.giroExport()">⬇️ Exportar CSV</button></div></div>`;
};
Modules.giroExport = function () {
  const S = this.giroState, r = BI.range(S.periodo, S.de, S.ate), D = this.giroCompute(r);
  const head = ['Produto', 'SKU', 'Comprado (un)', 'Investido', 'Vendido do lote (un)', '% giro', 'Custo do vendido', 'Receita estimada', 'Lucro estimado', 'Sobra (un)', 'Sobra (custo)'];
  const lines = [head.join(';')];
  D.rows.forEach(x => lines.push([`"${(x.nome || '').replace(/"/g, '""')}"`, x.sku, x.qtdC, x.custoC.toFixed(2), x.vendLote, x.giro.toFixed(1), x.custoVend.toFixed(2), x.receitaEst.toFixed(2), x.lucroEst.toFixed(2), x.sobra, x.sobraCusto.toFixed(2)].join(';')));
  const T = D.T; lines.push(['TOTAL', '', T.qtdC, T.custoC.toFixed(2), T.vendLote, T.giro.toFixed(1), T.custoVend.toFixed(2), T.receitaEst.toFixed(2), T.lucroEst.toFixed(2), T.sobra, T.sobraCusto.toFixed(2)].join(';'));
  const blob = new Blob(['﻿' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'compras-x-vendas.csv'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  if (typeof Toast !== 'undefined') Toast.ok('CSV exportado.');
};
