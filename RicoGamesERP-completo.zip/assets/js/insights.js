/* Removido na limpeza v4.7 — a aba "Insights" dos Relatórios foi descontinuada.
   Este arquivo não é mais carregado pelo index.html. */
