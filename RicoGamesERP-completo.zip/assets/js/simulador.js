/* ============ RICO GAMES ERP — Simulador Comercial (layout Studio) ============
   Simula preços, descontos, combos, taxas e quantidades usando os dados REAIS do ERP.
   NÃO altera nenhum preço/produto no sistema — é só para análise e decisão.
   Layout: painel de controle à esquerda, resultado vivo à direita (recalcula em tempo real). */

Modules.simState = { itens: [], forma: '', qtd: 1, comboPreco: null, nome: '' };

/* Cálculo de um cenário de venda */
Modules.simCalc = function (preco, custo, qtd, forma) {
  preco = +preco || 0; custo = +custo || 0; qtd = +qtd || 1;
  const fat = preco * qtd, custoTot = custo * qtd, bruto = fat - custoTot;
  const taxa = (typeof Taxas !== 'undefined' && Taxas.feeByKey) ? Taxas.feeByKey(forma, fat) : 0;
  const liq = bruto - taxa;
  return { preco, fat, custoTot, bruto, taxa, liq, margemV: fat ? liq / fat * 100 : 0, margemC: custoTot ? liq / custoTot * 100 : 0, capital: custoTot };
};

Modules.simFormas = function () { return (typeof Taxas !== 'undefined') ? Taxas.ativas().map(t => t.key) : ['PIX', 'Dinheiro', 'Débito', 'Crédito à vista']; };

/* Semáforo de margem: 🟢 ≥30% · 🟡 20–30% · 🔴 <20% */
Modules.simSem = function (m) {
  if (m >= 30) return { c: 'var(--green)', bg: 'b-green', e: '🟢', t: 'Excelente' };
  if (m >= 20) return { c: 'var(--amber)', bg: 'b-amber', e: '🟡', t: 'Atenção' };
  return { c: 'var(--red)', bg: 'b-red', e: '🔴', t: 'Margem baixa' };
};

/* Miniatura do produto (foto se existir, senão ícone por categoria) */
Modules.simIcon = function (p) {
  const src = p.foto || p.imagem || p.img;
  if (src) return `<img src="${esc(src)}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:10px">`;
  const c = (p.categoria || '').toLowerCase();
  const e = c.includes('console') ? '🎮' : c.includes('jogo') ? '💿' : c.includes('controle') ? '🎮' : (c.includes('acess') || c.includes('head')) ? '🎧' : c.includes('colec') ? '⭐' : '📦';
  return `<span style="font-size:24px">${e}</span>`;
};

Modules.biSimulador = function () {
  const forms = this.simFormas();
  if (!this.simState.forma) this.simState.forma = forms[0] || 'PIX';
  const S = this.simState;
  const cenarios = DB.all('cenarios');

  const cards = S.itens.map(it => {
    const p = BI.prodInfo(it.sku) || DB.all('produtos').find(x => x.sku === it.sku) || {};
    const custo = p.custoMedio || p.custo || 0;
    const u = this.simCalc(p.preco || 0, custo, 1, S.forma);
    const sem = this.simSem(u.margemV);
    return `<div class="simx-card">
      <div class="simx-card-h">
        <div class="simx-thumb">${this.simIcon(p)}</div>
        <div style="flex:1;min-width:0"><div style="font-weight:700;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(p.nome || it.sku)}</div><div class="muted" style="font-size:11.5px">${esc(p.categoria || '')}${p.condicao ? ' · ' + esc(p.condicao) : ''}</div></div>
        <span class="simx-rm" title="Remover" onclick="Modules.simRemove('${esc(it.sku)}')">✕</span>
      </div>
      <div class="simx-stats">
        <div><span>Estoque</span><b>${p.qtd || 0} un</b></div>
        <div><span>Custo médio</span><b>${Fmt.brl(custo)}</b></div>
        <div><span>Venda</span><b>${Fmt.brl(p.preco || 0)}</b></div>
        <div><span>Lucro líq/un</span><b>${Fmt.brl(u.liq)}</b></div>
        <div style="grid-column:1/-1"><span>Margem atual</span><b style="color:${sem.c}">${sem.e} ${Fmt.pct(u.margemV)}</b></div>
      </div>
      <div class="simx-price">
        <div class="simx-pf" style="flex:1.4"><label>Novo preço (R$)</label><input type="text" inputmode="decimal" id="sim-preco-${esc(it.sku)}" value="${it.novoPreco != null ? String(it.novoPreco).replace('.', ',') : ''}" placeholder="${String(p.preco || 0).replace('.', ',')}" oninput="Modules.simRecalc()"></div>
        <div class="simx-pf"><label>Desconto</label><div style="display:flex;gap:4px"><input type="number" step="0.01" id="sim-desc-${esc(it.sku)}" value="${it.descVal || ''}" placeholder="0" oninput="Modules.simRecalc()" style="min-width:0"><select id="sim-desctipo-${esc(it.sku)}" onchange="Modules.simRecalc()" style="width:54px"><option value="pct" ${it.descTipo !== 'rs' ? 'selected' : ''}>%</option><option value="rs" ${it.descTipo === 'rs' ? 'selected' : ''}>R$</option></select></div></div>
      </div>
    </div>`;
  }).join('');

  const comboField = S.itens.length >= 2 ? `<div class="field full"><label>Preço do combo (R$) <span class="muted" style="font-weight:400">— pacote fechado</span></label><input id="sim-combopreco" type="text" inputmode="decimal" value="${S.comboPreco != null ? String(S.comboPreco).replace('.', ',') : ''}" placeholder="vazio = soma dos novos preços" oninput="Modules.simRecalc()"></div>` : '';

  return `
  <div class="simx">
    <div class="simx-col-left">
      <div class="card">
        <input id="sim-busca" placeholder="🔎 Buscar produto..." oninput="Modules.simBusca()" autocomplete="off">
        <div id="sim-drop" class="sim-drop"></div>
        <button class="btn-ghost btn-sm" style="margin-top:10px;width:100%" onclick="document.getElementById('sim-busca').focus()">+ Adicionar produto ao combo</button>
        <div id="sim-sel" style="margin-top:10px;display:flex;flex-direction:column;gap:10px">${cards || '<div class="simx-empty">Busque e selecione um produto para começar.</div>'}</div>
      </div>
      <div class="card" style="margin-top:12px">
        <div class="form-grid">
          <div class="field"><label>Forma de pagamento</label><select id="sim-forma" onchange="Modules.simState.forma=this.value;Modules.biRender()">${forms.map(f => `<option ${S.forma === f ? 'selected' : ''}>${esc(f)}</option>`).join('')}</select></div>
          <div class="field"><label>Quantidade</label><input id="sim-qtd" type="number" min="1" value="${S.qtd || 1}" oninput="Modules.simRecalc()"></div>
          ${comboField}
        </div>
        <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
          <input id="sim-nome" placeholder="Nome do cenário (ex: Black Friday)" value="${esc(S.nome || '')}" style="flex:1;min-width:120px">
          <button class="btn-primary btn-sm" onclick="Modules.simSalvar()">Salvar cenário</button>
        </div>
        ${cenarios.length ? `<div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap">${cenarios.slice().sort((a, b) => new Date(b.data) - new Date(a.data)).map(c => `<span class="seg-chip" onclick="Modules.simCarregar('${c.id}')">${esc(c.nome)} <span onclick="event.stopPropagation();Modules.simDelCenario('${c.id}')" style="color:var(--red)">✕</span></span>`).join('')}</div>` : ''}
      </div>
    </div>
    <div class="simx-col-right" id="sim-result"></div>
  </div>`;
};

Modules.simBusca = function () {
  const q = (fval('sim-busca') || '').toLowerCase(); const drop = document.getElementById('sim-drop'); if (!drop) return;
  if (!q) { drop.classList.remove('show'); drop.innerHTML = ''; return; }
  const list = DB.all('produtos').filter(p => !this.simState.itens.some(i => i.sku === p.sku) && (p.nome.toLowerCase().includes(q) || (p.sku || '').toLowerCase().includes(q))).slice(0, 10);
  drop.innerHTML = list.length ? list.map(p => `<div class="ms-opt" onmousedown="event.preventDefault();Modules.simAdd('${esc(p.sku)}')"><span>${esc(p.nome)}</span><span class="o-sku">${p.sku} · ${Fmt.brl(p.preco)}</span></div>`).join('') : '<div class="ms-empty">Nenhum produto.</div>';
  drop.classList.add('show');
};
Modules.simAdd = function (sku) {
  if (this.simState.itens.some(i => i.sku === sku)) return;
  this.simState.itens.push({ sku, novoPreco: null, descTipo: 'pct', descVal: 0 });
  const b = document.getElementById('sim-busca'); if (b) b.value = '';
  const d = document.getElementById('sim-drop'); if (d) { d.classList.remove('show'); d.innerHTML = ''; }
  this.biRender();
};
Modules.simRemove = function (sku) { this.simState.itens = this.simState.itens.filter(i => i.sku !== sku); this.biRender(); };

/* Lê os inputs, recalcula tudo e preenche SÓ a área de resultado (à direita) — mantém o foco nos campos */
Modules.simRecalc = function () {
  const host = document.getElementById('sim-result'); if (!host) return;
  const S = this.simState;
  S.forma = fval('sim-forma') || S.forma; S.qtd = parseInt(fval('sim-qtd')) || 1;
  const cp = moneyBR(fval('sim-combopreco')); S.comboPreco = isNaN(cp) ? null : cp; S.nome = fval('sim-nome') || S.nome;
  const rows = S.itens.map(it => {
    const p = BI.prodInfo(it.sku) || DB.all('produtos').find(x => x.sku === it.sku) || {};
    const custo = p.custoMedio || p.custo || 0, precoAtual = p.preco || 0;
    let novoPreco = moneyBR(fval('sim-preco-' + it.sku));
    const descVal = parseFloat(String(fval('sim-desc-' + it.sku)).replace(',', '.')) || 0;
    const descTipo = fval('sim-desctipo-' + it.sku) || 'pct';
    it.descVal = descVal; it.descTipo = descTipo;
    if (isNaN(novoPreco)) { novoPreco = descVal > 0 ? Math.max(0, precoAtual - (descTipo === 'rs' ? descVal : precoAtual * descVal / 100)) : precoAtual; }
    it.novoPreco = novoPreco;
    return { p, custo, precoAtual, novoPreco };
  });
  host.innerHTML = this.simResultHtml(rows);
};

Modules.simResultHtml = function (rows) {
  if (!rows.length) return '<div class="simx-empty big">Selecione um produto à esquerda e digite um novo preço.<br><span class="muted">Tudo é recalculado em tempo real.</span></div>';
  const S = this.simState;
  const kpi = (l, v, c) => `<div class="simx-kpi"><span>${l}</span><b${c ? ` style="color:${c}"` : ''}>${v}</b></div>`;

  const blocks = rows.map(r => {
    const au = this.simCalc(r.precoAtual, r.custo, 1, S.forma);   // atual / unidade
    const pu = this.simCalc(r.novoPreco, r.custo, 1, S.forma);    // promo / unidade
    const dPreco = r.novoPreco - r.precoAtual;
    const economia = r.precoAtual - r.novoPreco;
    const descPct = r.precoAtual ? economia / r.precoAtual * 100 : 0;
    const roi = r.custo ? pu.liq / r.custo * 100 : 0;
    const impacto = au.liq ? (pu.liq - au.liq) / au.liq * 100 : 0;
    const sem = this.simSem(pu.margemV), semA = this.simSem(au.margemV);
    const estoque = r.p.qtd || 0;
    return `<div class="simx-result">
      <div class="simx-hero">
        <div class="muted" style="font-size:12px">Resultado · ${esc(r.p.nome)} · ${S.qtd} un · ${esc(S.forma)}</div>
        <div class="simx-hero-main"><span class="simx-big" style="color:${pu.liq >= 0 ? 'inherit' : 'var(--red)'}">${Fmt.brl(pu.liq)}</span><span class="muted">lucro líquido / un ${dPreco !== 0 ? `<span style="color:${pu.liq - au.liq >= 0 ? 'var(--green)' : 'var(--red)'}">(${pu.liq - au.liq >= 0 ? '+' : ''}${Fmt.brl(pu.liq - au.liq)})</span>` : ''}</span></div>
        <span class="badge ${sem.bg}">${sem.e} Margem ${Fmt.pct(pu.margemV)} · ${sem.t}</span>
      </div>
      <div class="simx-ba">
        <div class="simx-ba-col"><div class="simx-ba-t">Antes</div>
          <div class="simx-ln"><span>Preço</span><b>${Fmt.brl(r.precoAtual)}</b></div>
          <div class="simx-ln"><span>Custo</span><b>${Fmt.brl(r.custo)}</b></div>
          <div class="simx-ln"><span>Lucro</span><b>${Fmt.brl(au.liq)}</b></div>
          <div class="simx-ln"><span>Margem</span><b style="color:${semA.c}">${Fmt.pct(au.margemV)}</b></div>
        </div>
        <div class="simx-ba-col promo"><div class="simx-ba-t">Depois</div>
          <div class="simx-ln"><span>Preço</span><b>${Fmt.brl(r.novoPreco)}</b></div>
          <div class="simx-ln"><span>Custo</span><b>${Fmt.brl(r.custo)}</b></div>
          <div class="simx-ln"><span>Lucro</span><b style="color:${pu.liq >= 0 ? 'var(--green)' : 'var(--red)'}">${Fmt.brl(pu.liq)}</b></div>
          <div class="simx-ln"><span>Margem</span><b style="color:${sem.c}">${Fmt.pct(pu.margemV)}</b></div>
        </div>
      </div>
      <div class="simx-kpis">
        ${kpi('Diferença de preço', (dPreco >= 0 ? '+' : '') + Fmt.brl(dPreco), dPreco < 0 ? 'var(--red)' : '')}
        ${kpi('Lucro bruto', Fmt.brl(pu.bruto))}
        ${kpi('Margem s/ custo', Fmt.pct(pu.margemC))}
        ${kpi('ROI', Fmt.pct(roi))}
        ${kpi('Cliente economiza', Fmt.brl(economia), economia > 0 ? 'var(--green)' : '')}
        ${kpi('Desconto', Fmt.pct(descPct))}
      </div>
      <div class="simx-final">
        <div class="simx-final-h">Resultado final <span class="muted" style="font-weight:400;font-size:12px">· ${S.qtd} un vendidas</span></div>
        <div class="simx-final-grid">
          ${kpi('Faturamento', Fmt.brl(pu.fat * S.qtd))}
          ${kpi('Lucro líquido', Fmt.brl(pu.liq * S.qtd), 'var(--green)')}
          ${kpi('Margem', Fmt.pct(pu.margemV), sem.c)}
          ${kpi('Lucro / unidade', Fmt.brl(pu.liq))}
          ${kpi('Lucro todo estoque (' + estoque + ')', Fmt.brl(pu.liq * estoque))}
          ${kpi('Impacto no lucro', (impacto >= 0 ? '+' : '') + Fmt.pct(impacto), impacto < 0 ? 'var(--red)' : 'var(--green)')}
        </div>
      </div>
    </div>`;
  }).join('');

  // barra-resumo do combo (2+ produtos)
  let combo = '';
  if (rows.length >= 2) {
    const custoCombo = rows.reduce((s, r) => s + r.custo, 0);
    const precoIndAtual = rows.reduce((s, r) => s + r.precoAtual, 0);
    const precoIndPromo = rows.reduce((s, r) => s + r.novoPreco, 0);
    const comboPreco = (S.comboPreco != null && S.comboPreco > 0) ? S.comboPreco : precoIndPromo;
    const ind = this.simCalc(precoIndPromo, custoCombo, 1, S.forma);
    const cmb = this.simCalc(comboPreco, custoCombo, 1, S.forma);
    const melhor = cmb.liq >= ind.liq ? 'combo' : 'sep';
    const economia = precoIndAtual - comboPreco;
    const sem = this.simSem(cmb.margemV);
    combo = `<div class="simx-combobar">
      <div class="simx-combobar-h"><b>🎁 Combo</b> <span class="muted" style="font-size:12px">${rows.map(r => esc(r.p.nome)).join(' + ')}</span></div>
      <div class="simx-combo-metrics">
        <div><span>Custo do combo</span><b>${Fmt.brl(custoCombo)}</b></div>
        <div><span>Preço somado</span><b>${Fmt.brl(precoIndAtual)}</b></div>
        <div><span>Preço do combo</span><b>${Fmt.brl(comboPreco)}</b></div>
        <div><span>Lucro líquido</span><b style="color:${cmb.liq >= 0 ? 'var(--green)' : 'var(--red)'}">${Fmt.brl(cmb.liq)}</b></div>
        <div><span>Margem</span><b style="color:${sem.c}">${sem.e} ${Fmt.pct(cmb.margemV)}</b></div>
        <div><span>Cliente economiza</span><b style="color:${economia > 0 ? 'var(--green)' : ''}">${Fmt.brl(economia)}</b></div>
      </div>
      <span class="badge ${melhor === 'combo' ? 'b-green' : 'b-amber'}">${melhor === 'combo' ? '🟢 O combo rende mais que vender separado' : '🟡 Vender separado rende mais'} · diferença ${Fmt.brl(Math.abs(cmb.liq - ind.liq))}</span>
    </div>`;
  }

  // sugestões inteligentes (histórico real de vendas)
  let sug = '';
  const skus = rows.map(r => r.p.sku);
  if (skus.length && typeof BI.crossSell === 'function') {
    const cross = BI.crossSell(BI.vendas());
    const dicas = [];
    skus.forEach(sku => {
      const c = cross.find(x => x.sku === sku);
      if (c && c.comps.length) {
        const top = c.comps[0]; const pct = c.orders ? Math.round(top.count / c.orders * 100) : 0;
        if (pct >= 30 && !skus.includes(top.sku)) dicas.push(`Adicionar "${top.nome}" ao combo faz sentido: sai junto com ${(BI.prodInfo(sku) || {}).nome} em ${pct}% das vendas.`);
      }
    });
    const a = BI.agg(BI.vendas());
    const incent = BI.prods().filter(p => p.qtd > 0).map(p => { const ag = a.find(x => x.sku === p.sku) || { qtd: 0 }; const margem = p.preco ? (p.preco - (p.custoMedio || p.custo)) / p.preco * 100 : 0; return { p, vend: ag.qtd, margem }; }).filter(x => x.vend <= 1 && x.margem >= 25).sort((u, v) => v.margem - u.margem)[0];
    if (incent) dicas.push(`"${incent.p.nome}" tem baixa saída e margem alta (${Fmt.pct(incent.margem)}) — bom brinde/incentivo na promoção.`);
    if (dicas.length) sug = dicas.map(d => `<div class="simx-sug"><span>💡</span><span>${esc(d)}</span></div>`).join('');
  }

  const exp = App.canFinance() ? `<div style="margin-top:12px"><button class="btn-ghost btn-sm" onclick="Modules.simExport('xlsx')">⬇️ Excel</button> <button class="btn-ghost btn-sm" onclick="Modules.simExport('pdf')">🖨️ PDF</button></div>` : '';
  return blocks + combo + sug + exp + `<p class="muted" style="font-size:11px;margin-top:8px">Usa custo médio, taxas e histórico reais · não altera nenhum preço do sistema.</p>`;
};

/* Cenários salvos */
Modules.simSalvar = function () {
  this.simRecalc();
  const nome = fval('sim-nome') || 'Cenário ' + new Date().toLocaleDateString('pt-BR');
  if (!this.simState.itens.length) return Toast.err('Selecione produtos antes de salvar o cenário.');
  DB.insert('cenarios', { nome, itens: this.simState.itens.map(i => ({ sku: i.sku, novoPreco: i.novoPreco, descTipo: i.descTipo, descVal: i.descVal })), forma: this.simState.forma, qtd: this.simState.qtd, comboPreco: this.simState.comboPreco, data: new Date().toISOString() });
  Toast.ok('Cenário "' + nome + '" salvo.'); this.biRender();
};
Modules.simCarregar = function (id) {
  const c = DB.get('cenarios', id); if (!c) return;
  this.simState = { itens: (c.itens || []).map(i => Object.assign({}, i)), forma: c.forma || this.simFormas()[0], qtd: c.qtd || 1, comboPreco: c.comboPreco != null ? c.comboPreco : null, nome: c.nome || '' };
  Toast.ok('Cenário "' + c.nome + '" carregado.'); this.biRender();
};
Modules.simDelCenario = function (id) { DB.remove('cenarios', id); Toast.ok('Cenário removido.'); this.biRender(); };

Modules.simExport = function (fmt) {
  const S = this.simState, r2 = x => Math.round(x * 100) / 100;
  const rows = S.itens.map(it => {
    const p = BI.prodInfo(it.sku) || DB.all('produtos').find(x => x.sku === it.sku) || {};
    const custo = p.custoMedio || p.custo || 0, precoAtual = p.preco || 0, novo = it.novoPreco != null ? it.novoPreco : precoAtual;
    const atual = this.simCalc(precoAtual, custo, S.qtd, S.forma), promo = this.simCalc(novo, custo, S.qtd, S.forma);
    return { nome: p.nome, precoAtual, novo, atual, promo };
  });
  if (fmt === 'xlsx') {
    const aoa = [['Rico Games — Simulador Comercial'], ['Cenário', S.nome || '—'], ['Forma', S.forma], ['Qtd', S.qtd], [],
      ['Produto', 'Preço atual', 'Novo preço', 'Lucro líq atual', 'Lucro líq promo', 'Margem atual %', 'Margem promo %']];
    rows.forEach(x => aoa.push([x.nome, r2(x.precoAtual), r2(x.novo), r2(x.atual.liq), r2(x.promo.liq), r2(x.atual.margemV), r2(x.promo.margemV)]));
    Exporter.xlsx('simulacao-' + (S.nome || 'cenario').replace(/[^\w]+/g, '-').slice(0, 24) + '.xlsx', 'Simulação', aoa);
  } else {
    const kp = (l, v) => `<div class="k"><div class="l">${l}</div><div class="v">${v}</div></div>`;
    const tot = rows.reduce((s, x) => s + x.promo.liq, 0);
    const kpis = `<div class="kpis">${kp('Cenário', esc(S.nome || '—'))}${kp('Forma', esc(S.forma))}${kp('Qtd/produto', S.qtd)}${kp('Lucro líq. total (promo)', Fmt.brl(tot))}</div>`;
    const tr = rows.map(x => `<tr><td>${esc(x.nome)}</td><td class="num">${Fmt.brl(x.precoAtual)}</td><td class="num">${Fmt.brl(x.novo)}</td><td class="num">${Fmt.brl(x.atual.liq)}</td><td class="num">${Fmt.brl(x.promo.liq)}</td><td class="num">${Fmt.pct(x.promo.margemV)}</td></tr>`).join('');
    Exporter.pdf('Simulador Comercial — ' + (S.nome || 'Cenário'), kpis + `<table><thead><tr><th>Produto</th><th class="num">Preço atual</th><th class="num">Novo preço</th><th class="num">Lucro atual</th><th class="num">Lucro promo</th><th class="num">Margem promo</th></tr></thead><tbody>${tr}</tbody></table>`);
  }
};
