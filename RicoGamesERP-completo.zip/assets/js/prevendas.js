/* ============ RICO GAMES ERP — Pré-venda / Reservas (UNIFICADO SOBRE VENDAS) ============
   REGRA CENTRAL: uma pré-venda é uma VENDA NORMAL (coleção `vendas`) com tipo 'pre_venda'.
   A única diferença é a ENTREGA FUTURA: o(s) item(ns) ficam com entrega:'prevenda' e o
   estoque físico NÃO é baixado até a entrega. O faturamento, lucro, margem, formas de
   pagamento, caixa e todos os relatórios já enxergam a venda desde o dia em que foi feita,
   porque leem a coleção `vendas`. A entrega posterior apenas vira o status logístico e dá
   baixa no estoque — NÃO cria uma segunda venda e NÃO altera o faturamento.

   Pagamento parcial (sinal): o valor TOTAL conta como faturamento na data da venda; o que
   falta receber vira uma conta "a receber" no financeiro (não recontamos o recebido). */
const PV = {
  PAY: { nao_pago: ['Não pago', 'b-gray'], parcial: ['Parcialmente pago', 'b-amber'], pago: ['Pago', 'b-green'], vencido: ['Vencido', 'b-red'], cancelado: ['Cancelado', 'b-gray'] },
  ENT: { aguardando: ['Aguardando produto', 'b-amber'], disponivel: ['Disponível p/ retirada', 'b-blue'], entregue: ['Entregue', 'b-green'], cancelado: ['Cancelado', 'b-gray'] },

  /* ---------- helpers de identificação ---------- */
  isPre(v) { return v && (v.tipo === 'pre_venda' || (v.itens || []).some(i => i.entrega === 'prevenda')); },
  listAll() { return DB.all('vendas').filter(v => this.isPre(v)); },
  items(v) { return v.itens || []; },
  pendentes(v) { return (v.itens || []).filter(i => i.entrega === 'prevenda'); },

  /* ---------- pagamento / entrega ---------- */
  pago(v) { return (v.pagamentos || []).reduce((s, p) => s + (+p.valor || 0), 0); },
  restante(v) { return Math.max(0, (v.total || 0) - this.pago(v)); },
  todayStart() { const d = new Date(); d.setHours(0, 0, 0, 0); return d; },
  limite(v) { return v.dataLimite ? new Date(v.dataLimite + 'T23:59:59') : null; },
  overdue(v) { const l = this.limite(v); return l && l < this.todayStart() && this.restante(v) > 0.009; },
  diasAteLimite(v) { const l = this.limite(v); if (!l) return null; return Math.ceil((l - this.todayStart()) / 86400000); },
  entregue(v) { return !this.pendentes(v).length && this.isPre(v); },
  payStatus(v) {
    if (v.cancelada) return 'cancelado';
    if (this.restante(v) <= 0.009) return 'pago';
    if (this.overdue(v)) return 'vencido';
    return this.pago(v) > 0 ? 'parcial' : 'nao_pago';
  },
  entStatus(v) {
    if (v.cancelada) return 'cancelado';
    if (!this.pendentes(v).length) return 'entregue';
    return v.statusEntrega === 'disponivel' ? 'disponivel' : 'aguardando';
  },
  payBadge(v) { const m = this.PAY[this.payStatus(v)] || ['—', 'b-gray']; return `<span class="badge ${m[1]}">${m[0]}</span>`; },
  entBadge(v) { const m = this.ENT[this.entStatus(v)] || ['—', 'b-gray']; return `<span class="badge ${m[1]}">${m[0]}</span>`; },
  vLabel(v) { return '#' + (v.numero || (v.id || '').slice(-4)); },
  produtoResumo(v) { return (v.itens || []).map(i => i.qtd + 'x ' + i.nome).join(', '); },
  qtdTotal(v) { return (v.itens || []).reduce((s, i) => s + (i.qtd || 0), 0); },

  nextNum() { let max = 1049; DB.all('prevendas').forEach(p => { if ((p.numero || 0) > max) max = p.numero; }); DB.all('vendas').forEach(v => { if ((v.numero || 0) > max) max = v.numero; }); return max + 1; },
  available(pr) { return (pr.qtd || 0) - (pr.reservado || 0); },
  quem() { return (typeof App !== 'undefined' && App.user() && App.user().nome) ? App.user().nome : 'Admin'; },

  /* ---------- reserva de estoque (não baixa; só marca reservado quando há unidade) ---------- */
  reserveItens(itens) {
    itens.forEach(it => {
      if (!it.produtoId) return;
      const pr = DB.get('produtos', it.produtoId); if (!pr) return;
      if (this.available(pr) >= it.qtd) { DB.update('produtos', it.produtoId, { reservado: (pr.reservado || 0) + it.qtd }); it.reservado = true; }
      else it.reservado = false;
    });
  },

  /* ---------- registra UM pagamento no financeiro (recebido REAL) e no caixa se dinheiro ---------- */
  logPay(v, pay) {
    const forma = pay.forma || 'Dinheiro', valor = +pay.valor || 0;
    const taxa = (typeof Taxas !== 'undefined') ? Taxas.feeByKey(forma, valor) : 0;
    const fin = DB.logFin({ tipo: 'entrada', categoria: 'Venda', subcategoria: forma, descricao: 'Pré-venda ' + this.vLabel(v) + ' — ' + (v.cliente || '') + ' (' + forma + ')', valor, taxa, liquido: valor - taxa, status: 'pago', origem: 'venda', refId: v.id, formaPagamento: forma });
    const p = { tipo: forma, valor, parcelas: pay.parcelas || 1, taxa, data: pay.data || new Date().toISOString(), finId: fin.id };
    if (forma === 'Dinheiro' && typeof Caixa !== 'undefined' && Caixa.add) {
      const cx = Caixa.add({ fluxo: 'entrada', tipo: 'Venda em dinheiro', origem: 'Pré-venda ' + this.vLabel(v), categoria: 'Venda', valor, obs: this.produtoResumo(v) + ' — ' + (v.cliente || ''), refId: v.id });
      if (cx && cx.id) p.caixaId = cx.id;
    }
    return p;
  },

  /* ---------- BUILDER CENTRAL: cria a pré-venda como VENDA ---------- */
  criar(dados) {
    // dados: { cliente, telefone, itens:[{produtoId,sku,nome,qtd,preco,custo,categoria,condicao}],
    //          pagamentos:[{forma,valor,parcelas}], dataLimite, dataEntregaPrevista, obs, data }
    const agoraISO = dados.data || new Date().toISOString();
    const itensArr = (dados.itens || []).map(i => ({
      produtoId: i.produtoId || null, sku: i.sku || null, nome: i.nome, qtd: +i.qtd || 1,
      preco: +i.preco || 0, precoOriginal: i.preco, precoMotivo: null, custo: +i.custo || 0,
      categoria: i.categoria || '—', condicao: i.condicao || 'novo',
      entrega: 'prevenda', entregueEm: null, dataPrevista: dados.dataEntregaPrevista || '', reservado: false
    }));
    this.reserveItens(itensArr);
    const total = itensArr.reduce((s, i) => s + i.preco * i.qtd, 0);
    const custoTotal = itensArr.reduce((s, i) => s + i.custo * i.qtd, 0);
    const numero = this.nextNum();
    const venda = DB.insert('vendas', {
      data: agoraISO, numero, tipo: 'pre_venda', itens: itensArr,
      cliente: dados.cliente || null, telefone: dados.telefone || null, temPrevenda: true,
      bruto: total, desconto: 0, total, aPagar: total, custoTotal,
      lucro: total - custoTotal, taxaTotal: 0, liquido: total, lucroLiquido: total - custoTotal,
      pagamentos: [], recebido: 0, troco: 0, usados: [], usuario: this.quem(),
      dataLimite: dados.dataLimite || '', dataEntregaPrevista: dados.dataEntregaPrevista || '', obs: dados.obs || '',
      statusEntrega: 'aguardando', finReceberId: null
    });
    // pagamentos iniciais (sinal/entrada)
    const pags = []; let recebido = 0, taxaTot = 0;
    (dados.pagamentos || []).forEach(pay => { if ((+pay.valor || 0) > 0) { const p = this.logPay(venda, pay); pags.push(p); recebido += p.valor; taxaTot += p.taxa; } });
    // saldo em aberto → conta "a receber" no financeiro (não é recontagem do recebido)
    let finReceberId = null;
    const restante = total - recebido;
    if (restante > 0.009) {
      const venc = dados.dataLimite ? new Date(dados.dataLimite + 'T23:59:59').toISOString() : new Date(Date.now() + 30 * 86400000).toISOString();
      const rec = DB.logFin({ tipo: 'entrada', categoria: 'Venda — a receber', subcategoria: 'Pré-venda', descricao: 'Pré-venda ' + this.vLabel(venda) + ' — saldo a receber' + (venda.cliente ? ' · ' + venda.cliente : ''), valor: restante, taxa: 0, liquido: restante, status: 'areceber', pago: 0, emissao: agoraISO, vencimento: venc, data: venc, origem: 'venda', refId: venda.id, formaPagamento: 'A combinar' });
      finReceberId = rec.id;
    }
    DB.update('vendas', venda.id, { pagamentos: pags, recebido, taxaTotal: taxaTot, liquido: total - taxaTot, lucroLiquido: total - taxaTot - custoTotal, finReceberId });
    DB.logMov('venda', 'Pré-venda ' + this.vLabel(venda) + ' criada: ' + this.produtoResumo(venda) + ' — ' + (venda.cliente || '') + ' (' + Fmt.brl(total) + (restante > 0.009 ? ' · sinal ' + Fmt.brl(recebido) : '') + ')', { valor: total, refId: venda.id });
    return DB.get('vendas', venda.id);
  },

  /* ---------- baixa de estoque na entrega de TODOS os itens pendentes ---------- */
  baixaEntrega(v) {
    const itens = v.itens.slice(); let mudou = false;
    itens.forEach((it, idx) => {
      if (it.entrega !== 'prevenda') return;
      if (it.produtoId) { const pr = DB.get('produtos', it.produtoId); if (pr) DB.update('produtos', it.produtoId, { qtd: Math.max(0, (pr.qtd || 0) - it.qtd), reservado: Math.max(0, (pr.reservado || 0) - (it.reservado ? it.qtd : 0)) }); }
      itens[idx] = Object.assign({}, it, { entrega: 'entregue', entregueEm: new Date().toISOString(), reservado: false });
      mudou = true;
    });
    if (mudou) DB.update('vendas', v.id, { itens, temPrevenda: false, statusEntrega: 'entregue' });
    return mudou;
  },
  /* libera reservas (sem devolver estoque, pois pré-venda não baixou) */
  releaseReservas(v) {
    (v.itens || []).forEach(it => { if (it.entrega === 'prevenda' && it.reservado && it.produtoId) { const pr = DB.get('produtos', it.produtoId); if (pr) DB.update('produtos', it.produtoId, { reservado: Math.max(0, (pr.reservado || 0) - it.qtd) }); } });
  }
};

/* ================= TELA ================= */
Modules.prevendas = function () {
  setTimeout(() => Modules.pvRender(), 20);
  return `
  <div class="page-head"><div><h1>Pré-venda / Reservas</h1><p>Vendas com entrega futura — já contam no faturamento; o estoque baixa só na entrega</p></div>
    <div class="actions">${(typeof App === 'undefined' || App.isAdmin()) ? '<button class="btn-ghost" onclick="Modules.pvLimparTestes()">🧹 Limpar canceladas</button>' : ''}<button class="btn-primary" onclick="Modules.pvForm()">+ Nova pré-venda</button></div></div>
  <div class="grid kpis" id="pv-kpis" style="margin-bottom:16px"></div>
  <div id="pv-alertas" style="margin-bottom:16px"></div>
  <div class="toolbar" style="flex-wrap:wrap;gap:8px">
    <select id="pv-fstatus" onchange="Modules.pvRender()">
      <option value="">Todos os status</option>
      <option value="nao_pago">Não pago</option><option value="parcial">Parcialmente pago</option>
      <option value="pago">Pago</option><option value="vencido">Vencido</option>
      <option value="aguardando">Aguardando produto</option><option value="disponivel">Disponível p/ retirada</option>
      <option value="entregue">Entregue</option><option value="cancelado">Cancelado</option>
      <option value="naopagos">Em aberto (restante &gt; 0)</option>
    </select>
    <input id="pv-fprod" placeholder="Filtrar por produto..." oninput="Modules.pvRender()">
    <input class="grow" id="pv-fbusca" placeholder="Buscar cliente, telefone ou nº do pedido..." oninput="Modules.pvRender()">
  </div>
  <div id="pv-table" style="margin-top:18px"></div>`;
};

Modules.pvData = function () {
  const status = fval('pv-fstatus'), prod = (fval('pv-fprod') || '').toLowerCase(), busca = (fval('pv-fbusca') || '').toLowerCase();
  let list = PV.listAll().slice().sort((a, b) => {
    const rank = { vencido: 0, parcial: 1, nao_pago: 2, pago: 3, cancelado: 5 };
    const sa = rank[PV.payStatus(a)] ?? 4, sb = rank[PV.payStatus(b)] ?? 4;
    if (sa !== sb) return sa - sb;
    return (b.numero || 0) - (a.numero || 0);
  });
  return list.filter(v => {
    const ps = PV.payStatus(v), es = PV.entStatus(v);
    if (status === 'naopagos') { if (PV.restante(v) <= 0.009 || v.cancelada) return false; }
    else if (status && status !== ps && status !== es) return false;
    if (prod && !PV.produtoResumo(v).toLowerCase().includes(prod)) return false;
    if (busca && !((v.cliente || '').toLowerCase().includes(busca) || (v.telefone || '').toLowerCase().includes(busca) || String(v.numero || '').includes(busca))) return false;
    return true;
  });
};

Modules.pvRender = function () {
  if (!document.getElementById('pv-kpis')) return;
  const ativas = PV.listAll().filter(v => !v.cancelada);
  const totReservas = ativas.length;
  const totVendido = ativas.reduce((s, v) => s + (v.total || 0), 0);
  const totRecebido = ativas.reduce((s, v) => s + PV.pago(v), 0);
  const totPend = ativas.filter(v => !PV.entregue(v)).reduce((s, v) => s + PV.restante(v), 0);
  const nPend = ativas.filter(v => PV.restante(v) > 0.009).length;
  const nVenc = ativas.filter(v => PV.payStatus(v) === 'vencido').length;
  const nRetirar = ativas.filter(v => !PV.entregue(v) && PV.restante(v) <= 0.009).length;
  document.getElementById('pv-kpis').innerHTML =
    kpi('Pré-vendas ativas', Fmt.num(totReservas), Fmt.brl(totVendido) + ' já no faturamento', '📋', 'blue') +
    kpi('Total recebido', Fmt.brl(totRecebido), 'entrou no financeiro', '💰', 'green') +
    kpi('A receber', Fmt.brl(totPend), nPend + ' pedido(s) em aberto', '⏳', 'amber') +
    kpi('Prontas p/ retirar', Fmt.num(nRetirar), nVenc + ' vencida(s)', '📦', nVenc ? 'red' : 'purple');

  // Alertas
  const venc = [], hoje = [], breve = [], retirar = [];
  ativas.forEach(v => {
    if (PV.entregue(v)) return;
    if (PV.restante(v) <= 0.009) { retirar.push(v); return; }
    const ps = PV.payStatus(v), d = PV.diasAteLimite(v);
    if (ps === 'vencido') venc.push(v);
    else if (d === 0) hoje.push(v);
    else if (d != null && d > 0 && d <= 3) breve.push(v);
  });
  const ac = (titulo, arr, cls, ico) => arr.length ? `<div class="pv-alert ${cls}"><div class="pv-alert-h">${ico} ${titulo} <span class="badge b-gray">${arr.length}</span></div>
    <div class="pv-alert-list">${arr.slice(0, 8).map(v => `<span class="pv-chip" onclick="Modules.pvDetail('${v.id}')">${PV.vLabel(v)} ${esc(v.cliente || '')} · ${esc(PV.produtoResumo(v))} · ${cls === 'green' ? 'pago' : Fmt.brl(PV.restante(v))}</span>`).join('')}</div></div>` : '';
  document.getElementById('pv-alertas').innerHTML =
    ac('Pagamento vencido', venc, 'red', '🚨') + ac('Vence hoje', hoje, 'amber', '⏰') +
    ac('Vence em até 3 dias', breve, 'blue', '📅') + ac('Pagas — prontas para retirada', retirar, 'green', '📦');

  // Tabela
  const rows = this.pvData().map(v => {
    const rest = PV.restante(v), ativo = !PV.entregue(v) && !v.cancelada, es = PV.entStatus(v);
    return `<tr>
      <td class="strong">${PV.vLabel(v)}<div class="muted" style="font-size:10.5px">${Fmt.date(v.data)}</div></td>
      <td><div class="strong">${esc(v.cliente || '—')}</div><div class="muted" style="font-size:11px">${esc(v.telefone || '—')}</div></td>
      <td>${esc(PV.produtoResumo(v))}<div class="muted" style="font-size:11px">${PV.qtdTotal(v)} un${v.dataLimite ? ' · limite ' + Fmt.date(v.dataLimite + 'T12:00:00') : ''}</div></td>
      <td class="num">${Fmt.brl(v.total)}</td>
      <td class="num" style="color:var(--green)">${Fmt.brl(PV.pago(v))}</td>
      <td class="num strong" style="color:${rest > 0 ? 'var(--red)' : 'var(--green)'}">${Fmt.brl(rest)}</td>
      <td>${PV.payBadge(v)}</td>
      <td>${PV.entBadge(v)}</td>
      <td class="num pv-actions">
        ${ativo && rest > 0.009 ? `<button class="btn-icon" title="Registrar pagamento" onclick="Modules.pvPagar('${v.id}')">💵</button>` : ''}
        ${ativo && es === 'aguardando' ? `<button class="btn-icon" title="Marcar disponível p/ retirada" onclick="Modules.pvDisponivel('${v.id}')">🟦</button>` : ''}
        ${ativo && rest <= 0.009 ? `<button class="btn-icon" title="Entregar (baixa no estoque)" onclick="Modules.pvEntregar('${v.id}')">📦</button>` : ''}
        ${v.telefone ? `<button class="btn-icon" title="WhatsApp" onclick="Modules.pvWhats('${v.id}')">💬</button>` : ''}
        ${ativo ? `<button class="btn-icon" title="Editar dados" onclick="Modules.pvForm('${v.id}')">✏️</button>` : ''}
        ${ativo && (typeof App === 'undefined' || App.can('podeCancelar') || App.isAdmin()) ? `<button class="btn-icon" title="Cancelar (mantém no histórico, estorna)" onclick="Modules.pvCancel('${v.id}')">🚫</button>` : ''}
        <button class="btn-icon" title="Ver venda completa" onclick="Modules.vdDetail('${v.id}')">🔎</button>
      </td></tr>`;
  }).join('');
  document.getElementById('pv-table').innerHTML = `<div class="table-wrap"><table>
    <thead><tr><th>Pedido</th><th>Cliente</th><th>Produto</th><th class="num">Total</th><th class="num">Pago</th><th class="num">Restante</th><th>Pagamento</th><th>Entrega</th><th></th></tr></thead>
    <tbody>${rows || '<tr><td colspan="9" class="muted" style="text-align:center;padding:34px">Nenhuma pré-venda encontrada.</td></tr>'}</tbody></table></div>
    <div class="muted" style="font-size:11.5px;margin-top:8px">Toda pré-venda também aparece em Vendas do Dia, Dashboard e Relatórios (conta como venda desde o dia em que foi feita). A entrega só dá baixa no estoque — não cria outra venda.</div>`;
};

/* ---------- Cadastro / edição ---------- */
Modules.pvForm = function (id) {
  const v = id ? DB.get('vendas', id) : null;
  const it0 = v ? (v.itens || [])[0] || {} : {};
  const prods = DB.all('produtos').slice().sort((a, b) => a.nome.localeCompare(b.nome));
  const hoje = new Date().toISOString().slice(0, 10);
  const formas = (typeof Taxas !== 'undefined') ? Taxas.ativas().map(t => t.key) : ['PIX', 'Dinheiro', 'Débito', 'Crédito à vista'];
  const editando = !!id;
  Modal.open({
    title: editando ? '✏️ Editar pré-venda ' + PV.vLabel(v) : '📋 Nova pré-venda', wide: true,
    body: `<div class="form-grid">
      <div class="field"><label>Nome do cliente *</label><input id="pv-cliente" value="${esc(v ? (v.cliente || '') : '')}"></div>
      <div class="field"><label>Telefone / WhatsApp</label><input id="pv-tel" placeholder="11 99999-9999" value="${esc(v ? (v.telefone || '') : '')}"></div>
      <div class="field full"><label>Produto *</label><input id="pv-prod" list="pv-prodlist" placeholder="Ex: GTA VI PS5" value="${esc(it0.nome || '')}" onchange="Modules.pvPickProd()" ${editando ? 'disabled' : ''}>
        <datalist id="pv-prodlist">${prods.map(x => `<option value="${esc(x.nome)}">${x.sku} · ${Fmt.brl(x.preco)} · ${PV.available(x)} disp.</option>`).join('')}</datalist>
        <div class="muted" style="font-size:11px;margin-top:3px">Pode ser um produto que ainda não chegou. Se já houver em estoque, a unidade é reservada e a baixa ocorre na entrega.</div></div>
      <div class="field"><label>Quantidade</label><input id="pv-qtd" type="number" min="1" value="${it0.qtd || 1}" oninput="Modules.pvCalcTotal()" ${editando ? 'disabled' : ''}></div>
      <div class="field"><label>Valor unitário (R$) <span class="muted" style="font-weight:400">opcional</span></label><input id="pv-unit" type="text" inputmode="decimal" placeholder="ex: 499,90" value="${it0.preco != null && editando ? String(it0.preco).replace('.', ',') : ''}" oninput="Modules.pvCalcTotal()" ${editando ? 'disabled' : ''}></div>
      <div class="field"><label>Valor total da venda (R$) *</label><input id="pv-total" type="text" inputmode="decimal" placeholder="ex: 499,90" value="${v ? String(v.total).replace('.', ',') : ''}" ${editando ? 'disabled' : ''}></div>
      ${editando ? '' : `<div class="field"><label>Sinal / entrada já pago (R$) <span class="muted" style="font-weight:400">opcional</span></label><input id="pv-sinal" type="text" inputmode="decimal" placeholder="0,00"></div>
      <div class="field"><label>Forma do pagamento inicial</label><select id="pv-forma">${formas.map(f => `<option>${esc(f)}</option>`).join('')}</select></div>`}
      <div class="field"><label>Data da venda</label><input id="pv-datares" type="date" value="${v && v.data ? v.data.slice(0, 10) : hoje}" ${editando ? 'disabled' : ''}></div>
      <div class="field"><label>Data limite p/ pagamento</label><input id="pv-limite" type="date" value="${v ? (v.dataLimite || '') : ''}"></div>
      <div class="field"><label>Data prevista de entrega</label><input id="pv-entrega" type="date" value="${v ? (v.dataEntregaPrevista || '') : ''}"></div>
      <div class="field full"><label>Observações</label><input id="pv-obs" value="${esc(v ? (v.obs || '') : '')}"></div>
    </div>${editando ? '<div class="muted" style="font-size:11.5px;margin-top:8px">Para mudar produto, quantidade ou valor, cancele e crie de novo (mantém o histórico correto).</div>' : ''}`,
    foot: `<button class="btn-ghost" onclick="Modal.close()">Cancelar</button><button class="btn-primary" onclick="Modules.pvSave('${id || ''}')">${editando ? 'Salvar dados' : 'Criar pré-venda'}</button>`
  });
};
Modules.pvPickProd = function () {
  const nome = fval('pv-prod');
  const p = DB.all('produtos').find(x => x.nome.toLowerCase() === nome.toLowerCase());
  if (p) { const u = document.getElementById('pv-unit'); if (u && !u.value) { u.value = String(p.preco).replace('.', ','); this.pvCalcTotal(); } }
};
Modules.pvCalcTotal = function () {
  const qtd = parseInt(fval('pv-qtd')) || 0, unit = moneyBR(fval('pv-unit'));
  const t = document.getElementById('pv-total');
  if (t && !isNaN(unit) && qtd > 0) t.value = String(Math.round(unit * qtd * 100) / 100).replace('.', ',');
};
Modules.pvSave = function (id) {
  const cliente = fval('pv-cliente');
  if (!cliente) return Toast.err('Informe o nome do cliente.');
  // EDIÇÃO: só dados de contato/datas/obs (não recria pagamentos nem muda valor)
  if (id) {
    DB.update('vendas', id, { cliente, telefone: fval('pv-tel'), dataLimite: fval('pv-limite') || '', dataEntregaPrevista: fval('pv-entrega') || '', obs: fval('pv-obs') });
    Toast.ok('Pré-venda atualizada.'); Modal.close(); App.go('prevendas'); return;
  }
  const produtoNome = fval('pv-prod');
  if (!produtoNome) return Toast.err('Informe o produto.');
  let valorTotal = moneyBR(fval('pv-total'));
  const unitTmp = moneyBR(fval('pv-unit')), qtd = parseInt(fval('pv-qtd')) || 1;
  if ((isNaN(valorTotal) || valorTotal <= 0) && !isNaN(unitTmp) && unitTmp > 0) valorTotal = Math.round(unitTmp * qtd * 100) / 100;
  if (isNaN(valorTotal) || valorTotal <= 0) return Toast.err('Informe o valor total (ou o valor unitário) da venda.');
  const linked = DB.all('produtos').find(x => x.nome.toLowerCase() === produtoNome.toLowerCase());
  const precoUnit = !isNaN(unitTmp) && unitTmp > 0 ? unitTmp : Math.round((valorTotal / qtd) * 100) / 100;
  const item = { produtoId: linked ? linked.id : null, sku: linked ? linked.sku : null, nome: produtoNome, qtd, preco: precoUnit, custo: linked ? (linked.custoMedio || linked.custo || 0) : 0, categoria: linked ? linked.categoria : '—', condicao: linked ? linked.condicao : 'novo' };
  const pagamentos = [];
  const sinal = moneyBR(fval('pv-sinal'));
  if (!isNaN(sinal) && sinal > 0) pagamentos.push({ forma: fval('pv-forma') || 'Dinheiro', valor: Math.min(sinal, valorTotal) });
  const dataVenda = (fval('pv-datares') || new Date().toISOString().slice(0, 10)) + 'T12:00:00';
  const v = PV.criar({ cliente, telefone: fval('pv-tel'), itens: [item], pagamentos, dataLimite: fval('pv-limite') || '', dataEntregaPrevista: fval('pv-entrega') || '', obs: fval('pv-obs'), data: new Date(dataVenda).toISOString() });
  Toast.ok('Pré-venda ' + PV.vLabel(v) + ' criada! Já conta como venda hoje.');
  Modal.close(); App.go('prevendas');
};

/* ---------- Pagamento do saldo ---------- */
Modules.pvPagar = function (id) {
  const v = DB.get('vendas', id); if (!v) return;
  const rest = PV.restante(v);
  const formas = (typeof Taxas !== 'undefined') ? Taxas.ativas().map(t => t.key) : ['PIX', 'Dinheiro', 'Débito', 'Crédito à vista'];
  Modal.open({
    title: '💵 Registrar pagamento — ' + PV.vLabel(v),
    body: `<div class="card" style="background:var(--bg-2);margin-bottom:14px">
        <div class="mini-stat"><span>Cliente</span><b>${esc(v.cliente || '—')}</b></div>
        <div class="mini-stat"><span>Produto</span><b>${esc(PV.produtoResumo(v))}</b></div>
        <div class="mini-stat"><span>Valor total</span><b>${Fmt.brl(v.total)}</b></div>
        <div class="mini-stat"><span>Já pago</span><b style="color:var(--green)">${Fmt.brl(PV.pago(v))}</b></div>
        <div class="mini-stat" style="font-size:15px"><span class="strong">Restante</span><b style="color:var(--red)">${Fmt.brl(rest)}</b></div>
      </div>
      <div class="form-grid">
        <div class="field"><label>Valor do pagamento (R$)</label><input id="pvp-valor" type="text" inputmode="decimal" value="${String(Math.round(rest * 100) / 100).replace('.', ',')}"></div>
        <div class="field"><label>Forma de pagamento</label><select id="pvp-forma">${formas.map(f => `<option>${esc(f)}</option>`).join('')}</select></div>
        <div class="field full"><label>Observação</label><input id="pvp-obs" placeholder="opcional"></div>
      </div>
      <div class="muted" style="font-size:11.5px;margin-top:6px">Entra no financeiro como recebido agora. Não altera o faturamento (já contado na venda).</div>`,
    foot: `<button class="btn-ghost" onclick="Modal.close()">Cancelar</button><button class="btn-primary" onclick="Modules.pvPagarSave('${id}')">Confirmar pagamento</button>`
  });
};
Modules.pvPagarSave = function (id) {
  const v = DB.get('vendas', id); if (!v) return;
  const valor = moneyBR(fval('pvp-valor'));
  if (isNaN(valor) || valor <= 0) return Toast.err('Informe um valor válido.');
  if (valor > PV.restante(v) + 0.01) return Toast.err('Valor maior que o restante (' + Fmt.brl(PV.restante(v)) + ').');
  const p = PV.logPay(v, { forma: fval('pvp-forma') || 'Dinheiro', valor, data: new Date().toISOString() });
  const pagamentos = (v.pagamentos || []).concat([p]);
  const recebido = (v.recebido || 0) + valor, taxaTotal = (v.taxaTotal || 0) + p.taxa;
  const restante = (v.total || 0) - recebido;
  // atualiza/remove a conta "a receber"
  let finReceberId = v.finReceberId;
  if (finReceberId) {
    if (restante <= 0.009) { DB.remove('financeiro', finReceberId); finReceberId = null; }
    else DB.update('financeiro', finReceberId, { valor: restante, liquido: restante });
  }
  DB.update('vendas', id, { pagamentos, recebido, taxaTotal, liquido: (v.total || 0) - taxaTotal, lucroLiquido: (v.total || 0) - taxaTotal - (v.custoTotal || 0), finReceberId });
  DB.logMov('venda', 'Pagamento pré-venda ' + PV.vLabel(v) + ': ' + Fmt.brl(valor) + ' (' + p.tipo + ')', { valor, refId: id });
  Toast.ok(restante <= 0.009 ? 'Pré-venda ' + PV.vLabel(v) + ' quitada! 🎉' : 'Pagamento registrado. Restante: ' + Fmt.brl(restante));
  Modal.close(); App.go('prevendas');
};

/* ---------- Marcar disponível ---------- */
Modules.pvDisponivel = function (id) {
  const v = DB.get('vendas', id); if (!v) return;
  DB.update('vendas', id, { statusEntrega: 'disponivel' });
  DB.logMov('venda', 'Pré-venda ' + PV.vLabel(v) + ' disponível para retirada — ' + (v.cliente || ''), { valor: 0, refId: id });
  Toast.ok('Marcada como disponível para retirada.'); App.go('prevendas');
};

/* ---------- Entregar (baixa definitiva, SEM criar venda nova) ---------- */
Modules.pvEntregar = function (id) {
  const v = DB.get('vendas', id); if (!v) return;
  if (PV.restante(v) > 0.009) return Toast.err('Quite o pagamento antes de entregar (restante ' + Fmt.brl(PV.restante(v)) + ').');
  if (PV.entregue(v)) return Toast.err('Esta pré-venda já foi entregue.');
  const its = PV.pendentes(v).filter(it => it.produtoId);
  let aviso = '';
  its.forEach(it => { const p = DB.get('produtos', it.produtoId); if (p && p.qtd < it.qtd) aviso += '<div class="muted" style="margin-top:8px">⚠️ Estoque de ' + esc(it.nome) + ' (' + p.qtd + ') menor que o pedido (' + it.qtd + '). Faça a Entrada de Estoque antes.</div>'; });
  if (!its.length) aviso = '<div class="muted" style="margin-top:8px">⚠️ Produto não vinculado ao estoque — será marcado como entregue sem baixa.</div>';
  Modal.confirm('Confirmar entrega da pré-venda <b>' + PV.vLabel(v) + '</b> (' + esc(PV.produtoResumo(v)) + ') para <b>' + esc(v.cliente || 'cliente') + '</b>?<br>Dá baixa no estoque. O faturamento já foi registrado na venda e não muda.' + aviso, () => {
    PV.baixaEntrega(v);
    DB.logMov('venda', 'Pré-venda ' + PV.vLabel(v) + ' ENTREGUE: ' + PV.produtoResumo(v) + ' — ' + (v.cliente || ''), { valor: v.total, refId: id });
    Toast.ok('Pré-venda ' + PV.vLabel(v) + ' entregue! Estoque baixado.'); Modal.close(); App.go('prevendas');
  }, 'Confirmar entrega');
};

/* ---------- Entregar UM item dentro de uma venda (mista, sem duplicar) ---------- */
Modules.pvEntregarItem = function (vendaId, idx) {
  const v = DB.get('vendas', vendaId); if (!v || !v.itens || !v.itens[idx]) return;
  const it = v.itens[idx];
  if (it.entrega !== 'prevenda') return Toast.err('Este item já foi entregue.');
  const prod = it.produtoId ? DB.get('produtos', it.produtoId) : null;
  let aviso = '';
  if (prod && prod.qtd < it.qtd) aviso = '<div class="muted" style="margin-top:8px">⚠️ Estoque atual (' + prod.qtd + ') menor que o pedido (' + it.qtd + '). Faça a Entrada de Estoque antes, ou o estoque ficará zerado.</div>';
  Modal.confirm('Entregar <b>' + it.qtd + 'x ' + esc(it.nome) + '</b> da venda <b>' + PV.vLabel(v) + '</b> para <b>' + esc(v.cliente || 'cliente') + '</b>?<br>Dá baixa no estoque desse item e marca como entregue. A venda e o financeiro não mudam.' + aviso, () => {
    if (prod) { const nq = Math.max(0, (prod.qtd || 0) - it.qtd); const patch = { qtd: nq }; if (it.reservado) patch.reservado = Math.max(0, (prod.reservado || 0) - it.qtd); DB.update('produtos', it.produtoId, patch); }
    const itens = v.itens.slice();
    itens[idx] = Object.assign({}, it, { entrega: 'entregue', entregueEm: new Date().toISOString(), reservado: false });
    const aindaPendente = itens.some(x => x.entrega === 'prevenda');
    DB.update('vendas', vendaId, { itens, temPrevenda: aindaPendente, statusEntrega: aindaPendente ? (v.statusEntrega || 'aguardando') : 'entregue' });
    DB.logMov('venda', 'Item de pré-venda entregue: ' + it.qtd + 'x ' + it.nome + ' — venda ' + PV.vLabel(v) + ' · ' + (v.cliente || ''), { valor: it.preco * it.qtd, refId: vendaId });
    Toast.ok('Item entregue e baixado do estoque! Venda ' + PV.vLabel(v) + '.'); Modal.close(); App.go('prevendas');
  }, 'Entregar item');
};
/* ---------- Pós-venda: marcar item ENTREGUE de volta como pré-venda ---------- */
Modules.pvMarcarItemPrevenda = function (vendaId, idx) {
  if (typeof App !== 'undefined' && !App.isAdmin()) return Toast.err('Apenas o administrador pode alterar o status do item.');
  const v = DB.get('vendas', vendaId); if (!v || !v.itens || !v.itens[idx]) return;
  const it = v.itens[idx];
  if (it.entrega === 'prevenda') return Toast.err('Este item já está em pré-venda.');
  Modal.open({
    title: '📋 Marcar item como pré-venda',
    body: `<p class="muted">Item: <b>${esc(it.nome)}</b> · venda ${PV.vLabel(v)}</p>
      <p class="muted" style="font-size:12px">O estoque baixado deste item será devolvido e ele passará a <b>aguardar entrega</b>. A venda e o financeiro não mudam.</p>
      <div class="form-grid"><div class="field"><label>Cliente *</label><input id="pmi-cli" value="${esc(v.cliente || '')}"></div>
      <div class="field"><label>Telefone / WhatsApp</label><input id="pmi-tel" value="${esc(v.telefone || '')}"></div>
      <div class="field"><label>Data prevista de entrega</label><input id="pmi-data" type="date" value="${it.dataPrevista || ''}"></div></div>`,
    foot: `<button class="btn-ghost" onclick="Modal.close()">Cancelar</button><button class="btn-primary" onclick="Modules.pvMarcarItemPrevendaSave('${vendaId}',${idx})">Confirmar</button>`
  });
};
Modules.pvMarcarItemPrevendaSave = function (vendaId, idx) {
  const v = DB.get('vendas', vendaId); if (!v || !v.itens[idx]) return;
  const it = v.itens[idx];
  const cli = fval('pmi-cli'); if (!cli) return Toast.err('Informe o nome do cliente.');
  if (it.produtoId && it.entrega === 'entregue') { const p = DB.get('produtos', it.produtoId); if (p) DB.update('produtos', it.produtoId, { qtd: (p.qtd || 0) + it.qtd }); } // devolve estoque
  const itens = v.itens.slice();
  itens[idx] = Object.assign({}, it, { entrega: 'prevenda', entregueEm: null, reservado: false, dataPrevista: fval('pmi-data') || '' });
  DB.update('vendas', vendaId, { itens, temPrevenda: true, statusEntrega: 'aguardando', cliente: cli, telefone: fval('pmi-tel') || v.telefone || '' });
  DB.logMov('venda', 'Item marcado como pré-venda: ' + it.nome + ' — venda ' + PV.vLabel(v), { valor: 0, refId: vendaId });
  Toast.ok('Item movido para pré-venda.'); Modal.close(); App.go('vendasDia');
};

/* ---------- Cancelar (estorna financeiro/caixa, libera reserva, devolve estoque entregue) ---------- */
Modules.pvCancel = function (id) {
  const v = DB.get('vendas', id); if (!v) return;
  if (typeof App !== 'undefined' && !(App.can('podeCancelar') || App.isAdmin())) return Toast.err('Você não tem permissão para cancelar.');
  Modal.confirm('Cancelar a pré-venda <b>' + PV.vLabel(v) + '</b> de <b>' + esc(v.cliente || '') + '</b> (' + esc(PV.produtoResumo(v)) + ')?<br>Os pagamentos serão estornados do financeiro/caixa, a reserva de estoque liberada e a venda sai do faturamento. Fica no histórico.', () => {
    PV.cancelarVenda(v, 'Cancelada pelo usuário');
    Toast.ok('Pré-venda ' + PV.vLabel(v) + ' cancelada e estornada.'); Modal.close(); App.go('prevendas');
  }, 'Cancelar pré-venda');
};
/* estorno reutilizável (também usado por vdCancel para pré-vendas) */
PV.cancelarVenda = function (v, motivo) {
  // devolve estoque só de itens já ENTREGUES (que baixaram); libera reserva dos pendentes
  (v.itens || []).forEach(it => {
    if (!it.produtoId) return;
    const p = DB.get('produtos', it.produtoId); if (!p) return;
    if (it.entrega === 'entregue') DB.update('produtos', it.produtoId, { qtd: (p.qtd || 0) + it.qtd });
    else if (it.reservado) DB.update('produtos', it.produtoId, { reservado: Math.max(0, (p.reservado || 0) - it.qtd) });
  });
  // remove lançamentos financeiros da venda (recebidos e a receber)
  DB.all('financeiro').filter(f => f.refId === v.id && (f.origem === 'venda' || f.origem === 'prevenda')).forEach(f => DB.remove('financeiro', f.id));
  // estorna caixa (dinheiro)
  if (typeof Caixa !== 'undefined' && Caixa.estornarVenda) Caixa.estornarVenda(v);
  DB.update('vendas', v.id, { cancelada: true, canceladaEm: new Date().toISOString(), motivoCancelamento: motivo || '', canceladaPor: PV.quem() });
  DB.logMov('devolucao', 'Pré-venda ' + PV.vLabel(v) + ' cancelada — estornada (' + Fmt.brl(v.total) + ')' + (motivo ? ' · ' + motivo : ''), { valor: v.total, refId: v.id });
};

/* ---------- Excluir definitivamente (admin, para testes) ---------- */
Modules.pvExcluir = function (id) {
  if (typeof App !== 'undefined' && !App.isAdmin()) return Toast.err('Apenas o administrador pode excluir.');
  const v = DB.get('vendas', id); if (!v) return;
  Modal.confirm('Excluir definitivamente a pré-venda <b>' + PV.vLabel(v) + '</b> (' + esc(PV.produtoResumo(v)) + ')?<br>Reverte pagamentos e libera reserva. <b>Não pode ser desfeito.</b>', () => {
    if (!v.cancelada) PV.cancelarVenda(v, 'Excluída');
    DB.remove('vendas', id);
    DB.logMov('devolucao', 'Pré-venda ' + PV.vLabel(v) + ' excluída', { valor: 0 });
    Toast.ok('Pré-venda ' + PV.vLabel(v) + ' excluída.'); Modal.close(); App.go('prevendas');
  }, 'Excluir definitivamente');
};
Modules.pvLimparTestes = function () {
  if (typeof App !== 'undefined' && !App.isAdmin()) return Toast.err('Apenas o administrador pode limpar.');
  const canc = PV.listAll().filter(v => v.cancelada);
  if (!canc.length) return Toast.ok('Não há pré-vendas canceladas para remover.');
  Modal.confirm('Remover definitivamente <b>' + canc.length + '</b> pré-venda(s) já cancelada(s)? Não pode ser desfeito.', () => {
    canc.forEach(v => { DB.all('financeiro').filter(f => f.refId === v.id).forEach(f => DB.remove('financeiro', f.id)); DB.remove('vendas', v.id); });
    Toast.ok(canc.length + ' pré-venda(s) cancelada(s) removida(s).'); Modal.close(); App.go('prevendas');
  }, 'Remover canceladas');
};

/* ---------- Criar pré-venda a partir do carrinho do PDV ---------- */
Modules.pvFromCart = function (cliente, telefone, pays) {
  const c = this.cart;
  const itens = c.itens.map(i => { const pr = DB.get('produtos', i.produtoId) || {}; return { produtoId: i.produtoId, sku: i.sku, nome: i.nome, qtd: i.qtd, preco: i.preco, custo: i.custo, categoria: pr.categoria || '—', condicao: pr.condicao || 'novo' }; });
  const pagamentos = (pays || []).filter(p => (+p.valor || 0) > 0).map(p => ({ forma: p.method, valor: +p.valor, parcelas: p.parcelas || 1 }));
  const v = PV.criar({ cliente, telefone: telefone || '', itens, pagamentos, obs: 'Gerada pelo PDV' });
  this.clearCart(); this.pdvSearch(); Modal.close();
  Toast.ok('Pré-venda ' + PV.vLabel(v) + ' registrada! Já conta como venda. Veja em Pré-venda / Reservas.');
};

/* ---------- Painel de pré-vendas dentro do PDV ---------- */
Modules.pvPDVPanel = function () {
  Modal.open({
    title: '📋 Pré-vendas / Reservas', wide: true,
    body: `<input id="pvpdv-q" class="grow" style="width:100%;margin-bottom:12px" placeholder="Buscar por nº do pedido, cliente, telefone ou produto..." oninput="Modules.pvPDVList()" autofocus>
      <div id="pvpdv-list"></div>`,
    foot: `<button class="btn-primary" style="margin-right:auto" onclick="Modal.close();Modules.pvForm()">+ Nova pré-venda</button><button class="btn-ghost" onclick="Modal.close()">Fechar</button>`
  });
  setTimeout(() => Modules.pvPDVList(), 20);
};
Modules.pvPDVList = function () {
  const host = document.getElementById('pvpdv-list'); if (!host) return;
  const q = (fval('pvpdv-q') || '').toLowerCase();
  let list = PV.listAll().filter(v => !v.cancelada && !PV.entregue(v)).slice().sort((a, b) => (b.numero || 0) - (a.numero || 0));
  if (q) list = list.filter(v => String(v.numero || '').includes(q) || (v.cliente || '').toLowerCase().includes(q) || (v.telefone || '').toLowerCase().includes(q) || PV.produtoResumo(v).toLowerCase().includes(q));
  host.innerHTML = list.length ? `<div class="table-wrap"><table>
    <thead><tr><th>Pedido</th><th>Cliente</th><th>Produto</th><th class="num">Restante</th><th>Pagto.</th><th>Entrega</th><th></th></tr></thead>
    <tbody>${list.slice(0, 30).map(v => { const rest = PV.restante(v); return `<tr>
      <td class="strong">${PV.vLabel(v)}</td>
      <td>${esc(v.cliente || '')}<div class="muted" style="font-size:11px">${esc(v.telefone || '')}</div></td>
      <td>${esc(PV.produtoResumo(v))}</td>
      <td class="num strong" style="color:${rest > 0 ? 'var(--red)' : 'var(--green)'}">${Fmt.brl(rest)}</td>
      <td>${PV.payBadge(v)}</td><td>${PV.entBadge(v)}</td>
      <td class="num pv-actions">
        ${rest > 0.009 ? `<button class="btn-icon" title="Registrar pagamento" onclick="Modules.pvPagar('${v.id}')">💵</button>` : ''}
        ${rest <= 0.009 ? `<button class="btn-icon" title="Entregar" onclick="Modules.pvEntregar('${v.id}')">📦</button>` : ''}
        <button class="btn-icon" title="Detalhes" onclick="Modules.pvDetail('${v.id}')">🔎</button></td></tr>`; }).join('')}</tbody></table></div>`
    : '<div class="empty-state"><div class="big">📋</div>Nenhuma pré-venda em aberto.</div>';
};

/* ---------- WhatsApp ---------- */
Modules.pvWhats = function (id) {
  const v = DB.get('vendas', id); if (!v) return;
  const tel = (v.telefone || '').replace(/\D/g, '');
  if (!tel) return Toast.err('Cliente sem telefone cadastrado.');
  const num = tel.length <= 11 ? '55' + tel : tel;
  const rest = PV.restante(v);
  let msg;
  if (PV.entStatus(v) === 'disponivel' || (rest <= 0.009 && !PV.entregue(v))) msg = `Olá ${v.cliente || ''}! Seu pedido *${PV.vLabel(v)}* (${PV.produtoResumo(v)}) está disponível para retirada na Rico Games. 🎮`;
  else msg = `Olá ${v.cliente || ''}! Sobre sua pré-venda *${PV.vLabel(v)}* (${PV.produtoResumo(v)}) na Rico Games:\nValor total: ${Fmt.brl(v.total)}\nJá pago: ${Fmt.brl(PV.pago(v))}\nRestante: ${Fmt.brl(rest)}${v.dataLimite ? `\nData limite: ${Fmt.date(v.dataLimite + 'T12:00:00')}` : ''}`;
  window.open('https://wa.me/' + num + '?text=' + encodeURIComponent(msg), '_blank');
};
Modules.pvWhatsVenda = function (vendaId) { return Modules.pvWhats(vendaId); };

/* ---------- Detalhes ---------- */
Modules.pvDetail = function (id) {
  const v = DB.get('vendas', id); if (!v) return;
  const pags = v.pagamentos || [];
  const pagsHtml = pags.length ? `<div class="table-wrap"><table><thead><tr><th>Data</th><th>Forma</th><th class="num">Valor</th></tr></thead>
    <tbody>${pags.map(p => `<tr><td>${Fmt.date(p.data)}</td><td>${esc(p.tipo)}${p.parcelas > 1 ? ' ' + p.parcelas + 'x' : ''}</td><td class="num strong" style="color:var(--green)">${Fmt.brl(p.valor)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">Nenhum pagamento registrado ainda.</p>';
  const itensHtml = `<div class="table-wrap"><table><thead><tr><th>Produto</th><th class="num">Qtd</th><th class="num">Preço</th><th>Entrega</th></tr></thead>
    <tbody>${(v.itens || []).map(i => `<tr><td>${esc(i.nome)}</td><td class="num">${i.qtd}</td><td class="num">${Fmt.brl(i.preco)}</td><td>${i.entrega === 'prevenda' ? (i.reservado ? '<span class="badge b-blue">🔒 Reservado</span>' : '<span class="badge b-amber">⏳ Aguardando</span>') : '<span class="badge b-green">✔ Entregue</span>'}</td></tr>`).join('')}</tbody></table></div>`;
  Modal.open({
    title: '🔎 Pré-venda ' + PV.vLabel(v) + ' — ' + esc(v.cliente || ''),
    body: `<div class="card" style="background:var(--bg-2);margin-bottom:14px">
        <div class="mini-stat"><span>Nº</span><b>${PV.vLabel(v)}</b></div>
        <div class="mini-stat"><span>Cliente</span><b>${esc(v.cliente || '—')}</b></div>
        <div class="mini-stat"><span>Telefone</span><b>${esc(v.telefone || '—')}</b></div>
        <div class="mini-stat"><span>Data da venda</span><b>${Fmt.date(v.data)}</b></div>
        <div class="mini-stat"><span>Limite pagamento</span><b>${v.dataLimite ? Fmt.date(v.dataLimite + 'T12:00:00') : '—'}</b></div>
        <div class="mini-stat"><span>Entrega prevista</span><b>${v.dataEntregaPrevista ? Fmt.date(v.dataEntregaPrevista + 'T12:00:00') : '—'}</b></div>
        <div class="mini-stat"><span>Status pagamento</span><b>${PV.payBadge(v)}</b></div>
        <div class="mini-stat"><span>Status entrega</span><b>${PV.entBadge(v)}</b></div>
        ${v.obs ? `<div class="mini-stat"><span>Observações</span><b>${esc(v.obs)}</b></div>` : ''}
        ${v.cancelada ? `<div class="mini-stat"><span>Cancelada</span><b style="color:var(--red)">${esc(v.motivoCancelamento || 'sim')}</b></div>` : ''}
      </div>
      <div class="section-title" style="margin:0 0 8px">Itens</div>${itensHtml}
      <div class="section-title" style="margin:14px 0 8px">Pagamentos (no financeiro)</div>${pagsHtml}
      <div class="card" style="background:var(--bg-2);margin-top:14px">
        <div class="mini-stat"><span>Valor total (faturamento)</span><b>${Fmt.brl(v.total)}</b></div>
        <div class="mini-stat"><span>Total pago</span><b style="color:var(--green)">${Fmt.brl(PV.pago(v))}</b></div>
        <div class="mini-stat" style="font-size:15px"><span class="strong">Restante</span><b style="color:${PV.restante(v) > 0 ? 'var(--red)' : 'var(--green)'}">${Fmt.brl(PV.restante(v))}</b></div>
      </div>`,
    foot: `${(!PV.entregue(v) && !v.cancelada && PV.restante(v) > 0.009) ? `<button class="btn-primary" style="margin-right:auto" onclick="Modal.close();Modules.pvPagar('${id}')">💵 Pagamento</button>` : ''}${(!PV.entregue(v) && !v.cancelada && PV.restante(v) <= 0.009) ? `<button class="btn-primary" style="margin-right:auto" onclick="Modal.close();Modules.pvEntregar('${id}')">📦 Entregar</button>` : ''}<button class="btn-ghost" onclick="Modules.vdDetail('${id}')">Ver venda completa</button><button class="btn-ghost" onclick="Modal.close()">Fechar</button>`
  });
};

/* ================= MIGRAÇÃO: reservas antigas (coleção prevendas) → vendas ================= */
PV.migrarLegado = function () {
  const cfg = DB.all('config')[0];
  if (cfg && cfg.preMigradoV1) return { migrados: 0, jaFeito: true };
  const legados = DB.all('prevendas').filter(p => !p.migradoParaVenda);
  if (!legados.length) { if (cfg) DB.update('config', cfg.id, { preMigradoV1: true }); return { migrados: 0 }; }
  // backup de segurança antes de mexer
  try { if (typeof DB.snapshotBackup === 'function') DB.snapshotBackup(); } catch (e) {}
  let n = 0;
  legados.forEach(pv => {
    const itensBase = (pv.itens && pv.itens.length) ? pv.itens : [{ produtoId: pv.produtoId, sku: pv.sku, nome: pv.produtoNome, qtd: pv.qtd, preco: pv.valorUnit || (pv.valorTotal / (pv.qtd || 1)), custo: pv.custoUnit || 0 }];
    const entregue = !!pv.entregue;
    const itens = itensBase.map(i => ({
      produtoId: i.produtoId || null, sku: i.sku || null, nome: i.nome || pv.produtoNome, qtd: +i.qtd || 1,
      preco: +i.preco || (pv.valorTotal / (pv.qtd || 1)), precoOriginal: i.preco, custo: +i.custo || 0,
      categoria: i.categoria || '—', condicao: i.condicao || 'novo',
      entrega: entregue ? 'entregue' : 'prevenda', entregueEm: entregue ? (pv.entregueEm || pv.canceladoEm || null) : null,
      dataPrevista: pv.dataEntregaPrevista || '', reservado: !!(i.__res || (!entregue && i.produtoId))
    }));
    const total = pv.valorTotal || itens.reduce((s, i) => s + i.preco * i.qtd, 0);
    const custoTotal = itens.reduce((s, i) => s + (i.custo || 0) * i.qtd, 0);
    const pagamentos = (pv.pagamentos || []).map(p => ({ tipo: p.forma || 'Dinheiro', valor: +p.valor || 0, parcelas: p.parcelas || 1, taxa: p.taxa || 0, data: p.data || pv.dataReserva, finId: p.finId || null, caixaId: p.caixaId || null }));
    const recebido = pagamentos.reduce((s, p) => s + p.valor, 0);
    const taxaTot = pagamentos.reduce((s, p) => s + (p.taxa || 0), 0);
    const venda = DB.insert('vendas', {
      data: pv.dataReserva || pv.criadoEm || new Date().toISOString(), numero: pv.numero, tipo: 'pre_venda', itens,
      cliente: pv.cliente || null, telefone: pv.telefone || null, temPrevenda: !entregue,
      bruto: total, desconto: 0, total, aPagar: total, custoTotal,
      lucro: total - custoTotal, taxaTotal: taxaTot, liquido: total - taxaTot, lucroLiquido: total - taxaTot - custoTotal,
      pagamentos, recebido, troco: 0, usados: [], usuario: pv.usuario || 'Admin',
      dataLimite: pv.dataLimite || '', dataEntregaPrevista: pv.dataEntregaPrevista || '', obs: pv.obs || '',
      statusEntrega: entregue ? 'entregue' : (pv.statusEntrega || 'aguardando'),
      cancelada: !!pv.cancelado, canceladaEm: pv.canceladoEm || null, migradoDe: pv.id, finReceberId: null
    });
    // re-aponta financeiro/caixa existentes (NÃO recria recebidos → sem contagem dupla)
    DB.all('financeiro').filter(f => f.refId === pv.id && f.origem === 'prevenda').forEach(f => DB.update('financeiro', f.id, { refId: venda.id, origem: 'venda' }));
    DB.all('caixa').filter(cx => cx.refId === pv.id).forEach(cx => DB.update('caixa', cx.id, { refId: venda.id }));
    // saldo em aberto (ativo, não cancelado, não quitado) → conta a receber (info nova, não é recontagem)
    const restante = total - recebido;
    if (!pv.cancelado && !entregue && restante > 0.009) {
      const venc = pv.dataLimite ? new Date(pv.dataLimite + 'T23:59:59').toISOString() : new Date(Date.now() + 30 * 86400000).toISOString();
      const rec = DB.logFin({ tipo: 'entrada', categoria: 'Venda — a receber', subcategoria: 'Pré-venda', descricao: 'Pré-venda ' + PV.vLabel(venda) + ' — saldo a receber (migrada)', valor: restante, taxa: 0, liquido: restante, status: 'areceber', pago: 0, vencimento: venc, data: venc, origem: 'venda', refId: venda.id, formaPagamento: 'A combinar' });
      DB.update('vendas', venda.id, { finReceberId: rec.id });
    }
    DB.update('prevendas', pv.id, { migradoParaVenda: true, vendaId: venda.id });
    n++;
  });
  if (cfg) DB.update('config', cfg.id, { preMigradoV1: true });
  if (n) DB.logMov('venda', n + ' pré-venda(s) antiga(s) migrada(s) para o modelo unificado de vendas.', { valor: 0 });
  return { migrados: n };
};
