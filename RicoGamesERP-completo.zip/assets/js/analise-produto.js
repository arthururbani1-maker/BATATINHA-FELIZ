/* ============ RICO GAMES ERP — Análise de Produto (Relatórios) ============
   Relatório completo de desempenho de UM produto num período: KPIs, fórmulas,
   histórico de vendas, gráficos, comparativo com período anterior, estatísticas,
   análise inteligente e exportação. Usa apenas dados reais do ERP. */

Modules.apState = { sku: '', periodo: '30d', de: '', ate: '' };

Modules.apPeriodos = [['hoje', 'Hoje'], ['ontem', 'Ontem'], ['7d', 'Últimos 7 dias'], ['30d', 'Últimos 30 dias'], ['mes', 'Este mês'], ['mesAnterior', 'Mês passado'], ['6m', 'Últimos 6 meses'], ['12m', 'Último ano'], ['custom', 'Período personalizado']];

/* ---------- cálculo ---------- */
Modules.apCompute = function (sku, r) {
  const p = BI.prodInfo(sku) || {};
  const vendas = DB.all('vendas').filter(v => !v.cancelada && (() => { const d = new Date(v.data); return d >= r.start && d <= r.end; })());
  const rows = []; let qtd = 0, receita = 0, custo = 0, taxa = 0; const precos = [], diasSet = new Set();
  vendas.forEach(v => {
    const vtax = v.taxaTotal != null ? v.taxaTotal : 0, vtot = v.total || (v.itens || []).reduce((s, i) => s + i.preco * i.qtd, 0) || 1;
    let iq = 0, ir = 0, ic = 0, it = 0, precoUnit = 0;
    (v.itens || []).forEach(i => { if (i.sku !== sku) return; const cu = (i.custo > 0) ? i.custo : (p.custoMedio || p.custo || 0); iq += i.qtd; ir += i.preco * i.qtd; ic += cu * i.qtd; it += vtax * (i.preco * i.qtd / vtot); precoUnit = i.preco; precos.push(i.preco); });
    if (iq <= 0) return;
    qtd += iq; receita += ir; custo += ic; taxa += it; diasSet.add(new Date(v.data).toISOString().slice(0, 10));
    const lb = ir - ic, ll = lb - it;
    rows.push({ vendaId: v.id, data: v.data, numero: v.numero != null ? ('#' + v.numero) : ('#' + String(v.id).slice(-4)), qtd: iq, precoUnit, valorItem: ir, forma: (v.pagamentos || []).map(x => x.tipo + (x.parcelas > 1 ? ' ' + x.parcelas + 'x' : '')).join(', ') || '—', taxaItem: it, lucroBruto: lb, lucroLiq: ll, margem: ir ? ll / ir * 100 : 0 });
  });
  rows.sort((a, b) => new Date(b.data) - new Date(a.data));
  const bruto = receita - custo, liq = bruto - taxa, nv = rows.length;
  const T = { qtd, receita, custo, taxa, bruto, liq, margemV: receita ? liq / receita * 100 : 0, margemC: custo ? liq / custo * 100 : 0, ticket: nv ? receita / nv : 0, precoMedio: qtd ? receita / qtd : 0, custoMedio: qtd ? custo / qtd : 0, investido: custo, nv };
  const spanDias = Math.max(1, Math.round((r.end - r.start) / 86400000));
  const stats = { maxPreco: precos.length ? Math.max(...precos) : 0, minPreco: precos.length ? Math.min(...precos) : 0, precoMedio: T.precoMedio, qtdDia: qtd / spanDias, lucroUn: qtd ? liq / qtd : 0, diasComVenda: diasSet.size, diasPeriodo: spanDias, diasSemVenda: Math.max(0, spanDias - diasSet.size) };
  return { p, rows, T, stats };
};

/* ---------- buckets p/ gráficos ---------- */
Modules.apBuckets = function (rows, r) {
  const span = (r.end - r.start) / 86400000, out = [];
  const push = (label, ini, fim) => out.push({ label, ini: +ini, fim: +fim, qtd: 0, fat: 0, liq: 0 });
  const mn = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  if (span <= 1.5) { const s = new Date(r.start); s.setMinutes(0, 0, 0); for (let t = +s; t <= +r.end && out.length < 26; t += 3600000) { const d = new Date(t); push(d.getHours() + 'h', t, t + 3600000); } }
  else if (span <= 45) { const s = new Date(r.start); s.setHours(0, 0, 0, 0); for (let t = +s; t <= +r.end && out.length < 46; t += 86400000) { const d = new Date(t); push(d.getDate() + '/' + (d.getMonth() + 1), t, t + 86400000); } }
  else if (span <= 200) { const s = new Date(r.start); s.setHours(0, 0, 0, 0); s.setDate(s.getDate() - s.getDay()); for (let t = +s; t <= +r.end && out.length < 30; t += 7 * 86400000) { const d = new Date(t); push(d.getDate() + '/' + (d.getMonth() + 1), t, t + 7 * 86400000); } }
  else { let d = new Date(r.start.getFullYear(), r.start.getMonth(), 1); while (d <= r.end && out.length < 24) { const f = new Date(d.getFullYear(), d.getMonth() + 1, 1); push(mn[d.getMonth()] + '/' + String(d.getFullYear()).slice(2), d, f); d = f; } }
  rows.forEach(x => { const t = +new Date(x.data); const b = out.find(o => t >= o.ini && t < o.fim); if (b) { b.qtd += x.qtd; b.fat += x.valorItem; b.liq += x.lucroLiq; } });
  return out;
};

/* ---------- gráficos SVG (tema claro/escuro) ---------- */
Modules.apLine = function (labels, series) {
  if (labels.length < 2) return '';
  const w = 640, h = 200, pl = 48, pr = 14, pt = 14, pb = 28, iw = w - pl - pr, ih = h - pt - pb;
  const all = series.flatMap(s => s.values); let max = Math.max(1, ...all), min = Math.min(0, ...all); if (max === min) max = min + 1;
  const kf = v => { const a = Math.abs(v); return a >= 1000 ? (v / 1000).toFixed(1).replace('.', ',') + 'k' : Math.round(v); };
  const X = i => pl + i / (labels.length - 1) * iw, Y = v => pt + ih - (v - min) / (max - min) * ih;
  const grid = [0, .5, 1].map(f => { const gy = pt + ih - f * ih, gv = min + f * (max - min); return `<line x1="${pl}" y1="${gy.toFixed(1)}" x2="${w - pr}" y2="${gy.toFixed(1)}" stroke="var(--border)"/><text x="6" y="${(gy + 3).toFixed(1)}" font-size="10" fill="var(--txt-3)">${kf(gv)}</text>`; }).join('');
  const lines = series.map(s => { const pts = s.values.map((v, i) => X(i).toFixed(1) + ',' + Y(v).toFixed(1)).join(' '); return `<polyline points="${pts}" fill="none" stroke="${s.color}" stroke-width="2.2"/>` + s.values.map((v, i) => `<circle cx="${X(i).toFixed(1)}" cy="${Y(v).toFixed(1)}" r="2.6" fill="${s.color}"/>`).join(''); }).join('');
  const step = Math.ceil(labels.length / 12);
  const xl = labels.map((l, i) => i % step === 0 ? `<text x="${X(i).toFixed(1)}" y="${h - 8}" font-size="9.5" fill="var(--txt-3)" text-anchor="middle">${esc(l)}</text>` : '').join('');
  const leg = series.map(s => `<span class="ap-leg"><span style="background:${s.color}"></span>${esc(s.name)}</span>`).join('');
  return `<div class="ap-chart"><svg viewBox="0 0 ${w} ${h}" width="100%" xmlns="http://www.w3.org/2000/svg">${grid}${lines}${xl}</svg><div class="ap-legs">${leg}</div></div>`;
};
Modules.apBars = function (labels, values, color) {
  if (!labels.length) return '';
  const w = 640, h = 170, pl = 34, pr = 12, pt = 12, pb = 26, iw = w - pl - pr, ih = h - pt - pb, max = Math.max(1, ...values);
  const bw = iw / labels.length * 0.62, gap = iw / labels.length;
  const bars = values.map((v, i) => { const x = pl + i * gap + (gap - bw) / 2, bh = v / max * ih, y = pt + ih - bh; return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${bw.toFixed(1)}" height="${Math.max(0, bh).toFixed(1)}" rx="2" fill="${color || '#5b8cff'}"/>`; }).join('');
  const base = `<line x1="${pl}" y1="${pt + ih}" x2="${w - pr}" y2="${pt + ih}" stroke="var(--border)"/>`;
  const step = Math.ceil(labels.length / 12);
  const xl = labels.map((l, i) => i % step === 0 ? `<text x="${(pl + i * gap + gap / 2).toFixed(1)}" y="${h - 8}" font-size="9.5" fill="var(--txt-3)" text-anchor="middle">${esc(l)}</text>` : '').join('');
  return `<div class="ap-chart"><svg viewBox="0 0 ${w} ${h}" width="100%" xmlns="http://www.w3.org/2000/svg">${base}${bars}${xl}</svg></div>`;
};

/* ---------- render ---------- */
Modules.biAnaliseProd = function () {
  const S = this.apState;
  const prod = S.sku ? BI.prodInfo(S.sku) : null;
  const periodSel = `<select id="ap-periodo" onchange="Modules.apSetPeriodo(this.value)">${this.apPeriodos.map(o => `<option value="${o[0]}" ${S.periodo === o[0] ? 'selected' : ''}>${o[1]}</option>`).join('')}</select>`;
  const custom = S.periodo === 'custom' ? `<span style="display:inline-flex;gap:6px;align-items:center"><input type="date" id="ap-de" value="${S.de}" onchange="Modules.apState.de=this.value;Modules.biRender()"><span class="muted">até</span><input type="date" id="ap-ate" value="${S.ate}" onchange="Modules.apState.ate=this.value;Modules.biRender()"></span>` : '';
  const filtros = `<div class="card"><div class="section-title">1. Produto e período</div>
    <div class="ap-filtros">
      <div class="ap-search"><input id="ap-busca" placeholder="🔎 Pesquisar produto por nome, SKU..." value="${prod ? esc(prod.nome) : ''}" oninput="Modules.apBusca()" onfocus="Modules.apBusca()" autocomplete="off"><div id="ap-drop" class="ap-drop"></div></div>
      ${periodSel} ${custom}
    </div></div>`;

  if (!prod) return filtros + '<div class="empty-state"><div class="big">🔎</div>Pesquise e selecione um produto para ver o relatório completo de desempenho.</div>';

  const r = BI.range(S.periodo, S.de, S.ate), pr = BI.prevRange(r, S.periodo);
  const D = this.apCompute(S.sku, r), Dp = this.apCompute(S.sku, pr);
  const T = D.T, Tp = Dp.T, st = D.stats, canFin = App.canFinance();
  const label = BI.periodoLabel(S.periodo, r);
  const sem = m => (typeof Modules !== 'undefined' && Modules.simSem) ? Modules.simSem(m) : { c: 'var(--txt)', e: '' };

  if (!T.qtd) return filtros + `<div class="empty-state"><div class="big">📭</div>Nenhuma venda de <b>${esc(prod.nome)}</b> ${esc(label)}.<br><span class="muted">Tente outro período.</span></div>`;

  /* Bloco 2: KPIs */
  const kpi = (l, v, c, tip) => `<div class="ap-kpi"${tip ? ` title="${esc(tip)}"` : ''}><span>${l}</span><b${c ? ` style="color:${c}"` : ''}>${v}</b></div>`;
  const kpis = `<div class="ap-kpis">
    ${kpi('Qtd vendida', T.qtd + ' un')}
    ${kpi('Faturamento bruto', Fmt.brl(T.receita), '', 'Soma de preço × quantidade de cada venda')}
    ${canFin ? kpi('Lucro bruto', Fmt.brl(T.bruto), '', 'Faturamento − Custo = ' + Fmt.brl(T.receita) + ' − ' + Fmt.brl(T.custo)) : ''}
    ${canFin ? kpi('Lucro líquido', Fmt.brl(T.liq), T.liq >= 0 ? 'var(--green)' : 'var(--red)', 'Lucro bruto − Taxas = ' + Fmt.brl(T.bruto) + ' − ' + Fmt.brl(T.taxa)) : ''}
    ${canFin ? kpi('Margem s/ venda', Fmt.pct(T.margemV), sem(T.margemV).c, 'Lucro líquido ÷ Faturamento × 100') : ''}
    ${canFin ? kpi('Margem s/ custo', Fmt.pct(T.margemC), '', 'Lucro líquido ÷ Custo × 100') : ''}
    ${kpi('Ticket médio', Fmt.brl(T.ticket), '', 'Faturamento ÷ nº de vendas')}
    ${kpi('Preço médio', Fmt.brl(T.precoMedio), '', 'Faturamento ÷ quantidade')}
    ${canFin ? kpi('Custo médio', Fmt.brl(T.custoMedio)) : ''}
    ${canFin ? kpi('Investido nas vendas', Fmt.brl(T.investido), '', 'Custo total das unidades vendidas') : ''}
  </div>
  ${canFin ? `<details class="ap-form"><summary>🧮 Como os valores foram calculados</summary>
    <div class="ap-form-b">
      <div>Lucro bruto = Faturamento − Custo = ${Fmt.brl(T.receita)} − ${Fmt.brl(T.custo)} = <b>${Fmt.brl(T.bruto)}</b></div>
      <div>Lucro líquido = Lucro bruto − Taxas = ${Fmt.brl(T.bruto)} − ${Fmt.brl(T.taxa)} = <b>${Fmt.brl(T.liq)}</b></div>
      <div>Margem sobre venda = Lucro líquido ÷ Faturamento × 100 = ${Fmt.brl(T.liq)} ÷ ${Fmt.brl(T.receita)} = <b>${Fmt.pct(T.margemV)}</b></div>
      <div>Margem sobre custo = Lucro líquido ÷ Custo × 100 = ${Fmt.brl(T.liq)} ÷ ${Fmt.brl(T.custo)} = <b>${Fmt.pct(T.margemC)}</b></div>
    </div></details>` : ''}`;

  /* Bloco 2b: comparativo */
  const cmp = (cur, prev, money, pts) => {
    if (pts) { const d = cur - prev; return `<span class="${d >= 0 ? 'up' : 'down'}">${d >= 0 ? '+' : ''}${d.toFixed(1)} p.p.</span>`; }
    const d = prev ? (cur - prev) / prev * 100 : (cur ? 100 : 0); return `<span class="${d >= 0 ? 'up' : 'down'}">${d >= 0 ? '▲ +' : '▼ '}${Fmt.pct(Math.abs(d))}</span>`;
  };
  const comparativo = `<div class="card"><div class="section-title">Comparado ao período anterior <span class="muted" style="font-weight:500">· ${esc(BI.periodoLabel('custom', pr))}</span></div>
    <div class="ap-cmp">
      <div><span>Qtd vendida</span><b>${T.qtd}</b>${cmp(T.qtd, Tp.qtd)}</div>
      <div><span>Faturamento</span><b>${Fmt.brl(T.receita)}</b>${cmp(T.receita, Tp.receita)}</div>
      ${canFin ? `<div><span>Lucro líquido</span><b>${Fmt.brl(T.liq)}</b>${cmp(T.liq, Tp.liq)}</div>` : ''}
      ${canFin ? `<div><span>Margem</span><b>${Fmt.pct(T.margemV)}</b>${cmp(T.margemV, Tp.margemV, false, true)}</div>` : ''}
    </div></div>`;

  /* Bloco 3: gráficos */
  const bk = this.apBuckets(D.rows, r);
  const grafFat = this.apLine(bk.map(x => x.label), [{ name: 'Faturamento', color: '#5b8cff', values: bk.map(x => x.fat) }].concat(canFin ? [{ name: 'Lucro líquido', color: '#22c55e', values: bk.map(x => x.liq) }] : []));
  const grafQtd = this.apBars(bk.map(x => x.label), bk.map(x => x.qtd), '#a855f7');
  const graficos = bk.length >= 2 ? `<div class="card"><div class="section-title">3. Evolução no período</div>
    ${grafFat ? `<div class="ap-graf-t">${canFin ? 'Faturamento e lucro líquido' : 'Faturamento'}</div>${grafFat}` : ''}
    <div class="ap-graf-t" style="margin-top:14px">Quantidade vendida</div>${grafQtd}</div>` : '';

  /* Bloco 3b: estatísticas */
  const estat = `<div class="card"><div class="section-title">Estatísticas</div>
    <div class="ap-stats">
      ${kpi('Maior preço vendido', Fmt.brl(st.maxPreco))}
      ${kpi('Menor preço vendido', Fmt.brl(st.minPreco))}
      ${kpi('Preço médio', Fmt.brl(st.precoMedio))}
      ${kpi('Qtd média por dia', st.qtdDia.toFixed(2))}
      ${canFin ? kpi('Lucro médio / unidade', Fmt.brl(st.lucroUn)) : ''}
      ${kpi('Dias sem venda', st.diasSemVenda + ' de ' + st.diasPeriodo)}
    </div></div>`;

  /* Bloco 4: histórico */
  const hist = `<div class="card"><div class="section-title">4. Histórico de vendas <span class="muted" style="font-weight:500">· ${D.rows.length} venda(s)</span></div>
    <div class="table-wrap"><table><thead><tr><th>Data</th><th>Venda</th><th class="num">Qtd</th><th class="num">Preço un.</th><th class="num">Total</th><th>Pagamento</th>${canFin ? '<th class="num">Taxa</th><th class="num">L. bruto</th><th class="num">L. líquido</th><th class="num">Margem</th>' : ''}</tr></thead>
    <tbody>${D.rows.map(x => `<tr style="cursor:pointer" onclick="Modules.vdDetail('${x.vendaId}')">
      <td>${Fmt.date(x.data)}</td><td class="strong">${esc(x.numero)}</td><td class="num">${x.qtd}</td><td class="num">${Fmt.brl(x.precoUnit)}</td><td class="num strong">${Fmt.brl(x.valorItem)}</td><td>${esc(x.forma)}</td>
      ${canFin ? `<td class="num" style="color:var(--red)">${x.taxaItem > 0 ? '− ' + Fmt.brl(x.taxaItem) : '—'}</td><td class="num">${Fmt.brl(x.lucroBruto)}</td><td class="num" style="color:${x.lucroLiq >= 0 ? 'var(--green)' : 'var(--red)'};font-weight:700">${Fmt.brl(x.lucroLiq)}</td><td class="num">${Fmt.pct(x.margem)}</td>` : ''}</tr>`).join('')}</tbody></table></div>
    <div class="muted" style="font-size:12px;margin-top:6px">Clique em uma venda para abrir o detalhamento completo da operação.</div></div>`;

  /* Bloco 4b: análise inteligente */
  const ins = this.apInsights(prod, T, Tp, st, r, pr);
  const inteligente = `<div class="card"><div class="section-title">🧠 Análise inteligente</div>${ins.map(i => `<div class="ap-ins ${i.t}">${i.e} ${i.txt}</div>`).join('')}</div>`;

  const exp = canFin ? `<div style="margin:0 0 4px"><button class="btn-ghost btn-sm" onclick="Modules.apExport('xlsx')">⬇️ Excel</button> <button class="btn-ghost btn-sm" onclick="Modules.apExport('pdf')">🖨️ PDF</button></div>` : '';

  return filtros
    + `<div class="ap-head"><div><h2 style="margin:0">${esc(prod.nome)}</h2><div class="muted" style="font-size:12.5px">${esc(prod.categoria || '')}${prod.condicao ? ' · ' + esc(prod.condicao) : ''} · ${esc(prod.sku)} · estoque atual ${prod.qtd || 0} un</div></div><div class="ap-head-per">📅 ${esc(label)}</div></div>`
    + '<div class="section-title" style="margin:14px 0 8px">2. Indicadores</div>' + kpis + comparativo + graficos + estat + hist + inteligente + exp;
};

/* ---------- análise inteligente ---------- */
Modules.apInsights = function (prod, T, Tp, st, r, pr) {
  const out = [];
  const dQtd = Tp.qtd ? (T.qtd - Tp.qtd) / Tp.qtd * 100 : (T.qtd ? 100 : 0);
  const dLiq = Tp.liq ? (T.liq - Tp.liq) / Tp.liq * 100 : 0;
  const dMarg = T.margemV - Tp.margemV;
  const dPreco = Tp.precoMedio ? (T.precoMedio - Tp.precoMedio) / Tp.precoMedio * 100 : 0;
  if (Tp.qtd || Tp.receita) {
    if (Math.abs(dLiq) >= 3) out.push({ t: dLiq >= 0 ? 'op' : 'risco', e: dLiq >= 0 ? '🟢' : '🔴', txt: `O lucro líquido ${dLiq >= 0 ? 'aumentou' : 'caiu'} ${Fmt.pct(Math.abs(dLiq))} em relação ao período anterior.` });
    if (dQtd > 3 && dMarg < -1) out.push({ t: 'risco', e: '🔴', txt: `Apesar do aumento nas vendas (+${Fmt.pct(dQtd)}), a margem caiu ${Math.abs(dMarg).toFixed(1)} pontos — provável aumento de taxas ou vendas parceladas.` });
    if (Math.abs(dPreco) >= 5) out.push({ t: 'analise', e: '🟡', txt: `O preço médio ${dPreco >= 0 ? 'subiu' : 'caiu'} ${Fmt.pct(Math.abs(dPreco))} durante o período analisado.` });
  }
  if (T.margemV >= 30 && st.qtdDia >= 0.5) out.push({ t: 'op', e: '🟢', txt: 'Este produto tem alta margem e boa demanda — forte candidato a manter em estoque e destacar.' });
  else if (T.margemV >= 30 && st.qtdDia < 0.2) out.push({ t: 'analise', e: '🟡', txt: 'Alta margem, mas giro baixo — pode render mais em combo ou com destaque na loja.' });
  else if (T.margemV < 15) out.push({ t: 'risco', e: '🔴', txt: `Margem baixa (${Fmt.pct(T.margemV)}) — reveja o preço ou negocie melhor o custo de compra.` });
  if (st.diasSemVenda > st.diasPeriodo * 0.7 && st.diasPeriodo >= 7) out.push({ t: 'analise', e: '🟡', txt: `Ficou ${st.diasSemVenda} de ${st.diasPeriodo} dias sem vender — demanda concentrada em poucos dias.` });
  if (!out.length) out.push({ t: 'analise', e: '🟡', txt: 'Desempenho estável no período, sem variações relevantes frente ao período anterior.' });
  return out;
};

/* ---------- busca / seleção ---------- */
Modules.apBusca = function () {
  const q = (fval('ap-busca') || '').toLowerCase(), drop = document.getElementById('ap-drop'); if (!drop) return;
  if (!q) { drop.classList.remove('show'); drop.innerHTML = ''; return; }
  const list = DB.all('produtos').filter(p => p.nome.toLowerCase().includes(q) || (p.sku || '').toLowerCase().includes(q) || (p.barcode || '').includes(q)).slice(0, 12);
  drop.innerHTML = list.length ? list.map(p => `<div class="ms-opt" onmousedown="event.preventDefault();Modules.apPick('${esc(p.sku)}')"><span>${esc(p.nome)}</span><span class="o-sku">${esc(p.sku)} · ${p.qtd || 0} un</span></div>`).join('') : '<div class="ms-empty">Nenhum produto encontrado.</div>';
  drop.classList.add('show');
};
Modules.apPick = function (sku) { this.apState.sku = sku; const d = document.getElementById('ap-drop'); if (d) { d.classList.remove('show'); d.innerHTML = ''; } this.biRender(); };
Modules.apSetPeriodo = function (v) { this.apState.periodo = v; this.biRender(); };

/* ---------- exportação ---------- */
Modules.apExport = function (fmt) {
  const S = this.apState, prod = BI.prodInfo(S.sku); if (!prod) return;
  const r = BI.range(S.periodo, S.de, S.ate), D = this.apCompute(S.sku, r), T = D.T, r2 = x => Math.round(x * 100) / 100;
  const label = BI.periodoLabel(S.periodo, r);
  if (fmt === 'xlsx') {
    const aoa = [['Rico Games — Análise de Produto'], ['Produto', prod.nome], ['SKU', prod.sku], ['Período', label], [],
      ['Qtd vendida', T.qtd], ['Faturamento', r2(T.receita)], ['Custo', r2(T.custo)], ['Taxas', r2(T.taxa)], ['Lucro bruto', r2(T.bruto)], ['Lucro líquido', r2(T.liq)], ['Margem s/ venda %', r2(T.margemV)], ['Margem s/ custo %', r2(T.margemC)], ['Ticket médio', r2(T.ticket)], ['Preço médio', r2(T.precoMedio)], [],
      ['Data', 'Venda', 'Qtd', 'Preço un', 'Total', 'Pagamento', 'Taxa', 'Lucro bruto', 'Lucro líquido', 'Margem %']];
    D.rows.forEach(x => aoa.push([Fmt.date(x.data), x.numero, x.qtd, r2(x.precoUnit), r2(x.valorItem), x.forma, r2(x.taxaItem), r2(x.lucroBruto), r2(x.lucroLiq), r2(x.margem)]));
    Exporter.xlsx('analise-' + prod.nome.replace(/[^\w]+/g, '-').slice(0, 24) + '.xlsx', 'Análise', aoa);
  } else {
    const kp = (l, v) => `<div class="k"><div class="l">${l}</div><div class="v">${v}</div></div>`;
    const kpis = `<div class="kpis">${kp('Qtd', T.qtd)}${kp('Faturamento', Fmt.brl(T.receita))}${kp('Lucro líquido', Fmt.brl(T.liq))}${kp('Margem', Fmt.pct(T.margemV))}</div>`;
    const tr = D.rows.map(x => `<tr><td>${Fmt.date(x.data)}</td><td>${esc(x.numero)}</td><td class="num">${x.qtd}</td><td class="num">${Fmt.brl(x.precoUnit)}</td><td class="num">${Fmt.brl(x.valorItem)}</td><td>${esc(x.forma)}</td><td class="num">${Fmt.brl(x.lucroLiq)}</td><td class="num">${Fmt.pct(x.margem)}</td></tr>`).join('');
    Exporter.pdf('Análise de Produto — ' + prod.nome + ' · ' + label, kpis + `<table><thead><tr><th>Data</th><th>Venda</th><th class="num">Qtd</th><th class="num">Preço un</th><th class="num">Total</th><th>Pagamento</th><th class="num">Lucro líq</th><th class="num">Margem</th></tr></thead><tbody>${tr}</tbody></table>`);
  }
};

/* ============ Análise de Produtos (comparação multi-produto) ============ */
Modules.mpState = { skus: [], periodo: '30d', de: '', ate: '', sort: 'liq', dir: -1 };
Modules.mpSetPeriodo = function (v) { this.mpState.periodo = v; this.biRender(); };
Modules.mpBusca = function () {
  const q = (fval('mp-busca') || '').toLowerCase(), drop = document.getElementById('mp-drop'); if (!drop) return;
  if (!q) { drop.classList.remove('show'); drop.innerHTML = ''; return; }
  const list = DB.all('produtos').filter(p => this.mpState.skus.indexOf(p.sku) < 0 && (p.nome.toLowerCase().includes(q) || (p.sku || '').toLowerCase().includes(q) || (p.barcode || '').includes(q))).slice(0, 12);
  drop.innerHTML = list.length ? list.map(p => `<div class="ms-opt" onmousedown="event.preventDefault();Modules.mpAdd('${esc(p.sku)}')"><span>${esc(p.nome)}</span><span class="o-sku">${esc(p.sku)} · ${p.qtd || 0} un</span></div>`).join('') : '<div class="ms-empty">Nenhum produto encontrado.</div>';
  drop.classList.add('show');
};
Modules.mpAdd = function (sku) { if (this.mpState.skus.indexOf(sku) < 0) this.mpState.skus.push(sku); const d = document.getElementById('mp-drop'); if (d) { d.classList.remove('show'); d.innerHTML = ''; } this.biRender(); };
Modules.mpDel = function (sku) { this.mpState.skus = this.mpState.skus.filter(s => s !== sku); this.biRender(); };
Modules.mpSort = function (k) { const S = this.mpState; if (S.sort === k) S.dir = -S.dir; else { S.sort = k; S.dir = -1; } this.biRender(); };
Modules.mpConsolidado = function (skuSet, r) {
  const vendas = DB.all('vendas').filter(v => !v.cancelada && (() => { const d = new Date(v.data); return d >= r.start && d <= r.end; })());
  let qtd = 0, receita = 0, custo = 0, taxa = 0; const sales = new Set();
  vendas.forEach(v => {
    const vtax = v.taxaTotal != null ? v.taxaTotal : 0, vtot = v.total || (v.itens || []).reduce((s, i) => s + i.preco * i.qtd, 0) || 1; let hit = false;
    (v.itens || []).forEach(i => { if (!skuSet.has(i.sku)) return; hit = true; const p = BI.prodInfo(i.sku) || {}; const cu = (i.custo > 0) ? i.custo : (p.custoMedio || p.custo || 0); qtd += i.qtd; receita += i.preco * i.qtd; custo += cu * i.qtd; taxa += vtax * (i.preco * i.qtd / vtot); });
    if (hit) sales.add(v.id);
  });
  const bruto = receita - custo, liq = bruto - taxa;
  return { qtd, receita, custo, taxa, bruto, liq, margemV: receita ? liq / receita * 100 : 0, margemC: custo ? liq / custo * 100 : 0, nv: sales.size, ticket: sales.size ? receita / sales.size : 0 };
};
Modules.biMultiProd = function () {
  const S = this.mpState, canFin = App.canFinance();
  const periodSel = `<select id="mp-periodo" onchange="Modules.mpSetPeriodo(this.value)">${this.apPeriodos.map(o => `<option value="${o[0]}" ${S.periodo === o[0] ? 'selected' : ''}>${o[1]}</option>`).join('')}</select>`;
  const custom = S.periodo === 'custom' ? `<span style="display:inline-flex;gap:6px;align-items:center"><input type="date" id="mp-de" value="${S.de}" onchange="Modules.mpState.de=this.value;Modules.biRender()"><span class="muted">até</span><input type="date" id="mp-ate" value="${S.ate}" onchange="Modules.mpState.ate=this.value;Modules.biRender()"></span>` : '';
  const chips = S.skus.map(sku => { const p = BI.prodInfo(sku) || { nome: sku }; return `<span class="seg-chip">${esc(p.nome)} <span onclick="Modules.mpDel('${esc(sku)}')" style="color:var(--red);cursor:pointer">✕</span></span>`; }).join('');
  const filtros = `<div class="card"><div class="section-title">Selecionar produtos <span class="muted" style="font-weight:500">· ${S.skus.length} selecionado(s)</span></div>
    <div class="ap-filtros">
      <div class="ap-search"><input id="mp-busca" placeholder="🔎 Buscar produto para adicionar..." oninput="Modules.mpBusca()" onfocus="Modules.mpBusca()" autocomplete="off"><div id="mp-drop" class="ap-drop"></div></div>
      ${periodSel} ${custom}
    </div>
    ${chips ? `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:12px">${chips}</div>` : '<p class="muted" style="font-size:12.5px;margin-top:10px">Adicione produtos para comparar (4 ou mais).</p>'}
  </div>`;
  if (!S.skus.length) return filtros + '<div class="empty-state"><div class="big">⚖️</div>Selecione produtos acima para ver a análise consolidada e individual.</div>';

  const r = BI.range(S.periodo, S.de, S.ate), label = BI.periodoLabel(S.periodo, r);
  const rows = S.skus.map(sku => { const p = BI.prodInfo(sku) || { nome: sku, sku }; const T = this.apCompute(sku, r).T; return { sku, nome: p.nome, T }; });
  const C = this.mpConsolidado(new Set(S.skus), r);
  const sem = m => (Modules.simSem ? Modules.simSem(m) : { c: 'var(--txt)' });

  // ordenação
  const key = S.sort, getV = x => key === 'nome' ? x.nome : (x.T[key] != null ? x.T[key] : 0);
  const sorted = rows.slice().sort((a, b) => key === 'nome' ? a.nome.localeCompare(b.nome) * (S.dir) : (getV(b) - getV(a)) * (S.dir < 0 ? 1 : -1));
  const arrow = k => S.sort === k ? (S.dir < 0 ? ' ▼' : ' ▲') : '';
  const th = (k, lbl, cls) => `<th class="${cls || ''}" style="cursor:pointer" onclick="Modules.mpSort('${k}')">${lbl}${arrow(k)}</th>`;

  // KPIs consolidados
  const kpi = (l, v, c) => `<div class="ap-kpi"><span>${l}</span><b${c ? ` style="color:${c}"` : ''}>${v}</b></div>`;
  const resumo = `<div class="section-title" style="margin:14px 0 8px">Resumo consolidado <span class="muted" style="font-weight:500">· ${esc(label)}</span></div>
    <div class="ap-kpis">
      ${kpi('Qtd vendida', C.qtd + ' un')}
      ${kpi('Faturamento', Fmt.brl(C.receita))}
      ${canFin ? kpi('Custo total', Fmt.brl(C.custo)) : ''}
      ${canFin ? kpi('Lucro bruto', Fmt.brl(C.bruto)) : ''}
      ${canFin ? kpi('Taxas', Fmt.brl(C.taxa), 'var(--red)') : ''}
      ${canFin ? kpi('Lucro líquido', Fmt.brl(C.liq), C.liq >= 0 ? 'var(--green)' : 'var(--red)') : ''}
      ${canFin ? kpi('Margem líquida', Fmt.pct(C.margemV), sem(C.margemV).c) : ''}
      ${canFin ? kpi('Margem s/ custo', Fmt.pct(C.margemC)) : ''}
      ${kpi('Ticket médio', Fmt.brl(C.ticket))}
    </div>`;

  // tabela por produto
  const tabela = `<div class="card"><div class="section-title">Detalhamento por produto</div>
    <div class="table-wrap"><table><thead><tr>${th('nome', 'Produto')}${th('qtd', 'Qtd', 'num')}${canFin ? th('custo', 'Custo', 'num') : ''}${th('receita', 'Faturamento', 'num')}${canFin ? th('liq', 'Lucro líquido', 'num') : ''}${canFin ? th('margemV', 'Margem', 'num') : ''}</tr></thead>
    <tbody>${sorted.map(x => `<tr${x.T.qtd === 0 ? ' style="opacity:.6"' : ''}>
      <td class="strong">${esc(x.nome)}${x.T.qtd === 0 ? ' <span class="badge b-gray">0 vendas</span>' : ''}</td>
      <td class="num">${x.T.qtd}</td>
      ${canFin ? `<td class="num muted">${Fmt.brl(x.T.custo)}</td>` : ''}
      <td class="num strong">${Fmt.brl(x.T.receita)}</td>
      ${canFin ? `<td class="num" style="color:${x.T.liq >= 0 ? 'var(--green)' : 'var(--red)'}">${Fmt.brl(x.T.liq)}</td>` : ''}
      ${canFin ? `<td class="num">${x.T.qtd ? Fmt.pct(x.T.margemV) : '—'}</td>` : ''}</tr>`).join('')}</tbody>
    <tfoot><tr style="font-weight:700;border-top:2px solid var(--line)"><td>Total</td><td class="num">${C.qtd}</td>${canFin ? `<td class="num">${Fmt.brl(C.custo)}</td>` : ''}<td class="num">${Fmt.brl(C.receita)}</td>${canFin ? `<td class="num">${Fmt.brl(C.liq)}</td>` : ''}${canFin ? `<td class="num">${Fmt.pct(C.margemV)}</td>` : ''}</tr></tfoot></table></div></div>`;

  // gráficos (ordenados por valor desc para leitura)
  const byVal = (mapFn) => rows.slice().map(x => ({ label: x.nome, value: mapFn(x) })).sort((a, b) => b.value - a.value);
  const graf = `<div class="card"><div class="section-title">Comparação visual</div>
    <div class="ap-graf-t">Faturamento por produto</div>${this.apBars(byVal(x => x.T.receita).map(x => x.label), byVal(x => x.T.receita).map(x => x.value), '#5b8cff')}
    ${canFin ? `<div class="ap-graf-t" style="margin-top:14px">Lucro líquido por produto</div>${this.apBars(byVal(x => x.T.liq).map(x => x.label), byVal(x => x.T.liq).map(x => x.value), '#22c55e')}` : ''}
    <div class="ap-graf-t" style="margin-top:14px">Quantidade vendida</div>${this.apBars(byVal(x => x.T.qtd).map(x => x.label), byVal(x => x.T.qtd).map(x => x.value), '#a855f7')}</div>`;

  // melhor desempenho
  const withSales = rows.filter(x => x.T.qtd > 0);
  let best = '';
  if (withSales.length) {
    const top = (fn) => withSales.slice().sort((a, b) => fn(b) - fn(a))[0];
    const bFat = top(x => x.T.receita), bLiq = top(x => x.T.liq), bMar = top(x => x.T.margemV), bQtd = top(x => x.T.qtd);
    const bc = (ico, lbl, nome, val) => `<div class="mp-best"><div class="mp-best-h">${ico} ${lbl}</div><div class="mp-best-p">${esc(nome)}</div><div class="mp-best-v">${val}</div></div>`;
    best = `<div class="section-title" style="margin:14px 0 8px">🏆 Melhor desempenho</div><div class="mp-bests">
      ${bc('💵', 'Maior faturamento', bFat.nome, Fmt.brl(bFat.T.receita))}
      ${canFin ? bc('💎', 'Maior lucro líquido', bLiq.nome, Fmt.brl(bLiq.T.liq)) : ''}
      ${canFin ? bc('📐', 'Maior margem', bMar.nome, Fmt.pct(bMar.T.margemV)) : ''}
      ${bc('📦', 'Maior quantidade', bQtd.nome, bQtd.T.qtd + ' un')}
    </div>`;
  }

  // análise inteligente
  const ins = this.mpInsights(rows, C, canFin);
  const analise = `<div class="card"><div class="section-title">🧠 Análise</div>${ins.map(t => `<div class="ap-ins ${t.t}">${t.e} ${t.txt}</div>`).join('')}</div>`;

  return filtros + resumo + best + graf + tabela + analise;
};
Modules.mpInsights = function (rows, C, canFin) {
  const out = [], withSales = rows.filter(x => x.T.qtd > 0), zero = rows.filter(x => x.T.qtd === 0);
  if (!withSales.length) { out.push({ t: 'analise', e: '🟡', txt: 'Nenhum dos produtos selecionados teve vendas no período.' }); return out; }
  const top = (fn) => withSales.slice().sort((a, b) => fn(b) - fn(a))[0];
  const bLiq = top(x => x.T.liq), bMar = top(x => x.T.margemV), bFat = top(x => x.T.receita), bQtd = top(x => x.T.qtd);
  if (canFin && bLiq && bMar) out.push({ t: 'op', e: '🟢', txt: `Entre os selecionados, <b>${esc(bLiq.nome)}</b> teve o maior lucro líquido (${Fmt.brl(bLiq.T.liq)})${bMar.sku !== bLiq.sku ? `, enquanto <b>${esc(bMar.nome)}</b> teve a maior margem (${Fmt.pct(bMar.T.margemV)})` : ''}.` });
  if (canFin && bFat && bMar && bFat.sku !== bMar.sku && bFat.T.margemV < bMar.T.margemV) out.push({ t: 'analise', e: '🟡', txt: `Apesar de <b>${esc(bFat.nome)}</b> ter o maior faturamento (${Fmt.brl(bFat.T.receita)}), sua margem (${Fmt.pct(bFat.T.margemV)}) é inferior à de <b>${esc(bMar.nome)}</b> (${Fmt.pct(bMar.T.margemV)}).` });
  if (!canFin) out.push({ t: 'op', e: '🟢', txt: `<b>${esc(bQtd.nome)}</b> foi o que mais vendeu (${bQtd.T.qtd} un) e <b>${esc(bFat.nome)}</b> o que mais faturou (${Fmt.brl(bFat.T.receita)}).` });
  if (zero.length) out.push({ t: 'risco', e: '🔴', txt: `${zero.length === 1 ? 'O produto' : 'Os produtos'} ${zero.map(x => '"' + esc(x.nome) + '"').join(', ')} ${zero.length === 1 ? 'não teve' : 'não tiveram'} nenhuma venda no período.` });
  return out;
};
