/* ============ RICO GAMES ERP — Tema (Dark / Light) ============ */
const Theme = {
  KEY: 'rg_theme',
  current() { return document.documentElement.getAttribute('data-theme') || 'dark'; },
  systemPref() { return (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) ? 'light' : 'dark'; },
  apply(t) {
    document.documentElement.setAttribute('data-theme', t);
    const ico = document.getElementById('tt-ico'), lbl = document.getElementById('tt-label');
    if (ico) ico.textContent = t === 'light' ? '☀️' : '🌙';
    if (lbl) lbl.textContent = t === 'light' ? 'Claro' : 'Escuro';
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', t === 'light' ? '#ffffff' : '#16181d');
  },
  init() {
    // 1ª utilização: segue o sistema operacional; depois respeita a escolha salva
    const saved = localStorage.getItem(this.KEY);
    this.apply(saved || this.systemPref());
    if (window.matchMedia) {
      window.matchMedia('(prefers-color-scheme: light)').addEventListener('change', e => {
        if (!localStorage.getItem(this.KEY)) this.apply(e.matches ? 'light' : 'dark');
      });
    }
  },
  toggle() {
    const t = this.current() === 'dark' ? 'light' : 'dark';
    localStorage.setItem(this.KEY, t);
    this.apply(t);
    Toast.ok('Tema ' + (t === 'light' ? 'claro' : 'escuro') + ' ativado.');
  }
};

/* ============ RICO GAMES ERP — Permissões ============ */
const PERM_DEFAULT_FUNC = {
  modules: { dashboard: false, vendasDia: true, pdv: true, caixa: true, estoque: true, entrada: false, compras: false, usados: false, trocas: false, prevendas: true, movimentacoes: false, garantias: false, financeiro: false, planejamento: false, relatorios: false, config: false },
  verFinanceiro: false, podeCancelar: false, podeDesconto: true, podeEditarProduto: true, podeExcluirProduto: false, podeSangria: true, podeAlterarPreco: false
};

/* ============ RICO GAMES ERP — App / Router ============ */
const App = {
  titles: {
    dashboard: 'Dashboard', vendasDia: 'Vendas do Dia', pdv: 'PDV — Ponto de Venda', caixa: 'Caixa da Loja', estoque: 'Estoque', entrada: 'Entrada de Estoque',
    compras: 'Compras', usados: 'Receber Usado',
    trocas: 'Trocas e Usados', prevendas: 'Pré-venda / Reservas', movimentacoes: 'Movimentações', garantias: 'Garantias',
    financeiro: 'Financeiro', planejamento: 'Planejamento de Compras', relatorios: 'Relatórios', config: 'Configurações'
  },
  current: 'dashboard',

  init() {
    // Mostra na tela qualquer erro silencioso de um handler (ex: um botão que "não faz nada"),
    // em vez de falhar em silêncio — ajuda a diagnosticar rapidamente.
    if (!window.__rgErrHook) {
      window.__rgErrHook = true;
      window.addEventListener('error', function (e) {
        try { if (typeof Toast !== 'undefined' && e && e.message) Toast.err('Erro: ' + e.message); } catch (_) {}
      });
      window.addEventListener('unhandledrejection', function (e) {
        try { const r = e && e.reason; const msg = (r && r.message) || r; if (typeof Toast !== 'undefined' && msg) Toast.err('Erro: ' + msg); } catch (_) {}
      });
    }
    DB.load();
    this.migratePerms();
    try { if (typeof PV !== 'undefined' && PV.migrarLegado) PV.migrarLegado(); } catch (e) { console.error('Falha ao migrar pré-vendas antigas', e); }
    Theme.init();
    this.renderAuth();
    if (typeof Cloud !== 'undefined' && Cloud.configured()) {
      Cloud.initialSync().then(() => { this.renderAuth(); if (this.current) this.refresh(); });
      Cloud.start();
    }
    // login persistence (sessão)
    if (sessionStorage.getItem('rg_logged') === '1') this.showApp();
    // nav binding
    document.querySelectorAll('.nav-item[data-route]').forEach(a => {
      a.addEventListener('click', () => App.go(a.dataset.route));
    });
  },

  renderAuth() {
    const form = document.getElementById('login-form'); if (!form) return;
    const sub = document.querySelector('.login-sub');
    const cloudLink = `<div style="text-align:center;margin-top:12px"><a style="font-size:12.5px;color:var(--green);cursor:pointer" onclick="App.loginCloud()">☁️ Conectar à nuvem (configurar este aparelho)</a></div>`;
    if (DB.all('usuarios').length === 0) {
      if (sub) sub.textContent = 'Primeiro acesso — crie a conta do administrador';
      form.innerHTML = `
        <label>Seu nome</label><input id="su-nome" autocomplete="off" />
        <label>Usuário (login)</label><input id="su-user" autocomplete="off" />
        <label>Senha</label><input id="su-pass" type="password" />
        <label>Confirmar senha</label><input id="su-pass2" type="password" onkeydown="if(event.key==='Enter')App.createOwner()" />
        <button class="btn-primary btn-block" onclick="App.createOwner()">Criar administrador</button>
        <div class="login-hint">Esta será a conta do dono (acesso total ao sistema).</div>
        ${cloudLink}`;
    } else {
      if (sub) sub.textContent = 'Sistema de Gestão · ERP & PDV';
      form.innerHTML = `
        <label>Usuário</label><input id="login-user" type="text" autocomplete="off" />
        <label>Senha</label><input id="login-pass" type="password" onkeydown="if(event.key==='Enter')App.login()" />
        <button class="btn-primary btn-block" onclick="App.login()">Entrar</button>
        <div class="login-hint">Entre com seu usuário e senha.</div>
        ${cloudLink}`;
    }
  },
  loginCloud() {
    const c = (typeof Cloud !== 'undefined' && Cloud.cfg()) || {};
    Modal.open({
      title: '☁️ Conectar à nuvem',
      body: `<p style="color:var(--txt-2);margin-bottom:14px;line-height:1.6">Cole a URL e a chave do Supabase para este aparelho baixar os dados da loja (usuários, produtos, vendas...). Depois é só entrar com seu usuário e senha.</p>
        <div class="field" style="margin-bottom:12px"><label>URL do projeto Supabase</label><input id="lc-url" value="${esc(c.url || '')}" placeholder="https://xxxx.supabase.co"></div>
        <div class="field"><label>Chave pública (anon)</label><input id="lc-key" value="${esc(c.key || '')}" placeholder="eyJ..."></div>`,
      foot: `<button class="btn-ghost" onclick="Modal.close()">Cancelar</button><button class="btn-primary" onclick="App.loginCloudSave()">Conectar e baixar</button>`
    });
  },
  async loginCloudSave() {
    const url = fval('lc-url'), key = fval('lc-key');
    if (!url || !key) return Toast.err('Cole a URL e a chave do Supabase.');
    Cloud.setCfg(url, key); Toast.ok('Conectando…');
    const ok = await Cloud.test();
    if (!ok) { Toast.err('Não consegui conectar. Confira a URL, a chave e se a tabela "erp_state" existe.'); return; }
    await Cloud.initialSync(); Cloud.start();
    Modal.close(); this.renderAuth();
    Toast.ok('Conectado! Agora entre com seu usuário e senha.');
  },
  createOwner() {
    const nome = document.getElementById('su-nome').value.trim();
    const user = document.getElementById('su-user').value.trim();
    const p = document.getElementById('su-pass').value, p2 = document.getElementById('su-pass2').value;
    if (!nome || !user || !p) return Toast.err('Preencha nome, usuário e senha.');
    if (p !== p2) return Toast.err('As senhas não conferem.');
    const rec = DB.insert('usuarios', { nome, usuario: user, senha: p, role: 'admin', ativo: true });
    sessionStorage.setItem('rg_logged', '1');
    sessionStorage.setItem('rg_user', JSON.stringify({ id: rec.id, usuario: user, nome, role: 'admin' }));
    Toast.ok('Administrador criado. Bem-vindo!');
    this.showApp();
  },
  login() {
    const u = document.getElementById('login-user').value.trim();
    const p = document.getElementById('login-pass').value.trim();
    const found = DB.all('usuarios').find(x => x.usuario.toLowerCase() === u.toLowerCase() && x.senha === p && x.ativo !== false);
    if (found) {
      sessionStorage.setItem('rg_logged', '1');
      sessionStorage.setItem('rg_user', JSON.stringify({ id: found.id, usuario: found.usuario, nome: found.nome, role: found.role }));
      this.showApp();
    } else Toast.err('Usuário ou senha incorretos.');
  },
  /* ---- Permissões ---- */
  user() { try { return JSON.parse(sessionStorage.getItem('rg_user')); } catch (e) { return null; } },
  // registro completo do usuário logado (fonte das permissões individuais)
  userRec() { const u = this.user(); if (!u) return null; return DB.all('usuarios').find(x => (u.id && x.id === u.id) || (x.usuario || '').toLowerCase() === (u.usuario || '').toLowerCase()) || null; },
  isAdmin() { const u = this.user(); if (!u) return true; const rec = this.userRec(); return (rec ? rec.role : u.role) === 'admin'; },
  perms() {
    if (this.isAdmin()) return null;
    const rec = this.userRec();
    const pp = (rec && rec.permissoes) ? rec.permissoes : {};   // permissões DESTE usuário (individuais)
    return Object.assign({}, PERM_DEFAULT_FUNC, pp, { modules: Object.assign({}, PERM_DEFAULT_FUNC.modules, pp.modules || {}) });
  },
  // Migração segura: dá a cada funcionário seu próprio conjunto de permissões, preservando o que já tinham.
  migratePerms() {
    const cfg = DB.all('config')[0]; if (!cfg) return;
    if (cfg.permUserMigrated) return;
    const legacy = cfg.permFuncionario || null;   // conjunto antigo, compartilhado
    DB.all('usuarios').forEach(u => {
      if (u.role === 'admin') return;
      if (!u.permissoes) {
        const base = legacy ? JSON.parse(JSON.stringify(legacy)) : JSON.parse(JSON.stringify(PERM_DEFAULT_FUNC));
        base.modules = Object.assign({}, PERM_DEFAULT_FUNC.modules, base.modules || {});
        DB.update('usuarios', u.id, { permissoes: base });
      }
    });
    DB.update('config', cfg.id, { permUserMigrated: true });
  },
  canModule(route) { if (this.isAdmin()) return true; const p = this.perms(); return !!(p.modules && p.modules[route]); },
  canFinance() { if (this.isAdmin()) return true; return !!this.perms().verFinanceiro; },
  can(action) { if (this.isAdmin()) return true; return !!this.perms()[action]; },
  firstRoute() { return this.isAdmin() ? 'dashboard' : (['pdv', 'vendasDia', 'caixa', 'estoque', 'compras', 'usados', 'trocas', 'movimentacoes', 'garantias', 'financeiro', 'relatorios'].find(r => this.canModule(r)) || 'pdv'); },
  applyAccess() {
    document.querySelectorAll('.nav-item[data-route]').forEach(a => { a.style.display = this.canModule(a.dataset.route) ? '' : 'none'; });
    const u = this.user() || { nome: 'Administrador', role: 'admin' };
    const av = document.querySelector('.user-chip .avatar'); if (av) av.textContent = (u.nome || 'A').charAt(0).toUpperCase();
    const nm = document.querySelector('.user-chip .only-desktop'); if (nm) nm.textContent = u.nome + (u.role === 'admin' ? '' : ' · Funcionário');
    const nv = document.querySelector('.topbar-actions .btn-ghost'); if (nv) nv.style.display = this.canModule('pdv') ? '' : 'none';
  },
  logout() {
    Modal.confirm('Deseja sair do sistema?', () => {
      sessionStorage.removeItem('rg_logged');
      sessionStorage.removeItem('rg_user');
      document.getElementById('app').classList.add('hidden');
      document.getElementById('login-screen').classList.remove('hidden');
    }, 'Sair');
  },
  showApp() {
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
    this.applyAccess();
    this.go(this.firstRoute());
  },

  go(route) {
    if (!this.canModule(route)) { Toast.err('Você não tem permissão para acessar esta área.'); route = this.firstRoute(); }
    this.current = route;
    document.getElementById('page-title').textContent = this.titles[route] || route;
    document.querySelectorAll('.nav-item[data-route]').forEach(a => a.classList.toggle('active', a.dataset.route === route));
    const view = document.getElementById('view');
    try {
      view.innerHTML = Modules[route] ? Modules[route]() : '<div class="empty-state"><div class="big">🚧</div>Módulo em construção.</div>';
    } catch (e) {
      view.innerHTML = '<div class="empty-state"><div class="big">⚠️</div>Erro ao carregar o módulo.<br><small>' + esc(e.message) + '</small></div>';
      console.error(e);
    }
    // post-render hooks
    if (route === 'vendasDia') Modules.vdRender();
    if (route === 'caixa') Modules.cxRender();
    if (route === 'estoque') Modules.renderEstoqueTable();
    if (route === 'entrada') Modules.entRender();
    if (route === 'pdv') { Modules.pdvSearch(); Modules.renderCart(); }
    if (route === 'movimentacoes') Modules.renderMovs();
    if (route === 'financeiro') Modules.finInit();
    if (route === 'relatorios') Modules.biInit();
    if (route === 'prevendas') Modules.pvRender();
    view.scrollTop = 0; window.scrollTo(0, 0);
    this.toggleSidebar(false);
  },

  toggleSidebar(open) {
    const sb = document.getElementById('sidebar'), ov = document.getElementById('sidebar-overlay');
    if (window.innerWidth > 860) return;
    sb.classList.toggle('open', open); ov.classList.toggle('open', open);
  },

  toggleTheme() { Theme.toggle(); },
  refresh() { const app = document.getElementById('app'); if (app && !app.classList.contains('hidden') && this.current) this.go(this.current); },

  globalSearch() {
    const q = document.getElementById('global-search').value.trim();
    if (!q) return;
    this.go('estoque');
    setTimeout(() => { const e = document.getElementById('est-search'); if (e) { e.value = q; Modules.renderEstoqueTable(); } }, 60);
  }
};

document.addEventListener('DOMContentLoaded', () => App.init());
