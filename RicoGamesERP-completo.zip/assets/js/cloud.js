/* ============ RICO GAMES ERP — Sincronização na nuvem (Supabase) ============
   Mantém o sistema funcionando offline (localStorage) e, quando configurado,
   espelha todo o estado num banco na nuvem para acesso de qualquer lugar. */
/* Nuvem embutida: preencha url e key para conectar automaticamente em TODOS os aparelhos
   (sem precisar configurar cada um). A "key" é a chave anon (pública) do Supabase. */
const CLOUD_DEFAULT = {
  url: 'https://irzogxqfnfduaqqpbxwc.supabase.co',
  key: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlyem9neHFmbmZkdWFxcXBieHdjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE5NTc4MjYsImV4cCI6MjA5NzUzMzgyNn0.sEc3nWebaWqgjOWsREtAahUtEbcAKzdh37NVI_PwoCI'
};

const Cloud = {
  pushTimer: null, syncTimer: null, pushing: false, ready: false,

  /* "dirty" = há alterações locais confirmadas que ainda NÃO foram enviadas à nuvem.
     Enquanto dirty, NUNCA sobrescrevemos o local com a nuvem (evita perder vendas). */
  markDirty() { try { localStorage.setItem('rg_dirty', '1'); } catch (e) { } },
  isDirty() { return localStorage.getItem('rg_dirty') === '1'; },
  clearDirty() { try { localStorage.removeItem('rg_dirty'); } catch (e) { } },

  cfg() {
    try { const s = JSON.parse(localStorage.getItem('rg_cloud')); if (s && s.url && s.key) return s; } catch (e) { }
    if (CLOUD_DEFAULT.url && CLOUD_DEFAULT.key) return CLOUD_DEFAULT;
    return null;
  },
  configured() { const c = this.cfg(); return !!(c && c.url && c.key); },
  setCfg(url, key) { localStorage.setItem('rg_cloud', JSON.stringify({ url: String(url).replace(/\/+$/, ''), key: String(key).trim() })); },
  clear() { localStorage.removeItem('rg_cloud'); this.stop(); this.status('Offline · salvo localmente', null); },
  rev() { return parseInt(localStorage.getItem('rg_rev') || '0', 10); },
  setRev(n) { localStorage.setItem('rg_rev', String(n)); },
  headers() { const c = this.cfg(); return { apikey: c.key, Authorization: 'Bearer ' + c.key, 'Content-Type': 'application/json' }; },

  status(txt, ok) {
    const el = document.getElementById('sync-label'); if (el) el.textContent = txt;
    const dot = document.querySelector('.sync-pill .dot');
    if (dot) dot.style.background = ok === null ? 'var(--txt-3)' : (ok ? 'var(--green)' : 'var(--amber)');
    if (dot) dot.style.boxShadow = ok ? '0 0 8px var(--green)' : 'none';
  },
  /* Estado visual em 3 níveis: Sincronizado · Sincronizando · Offline */
  showState() {
    if (!this.configured()) return this.status('Offline · salvo no aparelho', null);
    if (this._offline) return this.status('Sem conexão com a nuvem' + (this.isDirty() ? ' · alterações na fila' : ''), false);
    if (this.pushing || this.isDirty()) return this.status('Sincronizando…', true);
    return this.status('Sincronizado' + (this.realtimeOn ? ' · tempo real' : ''), true);
  },
  /* Teste de conexão detalhado — retorna sucesso ou a mensagem de erro exata */
  async testDetailed() {
    if (!this.configured()) return { ok: false, msg: 'Nuvem não configurada.' };
    try { await this.pull(); this._offline = false; this.showState(); this.log('teste', true, 'conexão OK'); return { ok: true }; }
    catch (e) { this._offline = true; this.showState(); const m = String(e && e.message || e); this.log('teste', false, m); return { ok: false, msg: m }; }
  },
  /* Log interno de sincronização (diagnóstico) */
  log(op, ok, msg) {
    try {
      const arr = JSON.parse(localStorage.getItem('rg_synclog') || '[]');
      arr.unshift({ t: new Date().toISOString(), u: (typeof App !== 'undefined' && App.user && App.user()) ? App.user().nome : '—', op, ok: !!ok, msg: msg || '' });
      localStorage.setItem('rg_synclog', JSON.stringify(arr.slice(0, 120)));
    } catch (e) { }
  },
  syncLog() { try { return JSON.parse(localStorage.getItem('rg_synclog') || '[]'); } catch (e) { return []; } },

  async pull() {
    const c = this.cfg();
    const r = await fetch(c.url + '/rest/v1/erp_state?id=eq.main&select=data,rev', { headers: this.headers() });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const rows = await r.json();
    return rows[0] || null;
  },
  /* Consulta SÓ o número da versão (bytes) — evita baixar o banco inteiro à toa (economiza egress) */
  async pullRev() {
    const c = this.cfg();
    const r = await fetch(c.url + '/rest/v1/erp_state?id=eq.main&select=rev', { headers: this.headers() });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const rows = await r.json();
    return rows[0] ? (rows[0].rev || 0) : -1;
  },
  async push(state, rev) {
    const c = this.cfg();
    const r = await fetch(c.url + '/rest/v1/erp_state', {
      method: 'POST',
      headers: Object.assign({ Prefer: 'resolution=merge-duplicates' }, this.headers()),
      body: JSON.stringify({ id: 'main', data: state, rev: rev, updated_at: new Date().toISOString() })
    });
    if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + (await r.text()));
  },

  afterLocalSave() {
    if (!this.configured()) return;
    if (this.ready) this.markDirty(); // só marca alterações do usuário (não a semente inicial, antes do 1º sync)
    clearTimeout(this.pushTimer);
    this.pushTimer = setTimeout(() => this.doPush(), 800);
  },
  async doPush() {
    if (!this.configured() || this.pushing) return;
    this.pushing = true; this.status('Sincronizando…', true);
    try {
      const newRev = this.rev() + 1;
      await this.push(DB.state(), newRev);
      this.setRev(newRev); this.clearDirty(); this._offline = false; // só limpa "dirty" APÓS o envio ter sucesso
      this.log('push', true, 'rev ' + newRev);
      this.showState();
    }
    catch (e) { console.warn('push falhou (dados seguros no aparelho)', e); this._offline = true; this.log('push', false, String(e && e.message || e)); this.showState(); }
    this.pushing = false;
  },
  async checkRemote() {
    if (!this.configured() || this.pushing) return;
    if (this.isDirty()) { this.doPush(); return; } // há mudanças locais não enviadas → enviar primeiro
    try {
      const remoteRev = await this.pullRev();          // consulta minúscula — economiza transferência (egress)
      this._offline = false;
      if (remoteRev > this.rev()) {                     // só baixa os dados QUANDO REALMENTE mudou
        const row = await this.pull();
        if (row && row.data) {
          const remoteCount = DB.recordCount(row.data);
          const res = DB.mergeRemote(row.data, row.rev || 0);   // MESCLA (união, mais-novo-vence)
          this.setRev(Math.max(this.rev(), row.rev || 0));
          if (res.added > 0) { this.log('pull', true, res.added + ' registros recebidos'); if (typeof App !== 'undefined' && App.refresh) App.refresh(); }
          if (DB.recordCount() > remoteCount) { this.markDirty(); this.doPush(); }
        }
      }
      this.showState();
    } catch (e) { this._offline = true; this.log('pull', false, String(e && e.message || e)); this.showState(); }
  },
  async initialSync() {
    if (!this.configured()) { this.status('Offline · salvo localmente', null); this.ready = true; return; }
    this.status('Conectando…', true);
    try {
      const row = await this.pull();
      if (row && row.data) {
        // MESCLA os dois lados; só reenvia se este aparelho tiver algo que a nuvem não tem (evita transferência à toa)
        const remoteCount = DB.recordCount(row.data);
        DB.mergeRemote(row.data, row.rev || 0);
        this.setRev(Math.max(this.rev(), row.rev || 0));
        if (DB.recordCount() > remoteCount || this.isDirty()) {
          const r = this.rev() + 1; await this.push(DB.state(), r); this.setRev(r); this.clearDirty();
        }
        if (typeof App !== 'undefined' && App.refresh) App.refresh();
        this._offline = false; this.showState();
      } else {
        const r = this.rev() + 1; await this.push(DB.state(), r); this.setRev(r); this.clearDirty();
        this._offline = false; this.showState();
      }
    } catch (e) { this.status('Sem conexão · salvo no aparelho', false); }
    this.ready = true;
  },
  /* Envia imediatamente ao sair/ocultar a página, se houver algo pendente (best-effort). */
  flush() { if (this.configured() && this.isDirty()) this.doPush(); },
  /* Realtime do Supabase (instantâneo). Requer supabase-js carregado e Realtime habilitado na tabela erp_state. */
  startRealtime(tries) {
    if (this._rt || !this.configured()) return;
    if (typeof window === 'undefined' || !window.supabase || !window.supabase.createClient) {
      if ((tries || 0) < 20) return void setTimeout(() => Cloud.startRealtime((tries || 0) + 1), 700); // aguarda o SDK carregar
      return; // SDK indisponível → segue com polling
    }
    try {
      const c = this.cfg();
      this._sb = window.supabase.createClient(c.url, c.key);
      this._rt = this._sb.channel('erp_state_rt')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'erp_state' }, () => { Cloud.checkRemote(); })
        .subscribe((st) => { if (st === 'SUBSCRIBED') { Cloud.realtimeOn = true; Cloud.log('realtime', true, 'conectado'); Cloud.flush(); Cloud.showState(); } });
    } catch (e) { console.warn('realtime indisponível, usando polling', e); this.log('realtime', false, String(e && e.message || e)); }
  },
  start() {
    if (!this.configured()) return; this.stop();
    this.startRealtime();
    // MODO ECONÔMICO: verificação leve (só a versão, ~50 bytes). Realtime cuida do instantâneo (não gasta egress).
    // Sem realtime, sincroniza a cada 45s — mais que suficiente para a loja e longe do limite.
    this._pollMs = 45000;
    this.syncTimer = setInterval(() => this.checkRemote(), this._pollMs);
    // reenvio automático da fila quando a internet voltar
    if (!this._flushBound) {
      this._flushBound = true;
      try {
        window.addEventListener('online', () => { Cloud._offline = false; Cloud.checkRemote(); Cloud.flush(); });
        window.addEventListener('offline', () => { Cloud._offline = true; Cloud.showState(); });
        window.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') Cloud.flush(); else Cloud.checkRemote(); });
        window.addEventListener('beforeunload', () => Cloud.flush());
      } catch (e) { }
    }
  },
  stop() { clearInterval(this.syncTimer); this.syncTimer = null; },
  async test() { try { await this.pull(); return true; } catch (e) { return false; } }
};
