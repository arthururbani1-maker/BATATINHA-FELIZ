-- ============================================================
-- Rico Games ERP — Configuração do Supabase para sincronização
-- Rode este script no Supabase → SQL Editor → New query → Run
-- ============================================================

-- 1) Tabela de estado (já deve existir; cria se não existir)
create table if not exists public.erp_state (
  id text primary key,
  data jsonb,
  rev bigint default 0,
  updated_at timestamptz default now()
);

-- 2) Permissão para a chave pública (anon) ler/gravar
alter table public.erp_state enable row level security;

drop policy if exists "erp_state_all" on public.erp_state;
create policy "erp_state_all" on public.erp_state
  for all using (true) with check (true);

-- 3) HABILITAR REALTIME (é isto que faz a atualização instantânea entre os PCs)
alter table public.erp_state replica identity full;
alter publication supabase_realtime add table public.erp_state;

-- Pronto. Depois disso, abra o ERP nos dois computadores:
-- no rodapé do menu deve aparecer "Sincronizado · tempo real".
