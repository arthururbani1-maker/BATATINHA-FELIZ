# Publicar o Rico Games ERP no GitHub Pages (grátis)

Você vai subir os arquivos para um repositório e ligar o GitHub Pages. Em poucos minutos o sistema fica em um endereço tipo `https://seuusuario.github.io/rico-games`.

## Passo a passo

1. **Crie um repositório** em https://github.com/new
   - Nome: `rico-games` (ou o que preferir).
   - Pode deixar **público** (mais simples) e clicar em **Create repository**.

2. **Suba os arquivos** (escolha um jeito):
   - **Pelo site:** no repositório, clique em **Add file → Upload files**. Extraia o `.zip` que te enviei e **arraste TODO o conteúdo** (o `index.html`, a pasta `assets` e o arquivo `.nojekyll`). Importante: arraste o conteúdo de dentro da pasta, não a pasta `ERP RICO GAMES` por fora — o `index.html` precisa ficar na raiz do repositório. Depois clique em **Commit changes**.
   - **Pelo Git (terminal):** dentro da pasta do projeto:
     ```
     git init
     git add .
     git commit -m "Rico Games ERP"
     git branch -M main
     git remote add origin https://github.com/SEUUSUARIO/rico-games.git
     git push -u origin main
     ```

3. **Ligue o GitHub Pages:**
   - No repositório: **Settings → Pages**.
   - Em **Source**, escolha **Deploy from a branch**.
   - Em **Branch**, selecione **main** e a pasta **/ (root)**. Clique em **Save**.
   - Aguarde ~1 minuto. O endereço público aparece no topo dessa mesma página (ex: `https://seuusuario.github.io/rico-games/`).

4. **Acesse e use:**
   - Abra o endereço no PC da loja e no seu celular.
   - Faça login (admin / 1234) e conecte na nuvem em **Configurações → Sincronização na nuvem** (veja o `GUIA-NUVEM`).

## Importante

- O arquivo **`.nojekyll`** já vai no pacote — ele evita que o GitHub ignore a pasta `assets`. Não apague.
- Sempre que eu te entregar uma versão nova, é só repetir o **Upload files** (substituindo os arquivos) ou dar `git push` de novo.
- O endereço termina com `/rico-games/` — funciona normalmente, porque todos os caminhos do sistema são relativos.

## Atualizar depois

Para trocar por uma versão atualizada: **Add file → Upload files**, arraste os arquivos novos por cima e **Commit**. O site atualiza sozinho em ~1 min.
